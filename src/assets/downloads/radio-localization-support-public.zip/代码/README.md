# CUMCM B submission code

This directory excludes practice telemetry, official encrypted logs, caches, Git metadata, and local machine paths.

The competition identifier is never stored in code or configuration. Supply it only at runtime:

```powershell
python scripts/run_q3_rehearsal_r2.py --robot-id "<ROBOT_ID>" --base-url http://127.0.0.1:2026 --confirm-q3-rehearsal
python scripts/run_q4_rehearsal_full.py --robot-id "<ROBOT_ID>" --base-url http://127.0.0.1:2026 --confirm-q4-rehearsal
```

Q3 uses `Q3_BREAKTHROUGH_R2`. Q4 uses `Q4_SANDBOX_EXACT_FULL`, `PAIR=BOUND`, and `ROUTING=ROUTINGPLUS`.

Run `python scripts/audit_submission_privacy.py .` before packaging this directory.
