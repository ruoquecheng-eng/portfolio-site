"""Direct adapter for the 2026-09-12 Q3 breakthrough sandbox.

Experimental only: this imports the supplied controller as-is and routes its
public simulator calls to the repository's local OfflineArena.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any

import numpy as np

from b_problem.benchmark.offline_arena import OfflineArena
from b_problem.benchmark.types import Point
from b_problem.simulator.protocol import Point as OfficialPoint

EXPERIMENTAL_UNPROVEN = True
SANDBOX_ROOT = Path(__file__).resolve().parents[3] / "vendor" / "q3_breakthrough_sandbox"


def _require_offline(arena: Any) -> None:
    if not isinstance(arena, OfflineArena) or any(hasattr(arena, name) for name in ("base_url", "robot_id", "request_id")):
        raise RuntimeError("Q3_BREAKTHROUGH is local OfflineArena only")


class ArenaAdapter:
    def __init__(self, arena: OfflineArena) -> None:
        _require_offline(arena); self.arena = arena
    @property
    def pos(self) -> np.ndarray:
        p = self.arena.public_state.position; return np.array([p.x, p.y], dtype=float)
    @property
    def channel(self) -> int: return self.arena.public_state.measure_channel
    def measure(self, position: Any, channel: int):
        obs = self.arena.measure(Point(float(position[0]), float(position[1])), int(channel))
        return obs.result, obs.svd_deg
    def clear(self, position: Any, channel: int):
        return self.arena.clear(Point(float(position[0]), float(position[1])), int(channel)), self.arena.virtual_time_s
    def stats(self) -> dict[str, float | int | None]:
        trace = self.arena.trace
        cleared = sum(item.action.kind == "clear" and item.result == "success" for item in trace)
        return {"n_sources": 0, "n_cleared": cleared, "ratio": 0.0, "total_time_s": self.arena.virtual_time_s,
                "avg_time_s": None, "n_requests": len(trace), "move_m": sum(item.movement_m for item in trace),
                "t_move": sum(item.movement_m / 5 for item in trace),
                "t_switch": sum(float(item.switched) for item in trace if item.action.kind == "measure"),
                "t_measure": 5 * sum(item.action.kind == "measure" for item in trace),
                "t_clear": sum(5 if item.result == "success" else 3 for item in trace if item.action.kind == "clear")}


class OfficialArenaAdapter:
    """Tuple-shaped R2 adapter over the validated serial official client."""
    def __init__(self, robot: Any) -> None:
        self._robot = robot
        self.measure_count = self.switch_count = self.successful_clears = self.failed_clears = 0
        self.negative_observations = 0
    @property
    def pos(self) -> np.ndarray:
        p = self._robot.state.position; return np.array([p.x, p.y], dtype=float)
    @property
    def channel(self) -> int: return self._robot.state.measure_channel
    def measure(self, position: Any, channel: int):
        before = self.channel
        response = self._robot.measure(OfficialPoint(float(position[0]), float(position[1])), int(channel))
        self.measure_count += 1; self.switch_count += int(before != int(channel))
        self.negative_observations += int(response.measure_result == "no_signal")
        return response.measure_result, response.svd_deg
    def clear(self, position: Any, channel: int):
        response = self._robot.clear(OfficialPoint(float(position[0]), float(position[1])), int(channel))
        if response.clear_result == "success": self.successful_clears += 1
        else: self.failed_clears += 1
        return response.clear_result, response.virtual_time_s
    def stats(self) -> dict[str, float | int | None]:
        return {"n_sources": 0, "n_cleared": self.successful_clears, "ratio": 0.0,
                "total_time_s": self._robot.state.virtual_time_s, "avg_time_s": None,
                "n_requests": self.measure_count + self.successful_clears + self.failed_clears,
                "move_m": 0., "t_move": 0., "t_switch": float(self.switch_count),
                "t_measure": 5. * self.measure_count,
                "t_clear": 5. * self.successful_clears + 3. * self.failed_clears}


def _load() -> Any:
    if not SANDBOX_ROOT.is_dir(): raise RuntimeError(f"Q3 breakthrough sandbox missing: {SANDBOX_ROOT}")
    for path in (str(SANDBOX_ROOT), str(SANDBOX_ROOT / "lib")):
        if path not in sys.path: sys.path.insert(0, path)
    # Avoid reusing an identically named module from the earlier sandbox.
    for name in ("strategy", "strategy2", "geom", "sim", "run_q3_nextgen", "q3_breakthrough"):
        old = sys.modules.get(name)
        if old is not None and not str(getattr(old, "__file__", "")).startswith(str(SANDBOX_ROOT)):
            del sys.modules[name]
    import q3_breakthrough  # type: ignore
    return q3_breakthrough


@dataclass
class BreakthroughTelemetry:
    variant: str
    lookahead_choices: int = 0
    band_sweeps: int = 0
    band_attempts: int = 0
    early16: bool = False
    rotation_phase: float = 0.0
    controller_result: dict[str, Any] = field(default_factory=dict)


def execute_q3_breakthrough(arena: OfflineArena, *, variant: str = "r2", telemetry: BreakthroughTelemetry | None = None) -> BreakthroughTelemetry:
    _require_offline(arena)
    if variant not in {"r1", "r2", "r3"}: raise ValueError("variant must be r1, r2, or r3")
    module = _load(); telemetry = telemetry or BreakthroughTelemetry(variant)
    controller = module.CLASSES[variant](ArenaAdapter(arena), module.PLAN,
        module.Params2(name=f"real_{variant}", theta_miss=0, use_belief=False), 3,
        neg=True, conditional=True, threshold=0, outer_n=9, outer_r=1700, rotate=True)
    telemetry.controller_result = controller.run()
    telemetry.lookahead_choices = int(getattr(controller, "lookahead_choices", 0))
    telemetry.band_sweeps = int(getattr(controller, "band_sweeps", 0))
    telemetry.band_attempts = int(getattr(controller, "band_attempts", 0))
    telemetry.early16 = bool(getattr(controller, "early16", False))
    telemetry.rotation_phase = float(getattr(controller, "base_phase", 0.0))
    return telemetry


def execute_q3_breakthrough_official(robot: Any) -> dict[str, Any]:
    """Run exactly R2 through an official-client adapter; no live configuration here."""
    module = _load(); telemetry = BreakthroughTelemetry("r2")
    adapter = OfficialArenaAdapter(robot)
    controller = module.CLASSES["r2"](adapter, module.PLAN,
        module.Params2(name="official_r2", theta_miss=0, use_belief=False), 3,
        neg=True, conditional=True, threshold=0, outer_n=9, outer_r=1700, rotate=True)
    result = controller.run()
    return {**result, "complete": not result.get("unresolved") and not result.get("gave_up"),
            "algorithm_version": "Q3_BREAKTHROUGH_R2", "strategy_class": type(controller).__name__,
            "lookahead_choices": int(getattr(controller, "lookahead_choices", 0)),
            "band_sweeps": int(getattr(controller, "band_sweeps", 0)),
            "band_attempts": int(getattr(controller, "band_attempts", 0)),
            "negative_observations": adapter.negative_observations, "measure_count": adapter.measure_count,
            "switch_count": adapter.switch_count, "successful_clears": adapter.successful_clears,
            "failed_clears": adapter.failed_clears}
