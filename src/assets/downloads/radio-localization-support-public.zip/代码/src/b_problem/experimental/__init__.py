"""Isolated, non-production experiments.

Nothing in this package is imported by the competition entry points.
"""
