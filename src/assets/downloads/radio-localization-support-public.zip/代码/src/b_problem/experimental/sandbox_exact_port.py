"""Direct portable-sandbox controller adapter for the local offline harness.

This is intentionally an *unproven* behavior port: it runs the supplied
sandbox classes unchanged wherever their simulator API can be represented by
``OfflineArena``.  It is isolated from production strategy modules and rejects
anything other than the in-process local benchmark arena.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any

import numpy as np

from b_problem.benchmark.offline_arena import OfflineArena
from b_problem.benchmark.types import Point
from b_problem.simulator.protocol import Point as OfficialPoint

EXPERIMENTAL_UNPROVEN = True
PORTABLE_ROOT = Path(__file__).resolve().parents[3] / "vendor" / "portable_sandbox"


def _offline_only(arena: Any) -> None:
    """Make accidental use with official/online clients fail before an action."""
    if not isinstance(arena, OfflineArena) or any(hasattr(arena, name) for name in ("base_url", "robot_id", "request_id")):
        raise RuntimeError("SANDBOX_EXACT is offline-only; online/official execution is refused")


def _load_portable() -> dict[str, Any]:
    if not PORTABLE_ROOT.is_dir():
        raise RuntimeError(f"portable sandbox missing: {PORTABLE_ROOT}")
    for path in (str(PORTABLE_ROOT), str(PORTABLE_ROOT / "lib")):
        if path not in sys.path:
            sys.path.insert(0, path)
    # Imports intentionally use the portable sandbox's own implementation.
    import strategy  # type: ignore
    import strategy2  # type: ignore
    import run_q3_nextgen  # type: ignore
    import run_safe7_r1130  # type: ignore
    import run_q4_shared_pair  # type: ignore
    import run_q4_shared_pair_bound  # type: ignore
    import run_q4_routingplus  # type: ignore
    import run_q4_routingplus_bound  # type: ignore
    strategy.MARGIN = 2.0
    return {"strategy2": strategy2, "q3": run_q3_nextgen, "safe7": run_safe7_r1130,
            "pair": run_q4_shared_pair, "pair_bound": run_q4_shared_pair_bound,
            "routing": run_q4_routingplus, "routing_bound": run_q4_routingplus_bound}


class ArenaSimulatorAdapter:
    """Sandbox ``Simulator`` surface mapped to real local-harness billing."""
    def __init__(self, arena: OfflineArena) -> None:
        _offline_only(arena)
        self.arena = arena

    @property
    def pos(self) -> np.ndarray:
        point = self.arena.public_state.position
        return np.array([point.x, point.y], dtype=float)

    @property
    def channel(self) -> int:
        return self.arena.public_state.measure_channel

    def measure(self, position: Any, channel: int) -> tuple[str, float | None]:
        point = Point(float(position[0]), float(position[1]))
        response = self.arena.measure(point, int(channel))
        return response.result, response.svd_deg

    def clear(self, position: Any, channel: int) -> tuple[str, float]:
        point = Point(float(position[0]), float(position[1]))
        result = self.arena.clear(point, int(channel))
        return result, self.arena.virtual_time_s

    def stats(self) -> dict[str, float | int | None]:
        trace = self.arena.trace
        cleared = sum(item.action.kind == "clear" and item.result == "success" for item in trace)
        return {"n_sources": 0, "n_cleared": cleared, "ratio": 0.0,
                "total_time_s": self.arena.virtual_time_s, "avg_time_s": None,
                "n_requests": len(trace), "move_m": sum(item.movement_m for item in trace),
                "t_move": sum(item.movement_m / 5.0 for item in trace),
                "t_switch": sum(float(item.switched) for item in trace if item.action.kind == "measure"),
                "t_measure": 5.0 * sum(item.action.kind == "measure" for item in trace),
                "t_clear": sum(5.0 if item.result == "success" else 3.0 for item in trace if item.action.kind == "clear")}


class OfficialSimulatorAdapter:
    """Portable sandbox simulator API over the already-validated HTTP client."""
    def __init__(self, robot: Any) -> None:
        self.robot=robot; self.measures=self.switches=self.successes=self.failures=0
    @property
    def pos(self) -> np.ndarray:
        p=self.robot.state.position; return np.array([p.x,p.y],float)
    @property
    def channel(self) -> int: return self.robot.state.measure_channel
    def measure(self, position: Any, channel: int):
        old=self.channel; r=self.robot.measure(OfficialPoint(float(position[0]),float(position[1])),int(channel))
        self.measures+=1; self.switches+=int(old!=int(channel)); return r.measure_result,r.svd_deg
    def clear(self, position: Any, channel: int):
        r=self.robot.clear(OfficialPoint(float(position[0]),float(position[1])),int(channel))
        self.successes+=int(r.clear_result=="success"); self.failures+=int(r.clear_result!="success"); return r.clear_result,r.virtual_time_s
    def stats(self) -> dict[str,float|int|None]:
        return {"n_sources":0,"n_cleared":self.successes,"ratio":0.,"total_time_s":self.robot.state.virtual_time_s,"avg_time_s":None,"n_requests":self.measures+self.successes+self.failures,"move_m":0.,"t_move":0.,"t_switch":float(self.switches),"t_measure":5.*self.measures,"t_clear":5.*self.successes+3.*self.failures}


@dataclass
class ExactTelemetry:
    family: str
    pair_events: list[dict[str, Any]] = field(default_factory=list)
    controller_result: dict[str, Any] = field(default_factory=dict)


def _audit_pair_class(base: type, telemetry: ExactTelemetry) -> type:
    """Record polygon transitions only; target truth is audited after execution."""
    class Audited(base):  # type: ignore[misc, valid-type]
        def _record_nosig(self, channel: int, point: Any) -> None:
            before = [np.asarray(vertex, float).tolist() for vertex in self.tracked.get(channel, [])]
            clips = getattr(self, "pair_clips", 0)
            super()._record_nosig(channel, point)
            if getattr(self, "pair_clips", 0) > clips:
                after = [np.asarray(vertex, float).tolist() for vertex in self.tracked.get(channel, [])]
                telemetry.pair_events.append({"channel": int(channel), "before": before, "after": after,
                                              "probe": np.asarray(point, float).tolist()})
    return Audited


def execute_q4_sandbox_exact(arena: OfflineArena, *, variant: str, telemetry: ExactTelemetry | None = None) -> ExactTelemetry:
    _offline_only(arena)
    if variant not in {"PAIR_ORIGINAL", "PAIR_BOUND", "FULL", "FULL_NN"}:
        raise ValueError("invalid Q4 sandbox-exact variant")
    modules = _load_portable(); telemetry = telemetry or ExactTelemetry(variant)
    sim = ArenaSimulatorAdapter(arena); params = modules["strategy2"].Params2(name=f"exact_{variant}", theta_miss=0, use_belief=False)
    plan = {"level1": [list(point) for point in modules["pair"].PTS21], "escalation": []}
    if variant == "PAIR_ORIGINAL":
        cls = _audit_pair_class(modules["pair"].SharedPairStrict, telemetry)
        controller = cls(sim, plan, params, 4, shared_radius=50, fresh_only=True)
    elif variant == "PAIR_BOUND":
        cls = _audit_pair_class(modules["pair_bound"].SharedPairBoundStrict, telemetry)
        controller = cls(sim, plan, params, 4, shared_radius=50, fresh_only=True)
    else:
        cls = _audit_pair_class(modules["routing"].RoutingPlusPair, telemetry)
        controller = cls(sim, plan, params, 4, shared_radius=50, fresh_only=True,
                         oropt=variant == "FULL", warm=variant == "FULL", starts=4 if variant == "FULL" else 1)
    telemetry.controller_result = controller.run()
    return telemetry


def execute_q3_sandbox_exact(arena: OfflineArena, *, variant: str, telemetry: ExactTelemetry | None = None) -> ExactTelemetry:
    _offline_only(arena)
    if variant not in {"NEXTGEN", "SAFE7", "FULL"}:
        raise ValueError("invalid Q3 sandbox-exact variant")
    modules = _load_portable(); telemetry = telemetry or ExactTelemetry(variant)
    sim = ArenaSimulatorAdapter(arena); params = modules["strategy2"].Params2(name=f"exact_{variant}", theta_miss=0, use_belief=False)
    if variant == "SAFE7":
        controller = modules["safe7"].StrictFiltered(sim, modules["safe7"].PLAN, params, 3)
    else:
        cfg = {"base": dict(neg=False, conditional=False, rotate=False),
               "full": dict(neg=True, conditional=True, rotate=True)}["base" if variant == "NEXTGEN" else "full"]
        controller = modules["q3"].Q3NegDynamic(sim, modules["q3"].PLAN, params, 3, **cfg)
    telemetry.controller_result = controller.run()
    return telemetry


def execute_q4_sandbox_exact_official(robot: Any) -> dict[str, Any]:
    """Q4 rehearsal-only FULL routing controller, explicitly PAIR_BOUND."""
    modules=_load_portable(); telemetry=ExactTelemetry("FULL_PAIR_BOUND_ROUTINGPLUS")
    sim=OfficialSimulatorAdapter(robot); params=modules["strategy2"].Params2(name="official_full_pair_bound",theta_miss=0,use_belief=False)
    plan={"level1":[list(point) for point in modules["pair"].PTS21],"escalation":[]}
    cls=_audit_pair_class(modules["routing_bound"].RoutingPlusPair,telemetry)
    controller=cls(sim,plan,params,4,shared_radius=50,fresh_only=True,oropt=True,warm=True,starts=4)
    result=controller.run(); telemetry.controller_result=result
    return {**result,"complete":not result.get("unresolved") and not result.get("gave_up"),"algorithm_version":"Q4_SANDBOX_EXACT_FULL","strategy_class":type(controller).__name__,"pair_mode":"BOUND","routing":"ROUTINGPLUS","pair_events":telemetry.pair_events,"measure_count":sim.measures,"switch_count":sim.switches,"successful_clears":sim.successes,"failed_clears":sim.failures}
