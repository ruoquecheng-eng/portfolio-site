"""Conservative arbitrary-station oracle for offline MINCERT search.

PASS is deliberately stronger than sampled success: the station Delaunay mesh
must cover the entire source disk and every triangle intersecting that disk
must have edges at most the 1000 m guaranteed receive radius.  Any source in
such a triangle is in the convex hull of three in-range stations, proving the
closed-half-plane directional condition.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import atan2, cos, hypot, pi, sin
from typing import Iterable

import numpy as np
from scipy.spatial import Delaunay, QhullError

from b_problem.strategy import q4


@dataclass(frozen=True)
class DirectionalCertificateValidation:
    status: str
    method: str
    failure_kind: str | None
    counterexample: q4.Point | None
    counterexample_orientation_deg: float | None
    max_active_triangle_edge_m: float | None
    margin_m: float | None
    detail: str


def two_ring_candidate(*, outer_radius_m: float, inner_radius_m: float, count: int = 12) -> frozenset[q4.Point]:
    """A boundary-adaptive polar mesh; the inner ring is half a sector offset."""
    if count < 3 or outer_radius_m <= 0.0 or inner_radius_m <= 0.0:
        raise ValueError("ring counts and radii must be positive")
    return frozenset({
        q4.Point(0.0, 0.0),
        *(q4.Point(outer_radius_m * cos(2.0 * pi * index / count), outer_radius_m * sin(2.0 * pi * index / count)) for index in range(count)),
        *(q4.Point(inner_radius_m * cos(2.0 * pi * (index + 0.5) / count), inner_radius_m * sin(2.0 * pi * (index + 0.5) / count)) for index in range(count)),
    })


def _cross(first: q4.Point, second: q4.Point, point: q4.Point) -> float:
    return (second.x - first.x) * (point.y - first.y) - (second.y - first.y) * (point.x - first.x)


def _convex_hull(points: Iterable[q4.Point]) -> tuple[q4.Point, ...]:
    ordered = sorted(set(points))
    if len(ordered) <= 1:
        return tuple(ordered)
    lower: list[q4.Point] = []
    for point in ordered:
        while len(lower) >= 2 and _cross(lower[-2], lower[-1], point) <= q4.TOLERANCE:
            lower.pop()
        lower.append(point)
    upper: list[q4.Point] = []
    for point in reversed(ordered):
        while len(upper) >= 2 and _cross(upper[-2], upper[-1], point) <= q4.TOLERANCE:
            upper.pop()
        upper.append(point)
    return tuple(lower[:-1] + upper[:-1])


def _disk_hull_witness(hull: tuple[q4.Point, ...], radius_m: float) -> tuple[q4.Point, float] | None:
    """Return a real uncovered source/orientation when the disk exits the hull."""
    if len(hull) < 3:
        return q4.Point(radius_m, 0.0), 0.0
    worst: tuple[float, q4.Point, q4.Point, float, float] | None = None
    for first, second in zip(hull, hull[1:] + hull[:1]):
        dx, dy = second.x - first.x, second.y - first.y
        length = hypot(dx, dy)
        inward_x, inward_y = -dy / length, dx / length
        # The minimum signed distance over the source disk occurs opposite the
        # inward normal.  A negative result lies strictly outside this hull edge.
        minimum = -radius_m - (inward_x * first.x + inward_y * first.y)
        source = q4.Point(-radius_m * inward_x, -radius_m * inward_y)
        if worst is None or minimum < worst[0]:
            worst = (minimum, first, second, inward_x, inward_y)
    assert worst is not None
    minimum, _first, _second, inward_x, inward_y = worst
    if minimum >= -q4.TOLERANCE:
        return None
    source = q4.Point(-radius_m * inward_x, -radius_m * inward_y)
    # Outward normal is an emitting direction that strictly excludes every
    # station of the convex hull from its closed half-plane through ``source``.
    orientation = atan2(-inward_y, -inward_x) * 180.0 / 3.141592653589793 % 360.0
    return source, orientation


def _point_in_triangle(point: q4.Point, triangle: tuple[q4.Point, q4.Point, q4.Point]) -> bool:
    signs = [_cross(first, second, point) for first, second in zip(triangle, triangle[1:] + triangle[:1])]
    return all(value >= -q4.TOLERANCE for value in signs) or all(value <= q4.TOLERANCE for value in signs)


def _segment_origin_distance(first: q4.Point, second: q4.Point) -> float:
    dx, dy = second.x - first.x, second.y - first.y
    denominator = dx * dx + dy * dy
    if denominator <= q4.TOLERANCE:
        return first.radius()
    ratio = max(0.0, min(1.0, -(first.x * dx + first.y * dy) / denominator))
    return hypot(first.x + ratio * dx, first.y + ratio * dy)


def _triangle_intersects_disk(triangle: tuple[q4.Point, q4.Point, q4.Point], radius_m: float) -> bool:
    if _point_in_triangle(q4.Point(0.0, 0.0), triangle):
        return True
    return min(_segment_origin_distance(first, second) for first, second in zip(triangle, triangle[1:] + triangle[:1])) <= radius_m + q4.TOLERANCE


def validate_directional_certificate(
    stations: Iterable[q4.Point], *, source_radius_m: float = q4.TARGET_RADIUS_M, receive_radius_m: float = q4.MIN_RECEIVE_RADIUS_M
) -> DirectionalCertificateValidation:
    """Conservatively prove or reject an arbitrary precomputed station set."""
    points = tuple(sorted(set(stations)))
    if len(points) < 3:
        return DirectionalCertificateValidation("FAIL", "delaunay_triangle_cover", "counterexample", q4.Point(source_radius_m, 0.0), 0.0, None, None, "fewer than three stations")
    hull_witness = _disk_hull_witness(_convex_hull(points), source_radius_m)
    if hull_witness is not None:
        source, orientation = hull_witness
        return DirectionalCertificateValidation("FAIL", "delaunay_triangle_cover", "counterexample", source, orientation, None, None, "source disk is not inside station convex hull")
    try:
        simplices = Delaunay(np.array([(point.x, point.y) for point in points], dtype=float)).simplices
    except QhullError:
        return DirectionalCertificateValidation("FAIL", "delaunay_triangle_cover", "unproven_degenerate_mesh", None, None, None, None, "Delaunay triangulation is degenerate")
    active_edges = []
    for simplex in simplices:
        triangle = tuple(points[index] for index in simplex)
        if not _triangle_intersects_disk(triangle, source_radius_m):
            continue
        edge = max(first.distance_to(second) for first, second in zip(triangle, triangle[1:] + triangle[:1]))
        active_edges.append(edge)
    if not active_edges:
        return DirectionalCertificateValidation("FAIL", "delaunay_triangle_cover", "unproven_mesh", None, None, None, None, "no Delaunay triangle intersects source disk")
    maximum = max(active_edges)
    margin = receive_radius_m - maximum
    if margin < -q4.TOLERANCE:
        return DirectionalCertificateValidation("FAIL", "delaunay_triangle_cover", "unproven_long_edge", None, None, maximum, margin, "active Delaunay triangle exceeds guaranteed receive radius")
    return DirectionalCertificateValidation("PASS", "delaunay_triangle_cover", None, None, None, maximum, margin, "conservative triangulation proof")
