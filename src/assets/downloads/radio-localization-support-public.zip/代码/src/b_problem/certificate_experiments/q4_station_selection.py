"""Static Q4 station-set certificates for the 180-degree directional guarantee.

For a source ``x``, let ``N(x)`` be the scheduled stations within 1000 m.
If ``x`` lies in ``conv(N(x))``, then every closed half-plane through ``x``
contains a receiver: otherwise a separating normal is negative at every
member of ``N(x)`` and therefore at their convex hull, contradicting ``x``.

The triangular-lattice construction below is a sufficient certificate for
that premise.  It is deliberately independent from ``q4.execute_q4_strategy``
and is intended only for static design experiments.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import cos, radians, sin
from random import Random

from b_problem.strategy import q4


SPACINGS_M = (650.0, 700.0, 750.0, 800.0, 850.0, 900.0, 925.0, 950.0, 975.0, 990.0)


@dataclass(frozen=True)
class StationCandidate:
    name: str
    edge_m: float
    stations: frozenset[q4.Point]
    route: tuple[q4.Point, ...]
    construction: str


@dataclass(frozen=True)
class StationCertificateAudit:
    name: str
    edge_m: float
    station_count: int
    route_length_m: float
    required_support_count: int
    redundant_station_count: int
    analytic_status: str
    deterministic_stress_status: str
    stress_sample_count: int
    critical_sample_count: int
    minimum_nearby_station_count: int
    proof: str


def _full_cells(edge_m: float) -> tuple[q4.Triangle, ...]:
    cells, _ = q4._full_lattice_cells(  # noqa: SLF001 - certificate reuses exact lattice geometry.
        q4.TARGET_RADIUS_M, edge_m, q4.Point(0.0, 0.0), outer_layers=2
    )
    return cells


def required_radial_support(edge_m: float) -> frozenset[q4.Point]:
    """Return the finite lattice collar required by the triangle proof.

    If a target point belongs to an edge-``h`` triangular cell, every vertex
    is within ``h`` of that point and hence within ``R+h`` of the origin.
    Retaining this radial collar therefore retains all three cell vertices.
    """
    if edge_m <= 0.0:
        raise ValueError("edge_m must be positive")
    _, points = q4._full_lattice_cells(  # noqa: SLF001 - same exact lattice as Q4.
        q4.TARGET_RADIUS_M, edge_m, q4.Point(0.0, 0.0), outer_layers=2
    )
    return frozenset(
        point for point in points
        if point.radius() <= q4.TARGET_RADIUS_M + edge_m + q4.TOLERANCE
    )


def _route(stations: frozenset[q4.Point]) -> tuple[q4.Point, ...]:
    return q4._q4_snake_order(tuple(stations))  # noqa: SLF001 - static route metric only.


def current_exact_candidate() -> StationCandidate:
    """CERT-B: the exact Q4 static station set, without modifying Q4."""
    plan = q4.build_survey_plan()
    return StationCandidate(
        "CERT-B exact current Q4 set", plan.edge_m, plan.stations, plan.route,
        "Exact build_survey_plan() stations and its deterministic snake route.",
    )


def radial_support_candidate(edge_m: float) -> StationCandidate:
    """CERT-C: only the analytically necessary radial lattice support."""
    stations = required_radial_support(edge_m)
    return StationCandidate(
        f"CERT-C radial support h={edge_m:g}", edge_m, stations, _route(stations),
        "Keep every triangular-lattice vertex with radius at most R+h.",
    )


def _candidate_from_stations(name: str, base: StationCandidate, stations: set[q4.Point], construction: str) -> StationCandidate:
    frozen = frozenset(stations)
    return StationCandidate(name, base.edge_m, frozen, _route(frozen), construction)


def greedy_redundant_deletion(candidate: StationCandidate) -> StationCandidate:
    """Delete only stations whose removal leaves the radial-support proof intact."""
    required = required_radial_support(candidate.edge_m)
    working = set(candidate.stations)
    extras = sorted(working - required, key=lambda point: (-point.radius(), point.x, point.y))
    for point in extras:
        proposal = working - {point}
        if required <= proposal:
            working = proposal
    return _candidate_from_stations(
        f"{candidate.name} greedy-pruned", candidate, working,
        "Greedy deletion accepts a removal only when every R+h support vertex remains.",
    )


def randomized_redundant_deletion(candidate: StationCandidate, *, seed: int) -> StationCandidate:
    """Seeded deletion-order check; it has the same analytic acceptance rule."""
    required = required_radial_support(candidate.edge_m)
    working = set(candidate.stations)
    extras = list(working - required)
    Random(seed).shuffle(extras)
    for point in extras:
        proposal = working - {point}
        if required <= proposal:
            working = proposal
    return _candidate_from_stations(
        f"{candidate.name} randomized-pruned seed={seed}", candidate, working,
        "Randomized deletion order, but each accepted deletion retains all R+h support vertices.",
    )


def _cross(origin: q4.Point, first: q4.Point, second: q4.Point) -> float:
    return (first.x - origin.x) * (second.y - origin.y) - (first.y - origin.y) * (second.x - origin.x)


def _convex_hull(points: tuple[q4.Point, ...]) -> tuple[q4.Point, ...]:
    ordered = sorted(set(points))
    if len(ordered) <= 1:
        return tuple(ordered)
    lower: list[q4.Point] = []
    for point in ordered:
        while len(lower) >= 2 and _cross(lower[-2], lower[-1], point) <= q4.TOLERANCE:
            lower.pop()
        lower.append(point)
    upper: list[q4.Point] = []
    for point in reversed(ordered):
        while len(upper) >= 2 and _cross(upper[-2], upper[-1], point) <= q4.TOLERANCE:
            upper.pop()
        upper.append(point)
    return tuple(lower[:-1] + upper[:-1])


def source_in_nearby_convex_hull(source: q4.Point, stations: frozenset[q4.Point]) -> tuple[bool, int]:
    """Directly validate the directional sufficient premise at one source."""
    nearby = tuple(point for point in stations if point.distance_to(source) <= q4.MIN_RECEIVE_RADIUS_M + q4.TOLERANCE)
    hull = _convex_hull(nearby)
    if len(hull) == 0:
        return False, 0
    if len(hull) == 1:
        return hull[0].distance_to(source) <= q4.TOLERANCE, len(nearby)
    if len(hull) == 2:
        on_line = abs(_cross(hull[0], hull[1], source)) <= q4.TOLERANCE
        between = (source.x - hull[0].x) * (source.x - hull[1].x) + (source.y - hull[0].y) * (source.y - hull[1].y) <= q4.TOLERANCE
        return on_line and between, len(nearby)
    return all(_cross(first, second, source) >= -q4.TOLERANCE for first, second in zip(hull, hull[1:] + hull[:1])), len(nearby)


def _critical_samples(candidate: StationCandidate) -> tuple[q4.Point, ...]:
    samples: set[q4.Point] = set()
    for triangle in _full_cells(candidate.edge_m):
        if not all(vertex in candidate.stations for vertex in triangle.vertices):
            continue
        a, b, c = triangle.vertices
        for point in (a, b, c, q4.Point((a.x + b.x) / 2.0, (a.y + b.y) / 2.0),
                      q4.Point((b.x + c.x) / 2.0, (b.y + c.y) / 2.0),
                      q4.Point((c.x + a.x) / 2.0, (c.y + a.y) / 2.0),
                      q4.Point((a.x + b.x + c.x) / 3.0, (a.y + b.y + c.y) / 3.0)):
            if point.radius() <= q4.TARGET_RADIUS_M + q4.TOLERANCE:
                samples.add(point)
    return tuple(sorted(samples))


def _dense_disk_samples(*, radial_step_m: float, angle_step_deg: int) -> tuple[q4.Point, ...]:
    if radial_step_m <= 0.0 or angle_step_deg <= 0 or 360 % angle_step_deg:
        raise ValueError("use a positive radial step and an integer divisor of 360 degrees")
    samples = {q4.Point(0.0, 0.0)}
    radius = radial_step_m
    while radius < q4.TARGET_RADIUS_M - q4.TOLERANCE:
        for angle in range(0, 360, angle_step_deg):
            samples.add(q4.Point(radius * cos(radians(angle)), radius * sin(radians(angle))))
        radius += radial_step_m
    for angle in range(0, 360, angle_step_deg):
        samples.add(q4.Point(q4.TARGET_RADIUS_M * cos(radians(angle)), q4.TARGET_RADIUS_M * sin(radians(angle))))
    return tuple(sorted(samples))


def audit_candidate(
    candidate: StationCandidate, *, radial_step_m: float = 25.0, angle_step_deg: int = 2
) -> StationCertificateAudit:
    """Check the analytic lattice premise plus deterministic dense/critical witnesses."""
    required = required_radial_support(candidate.edge_m)
    analytic = candidate.edge_m <= q4.MIN_RECEIVE_RADIUS_M + q4.TOLERANCE and required <= candidate.stations
    dense = _dense_disk_samples(radial_step_m=radial_step_m, angle_step_deg=angle_step_deg)
    critical = _critical_samples(candidate)
    minimum_nearby = len(candidate.stations)
    stress_ok = True
    for source in (*dense, *critical):
        contained, nearby_count = source_in_nearby_convex_hull(source, candidate.stations)
        minimum_nearby = min(minimum_nearby, nearby_count)
        if not contained:
            stress_ok = False
            break
    return StationCertificateAudit(
        candidate.name, candidate.edge_m, len(candidate.stations),
        q4._q4_route_length(q4.Point(0.0, 0.0), candidate.route),  # noqa: SLF001 - metric only.
        len(required), max(0, len(candidate.stations - required)),
        "PROVED" if analytic else "UNRESOLVED",
        "NUMERICALLY_VERIFIED" if stress_ok else "FAILED",
        len(dense) + len(critical), len(critical), minimum_nearby,
        (
            "For every target point, its containing lattice triangle has all three vertices inside R+h; "
            "these vertices are scheduled, within h<=1000 m, and their convex hull contains the source. "
            "The convex-hull half-plane lemma then supplies a receiver for every closed 180-degree direction."
            if analytic else
            "This candidate does not satisfy the triangular-cell/radial-support sufficient condition."
        ),
    )


def run_static_experiments() -> tuple[StationCertificateAudit, ...]:
    """CERT-B/C comparison, including greedy/random pruning and requested spacings."""
    current = current_exact_candidate()
    candidates = [current, greedy_redundant_deletion(current)]
    candidates.extend(randomized_redundant_deletion(current, seed=seed) for seed in (17, 53, 97))
    candidates.extend(radial_support_candidate(edge_m) for edge_m in SPACINGS_M)
    return tuple(audit_candidate(candidate) for candidate in candidates)
