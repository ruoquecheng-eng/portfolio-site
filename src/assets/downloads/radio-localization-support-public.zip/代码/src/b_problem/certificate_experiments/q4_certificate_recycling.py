"""Conservative offline replay of per-channel CERT-D measurement witnesses.

The proved CERT-C construction requires its complete 31-point radial-support
set.  This replay therefore credits a witness only when an actual ``no_signal``
measurement occurred exactly at one of those proved points.  Arbitrary visited
or measured points are deliberately not substituted: the current validator has
no analytic certificate for such a replacement.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from b_problem.strategy.q4 import Point


@dataclass(frozen=True)
class ReplayMeasurement:
    channel: int
    position: Point
    result: str
    virtual_time_s: float


def cert_d_reference_stations() -> frozenset[Point]:
    """Return only the independently proved 31-point CERT-D basis."""
    from b_problem.certificate_experiments.q4_station_selection import radial_support_candidate

    candidate = radial_support_candidate(925.0)
    if len(candidate.stations) != 31:
        raise RuntimeError("CERT-D reference certificate invariant failed")
    return candidate.stations


def no_signal_witnesses(
    events: Iterable[ReplayMeasurement], *, channel: int, through_time_s: float | None = None
) -> frozenset[Point]:
    """Extract only valid no-signal measurements for one channel and time cut."""
    return frozenset(
        event.position
        for event in events
        if event.channel == channel
        and event.result == "no_signal"
        and (through_time_s is None or event.virtual_time_s <= through_time_s)
    )


def remaining_certificate_stations(
    channel: int, witness_positions: Iterable[Point], reference_31_station_set: Iterable[Point]
) -> tuple[Point, ...]:
    """Return the proved reference witnesses still missing for one channel.

    ``channel`` is intentionally explicit to make callers retain per-channel
    evidence rather than pooling no-signal observations across channels.
    """
    if not 1 <= channel <= 20:
        raise ValueError("channel must be in 1..20")
    reference = frozenset(reference_31_station_set)
    witnesses = frozenset(witness_positions)
    return tuple(sorted(reference - witnesses))


def is_channel_certificate_complete(
    channel: int, witness_positions: Iterable[Point], reference_31_station_set: Iterable[Point]
) -> bool:
    """Conservative deterministic completion check for the current validator."""
    return not remaining_certificate_stations(channel, witness_positions, reference_31_station_set)
