"""Read-only, reconciled movement taxonomy for frozen CERT-D traces."""
from __future__ import annotations

from dataclasses import dataclass
from math import hypot
from typing import Iterable

from b_problem.benchmark.types import Trace
from b_problem.strategy.q4 import Point


@dataclass(frozen=True)
class MovementSegment:
    case_id: str
    event_index: int
    timestamp_before_s: float
    timestamp_after_s: float
    from_point: Point
    to_point: Point
    distance_m: float
    virtual_time_cost_s: float
    current_channel: int | None
    target_channel: int
    strategy_state_before: str
    strategy_state_after: str
    primary_category: str
    secondary_purposes: tuple[str, ...]
    source_channel: int | None
    current_target_type: str
    current_target_id: str | None
    certificate_target_id: int | None
    task_reason: str
    route_plan_id: str
    route_plan_index: int | None


@dataclass(frozen=True)
class MovementLedger:
    segments: tuple[MovementSegment, ...]
    reported_movement_m: float
    trace_movement_m: float
    reconciliation_pass: bool


def _same(point, station: Point) -> bool:
    return abs(point.x - station.x) <= 1e-8 and abs(point.y - station.y) <= 1e-8


def _station_index(point, stations: tuple[Point, ...]) -> int | None:
    for index, station in enumerate(stations):
        if _same(point, station):
            return index
    return None


def build_movement_ledger(
    case_id: str, trace: Iterable[Trace], stations: Iterable[Point], *, last_source_clear_event_index: int | None = None
) -> MovementLedger:
    """Assign one deterministic primary label to every positive-movement trace leg."""
    items = tuple(trace)
    route = tuple(stations)
    position = Point(0.0, 0.0)
    virtual_time = 0.0
    current_channel: int | None = 1
    in_source_handling = False
    survey_complete = False
    route_index: int | None = None
    last_clear_failed: set[int] = set()
    segments: list[MovementSegment] = []
    for event_index, event in enumerate(items):
        target = Point(event.action.position.x, event.action.position.y)
        station_index = _station_index(event.action.position, route)
        before_state = "FALLBACK" if survey_complete else ("SOURCE_HANDLING" if in_source_handling else "SURVEY")
        if event.movement_m > 1e-12:
            if survey_complete:
                category, secondary, source = "FALLBACK", (), event.action.channel
            elif station_index is not None:
                category = "ROUTE_RECONNECTION" if in_source_handling else (
                    "FINAL_CERTIFICATE" if last_source_clear_event_index is not None and event_index > last_source_clear_event_index else "CERT_ROUTE"
                )
                secondary, source = (("certificate_gain",), current_channel) if in_source_handling else ((), None)
            elif event.action.kind == "measure":
                if not in_source_handling:
                    category, secondary = "SECOND_BEARING", ("source_geometry",)
                else:
                    category, secondary = "LOCALIZATION_RECOVERY", ("source_geometry",)
                source = event.action.channel
            elif event.action.channel in last_clear_failed:
                category, secondary, source = "CLEAR_RETRY", (), event.action.channel
            else:
                category, secondary, source = "CLEAR_APPROACH", (), event.action.channel
            after_state = "FALLBACK" if survey_complete else ("SURVEY" if station_index is not None else "SOURCE_HANDLING")
            target_type = "certificate_station" if station_index is not None else ("fallback_clear" if survey_complete else "source_local")
            target_id = str(station_index) if station_index is not None else str(event.action.channel)
            task_reason = {"CERT_ROUTE": "cert_d_station_scan", "ROUTE_RECONNECTION": "resume_cert_d_station_scan",
                           "SECOND_BEARING": "fast_c_second_bearing", "LOCALIZATION_RECOVERY": "fast_c_alternate_bearing",
                           "CLEAR_APPROACH": "fast_c_clear_attempt", "CLEAR_RETRY": "post_failed_clear_retry",
                           "FALLBACK": "anchor_wedge_certified_clear", "FINAL_CERTIFICATE": "post_last_clear_certificate_completion"}[category]
            segments.append(MovementSegment(
                case_id, event_index, virtual_time, virtual_time + event.delta_s, position, target,
                event.movement_m, event.delta_s, current_channel, event.action.channel, before_state,
                after_state, category, secondary, source, target_type, target_id, station_index, task_reason,
                "cert_d_rolling_open", route_index,
            ))
        if station_index is not None and event.action.kind == "measure":
            route_index = station_index
            if station_index == len(route) - 1:
                survey_complete = True
            if in_source_handling:
                in_source_handling = False
        elif not survey_complete and station_index is None and event.movement_m > 1e-12:
            in_source_handling = True
        if event.action.kind == "clear":
            if event.result == "success":
                last_clear_failed.discard(event.action.channel)
            else:
                last_clear_failed.add(event.action.channel)
        position = target
        virtual_time += event.delta_s
        if event.action.kind == "measure":
            current_channel = event.action.channel
    total = sum(event.movement_m for event in items)
    traced = sum(segment.distance_m for segment in segments)
    return MovementLedger(tuple(segments), total, traced, abs(total - traced) <= max(1e-6, 1e-6 * total))
