"""Conservative arithmetic for Route-Aware Deferred Clear replays only."""
from __future__ import annotations

from dataclasses import dataclass

from b_problem.strategy.q4 import Point


@dataclass(frozen=True)
class DetourCounterfactual:
    immediate_detour_m: float
    best_defer_detour_m: float
    avoidable_detour_m: float


def insertion_detour(start: Point, end: Point, clear_point: Point) -> float:
    """Exact additional distance for inserting a clear candidate in one base edge."""
    return start.distance_to(clear_point) + clear_point.distance_to(end) - start.distance_to(end)


def counterfactual_avoidable_detour(
    *, immediate_segment_m: float, base_direct_m: float, future_insertion_costs_m: tuple[float, ...]
) -> DetourCounterfactual:
    """Compare observed interruption surplus against the best future insertion.

    This uses only action-trace geometry and a successful historic clear point;
    it is not an online decision rule and does not expose benchmark truth.
    """
    if immediate_segment_m < 0.0 or base_direct_m < 0.0 or not future_insertion_costs_m:
        raise ValueError("counterfactual distances must be non-negative and non-empty")
    if any(value < 0.0 for value in future_insertion_costs_m):
        raise ValueError("future insertion costs must be non-negative")
    immediate = max(0.0, immediate_segment_m - base_direct_m)
    deferred = min(future_insertion_costs_m)
    return DetourCounterfactual(immediate, deferred, max(0.0, immediate - deferred))
