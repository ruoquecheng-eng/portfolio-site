"""Finite, fail-closed certificate for the 21-point Q4 discovery candidate.

This is diagnostic geometry only; no strategy imports this module.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations
from math import cos, hypot, pi, sin

from b_problem.strategy.q4 import Point

_EPS = 1e-8


@dataclass(frozen=True)
class Certificate21:
    certified: bool
    hull_inradius_m: float
    oriented_pair_checks: int
    worst_receive_radius_m: float


def candidate_21() -> tuple[Point, ...]:
    """Origin, 12 outer sites and 8 inner sites; no expected result is embedded."""
    outer = 1802.0 / cos(pi / 12.0)
    return (Point(0.0, 0.0),
            *(Point(outer * cos(2 * pi * k / 12), outer * sin(2 * pi * k / 12)) for k in range(12)),
            *(Point(997.32 * cos(2 * pi * k / 8), 997.32 * sin(2 * pi * k / 8)) for k in range(8)))


def _cross(a: Point, b: Point, c: Point) -> float:
    return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)


def _hull(points: tuple[Point, ...]) -> tuple[Point, ...]:
    ordered = sorted(set(points))
    lower: list[Point] = []
    for point in ordered:
        while len(lower) >= 2 and _cross(lower[-2], lower[-1], point) <= 0: lower.pop()
        lower.append(point)
    upper: list[Point] = []
    for point in reversed(ordered):
        while len(upper) >= 2 and _cross(upper[-2], upper[-1], point) <= 0: upper.pop()
        upper.append(point)
    return tuple(lower[:-1] + upper[:-1])


def _clip(poly: tuple[Point, ...], nx: float, ny: float, bound: float) -> tuple[Point, ...]:
    out: list[Point] = []
    if not poly: return ()
    previous = poly[-1]; fp = nx*previous.x + ny*previous.y - bound
    for point in poly:
        fc = nx*point.x + ny*point.y-bound
        if (fp <= 0) != (fc <= 0):
            t = fp/(fp-fc); out.append(Point(previous.x+t*(point.x-previous.x), previous.y+t*(point.y-previous.y)))
        if fc <= _EPS: out.append(point)
        previous, fp = point, fc
    return tuple(out)


def _max_cell_radius(sites: tuple[Point, ...], nx: float, ny: float, offset: float, disk_r: float) -> float:
    # The pair support half-plane clipped to the source disk is partitioned by
    # Voronoi cells. Candidate extrema are cell vertices and edge/circle hits.
    base = _clip((Point(-disk_r,-disk_r), Point(disk_r,-disk_r), Point(disk_r,disk_r), Point(-disk_r,disk_r)), -nx, -ny, -offset)
    worst = 0.0
    for site in sites:
        cell = base
        for other in sites:
            if other == site: continue
            dx, dy = other.x-site.x, other.y-site.y
            cell = _clip(cell, dx, dy, (dx*(other.x+site.x)+dy*(other.y+site.y))/2.0)
            if not cell: break
        candidates = [p for p in cell if p.radius() <= disk_r+_EPS]
        for a, b in zip(cell, cell[1:]+cell[:1]):
            dx, dy = b.x-a.x, b.y-a.y; length2 = dx*dx+dy*dy
            if length2 <= _EPS: continue
            t0 = -(a.x*dx+a.y*dy)/length2; discriminant = disk_r*disk_r-(a.x+t0*dx)**2-(a.y+t0*dy)**2
            if discriminant >= -_EPS:
                dt = (max(discriminant, 0.0)/length2) ** 0.5
                for t in (t0-dt, t0+dt):
                    if -_EPS <= t <= 1+_EPS: candidates.append(Point(a.x+t*dx, a.y+t*dy))
        if candidates: worst = max(worst, max(site.distance_to(p) for p in candidates))
    return worst


def certify_21(points: tuple[Point, ...] | None = None, *, target_radius_m: float = 1800.0, receive_radius_m: float = 1000.0) -> Certificate21:
    points = candidate_21() if points is None else tuple(points)
    hull = _hull(points)
    inradius = min(abs(a.x*b.y-a.y*b.x)/a.distance_to(b) for a, b in zip(hull, hull[1:]+hull[:1]))
    worst, checks = 0.0, 0
    for a, b in permutations(points, 2):
        dx, dy = b.x-a.x, b.y-a.y; length = hypot(dx, dy)
        if length <= _EPS: continue
        nx, ny = -dy/length, dx/length; offset = nx*a.x+ny*a.y
        if offset >= target_radius_m: continue
        sites = tuple(p for p in points if nx*p.x+ny*p.y > offset+_EPS)
        worst = max(worst, _max_cell_radius(sites, nx, ny, offset, target_radius_m)); checks += 1
    return Certificate21(inradius > target_radius_m+_EPS and worst < receive_radius_m-_EPS, inradius, checks, worst)
