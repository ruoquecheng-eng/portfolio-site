"""Standalone mathematical certificate experiments; never strategy entry points."""
