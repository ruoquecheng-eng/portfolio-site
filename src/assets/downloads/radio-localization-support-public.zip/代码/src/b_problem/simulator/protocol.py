from __future__ import annotations

from dataclasses import dataclass
import math
import unicodedata


class ProtocolError(RuntimeError):
    pass


def validate_utf8_identifier(value: object, *, field: str, maximum_bytes: int) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    try:
        encoded = value.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise ValueError(f"{field} must be UTF-8 encodable") from exc
    if not 1 <= len(encoded) <= maximum_bytes:
        raise ValueError(f"{field} must use 1..{maximum_bytes} UTF-8 bytes")
    if any(unicodedata.category(character) in {"Cc", "Cf"} for character in value):
        raise ValueError(f"{field} must not contain Unicode control or format characters")
    return value


@dataclass(frozen=True)
class Point:
    x: float
    y: float

    def __post_init__(self) -> None:
        if not all(
            isinstance(value, (int, float))
            and not isinstance(value, bool)
            and math.isfinite(value)
            and abs(value) <= 2_000_000
            for value in (self.x, self.y)
        ):
            raise ValueError("position must be finite and within 2,000,000 m")


@dataclass(frozen=True)
class SessionState:
    phase: str = "new"
    position: Point = Point(0.0, 0.0)
    measure_channel: int = 1
    virtual_time_s: float = 0.0


@dataclass(frozen=True)
class EnterResponse:
    virtual_time_s: float
    remaining_real_duration_s: int
    accepted: bool = True


@dataclass(frozen=True)
class MeasureResponse:
    virtual_time_s: float
    measure_result: str
    svd_deg: float | None
    accepted: bool = True


@dataclass(frozen=True)
class ClearResponse:
    virtual_time_s: float
    clear_result: str
    accepted: bool = True


@dataclass(frozen=True)
class ExitResponse:
    virtual_time_s: float
    exit_reason: str
    accepted: bool = True


def validate_channel(channel: int) -> None:
    if isinstance(channel, bool) or not isinstance(channel, int) or not 1 <= channel <= 20:
        raise ValueError("channel must be an integer from 1 through 20")


def validate_response(payload: object) -> dict:
    if not isinstance(payload, dict):
        raise ProtocolError("response must be a JSON object")
    if not isinstance(payload.get("accepted"), bool):
        raise ProtocolError("response missing boolean accepted")
    for field in ("real_timestamp_ms", "virtual_time_s"):
        value = payload.get(field)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ProtocolError(f"response missing finite {field}")
    return payload
