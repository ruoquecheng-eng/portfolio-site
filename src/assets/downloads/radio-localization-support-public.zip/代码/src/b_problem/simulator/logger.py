from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


DEFAULT_LOCAL_LOG_BYTES = 8 * 1024 * 1024
OFFICIAL_ENCRYPTED_LOG_LIMIT_BYTES = 2 * 1024 * 1024
WORST_OFFLINE_ACTIONS = 4_159
ESTIMATED_ATTEMPT_BYTES = 512


class JsonlLogger:
    """Small local audit logger; it never writes a robot id verbatim."""

    def __init__(self, path: Path, max_bytes: int = DEFAULT_LOCAL_LOG_BYTES) -> None:
        self._path = path
        self._max_bytes = max_bytes
        self._written = 0
        self._file = path.open("w", encoding="utf-8")

    def preflight_offline_capacity(self, action_count: int = WORST_OFFLINE_ACTIONS) -> dict[str, int | bool]:
        if isinstance(action_count, bool) or not isinstance(action_count, int) or action_count < 0:
            raise ValueError("action_count must be a non-negative integer")
        estimated = action_count * ESTIMATED_ATTEMPT_BYTES
        return {
            "action_count": action_count,
            "estimated_local_bytes": estimated,
            "local_capacity_bytes": self._max_bytes,
            "local_capacity_ok": estimated <= self._max_bytes,
            "official_encrypted_limit_bytes": OFFICIAL_ENCRYPTED_LOG_LIMIT_BYTES,
            "official_export_preflight_required": True,
        }

    def record(self, *, path: str, request_id: str, robot_id: str, status: int | None,
               accepted: bool | None, response: object | None, outcome: str,
               request: dict[str, Any]) -> None:
        event = {
            "path": path,
            "request_id": request_id,
            "robot_id_hash": hashlib.sha256(robot_id.encode("utf-8")).hexdigest()[:16],
            "status": status,
            "accepted": accepted,
            "outcome": outcome,
            "request": self._redact_request(request, robot_id),
            "response": self._redact(response, robot_id),
        }
        encoded = (json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        if self._written + len(encoded) > self._max_bytes:
            raise RuntimeError("local audit log size limit reached")
        self._file.write(encoded.decode("utf-8"))
        self._file.flush()
        self._written += len(encoded)

    @staticmethod
    def _redact(value: object, robot_id: str) -> object:
        if value == robot_id:
            return "[redacted]"
        if isinstance(value, dict):
            return {key: JsonlLogger._redact(item, robot_id) for key, item in value.items()}
        if isinstance(value, list):
            return [JsonlLogger._redact(item, robot_id) for item in value]
        return value

    @staticmethod
    def _redact_request(value: dict[str, Any], robot_id: str) -> dict[str, Any]:
        return {
            "arena_id": value.get("arena_id"),
            "robot_id_hash": hashlib.sha256(robot_id.encode("utf-8")).hexdigest()[:16],
            "request_id": value.get("request_id"),
            "position": value.get("position"),
            "channel": value.get("channel"),
            "body_sha256": value.get("body_sha256"),
        }

    def close(self) -> None:
        self._file.close()
