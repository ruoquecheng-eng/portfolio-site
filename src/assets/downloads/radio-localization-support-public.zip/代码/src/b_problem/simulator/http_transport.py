from __future__ import annotations

import json
import socket
from typing import Any, Callable
from urllib import error, request

from .client import ConnectionClosed, ConnectionRefused, TransportTimeout
from .protocol import ProtocolError


_PATHS = {"/enter", "/measure", "/clear", "/exit"}


class HttpJsonTransport:
    """Loopback-only JSON transport; callers may inject an opener for tests."""

    is_official_live_transport = True

    def __init__(self, port: int, *, timeout_s: float = 10.0,
                 opener: Callable[..., Any] | None = None) -> None:
        if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
            raise ValueError("port must be an integer in 1..65535")
        if isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float)) or timeout_s <= 0:
            raise ValueError("timeout_s must be positive")
        self.port = port
        self.timeout_s = float(timeout_s)
        self._opener = opener or request.urlopen

    def post(self, path: str, body: bytes, *, timeout_s: float | None = None) -> tuple[int, object]:
        if path not in _PATHS:
            raise ValueError("unsupported simulator path")
        if not isinstance(body, bytes):
            raise ValueError("HTTP transport requires an exact bytes body")
        if timeout_s is not None and (isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float)) or timeout_s <= 0):
            raise ValueError("per-attempt timeout_s must be positive")
        try:
            decoded_request = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("HTTP transport requires a UTF-8 JSON body") from exc
        if not isinstance(decoded_request, dict):
            raise ValueError("HTTP transport requires a JSON object body")
        outgoing = request.Request(
            f"http://127.0.0.1:{self.port}{path}", data=body, method="POST",
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        try:
            response = self._opener(outgoing, timeout=min(self.timeout_s, float(timeout_s)) if timeout_s is not None else self.timeout_s)
            return self._read_response(response)
        except error.HTTPError as exc:
            return int(exc.code), self._read_error_body(exc)
        except (socket.timeout, TimeoutError) as exc:
            raise TransportTimeout("HTTP transport timed out") from exc
        except ConnectionRefusedError as exc:
            raise ConnectionRefused("HTTP connection refused") from exc
        except (ConnectionResetError, BrokenPipeError) as exc:
            raise ConnectionClosed("HTTP connection closed") from exc
        except error.URLError as exc:
            self._raise_url_error(exc)

    @staticmethod
    def _read_response(response: Any) -> tuple[int, object]:
        try:
            status_value = getattr(response, "status", None)
            status = int(response.getcode() if status_value is None else status_value)
            raw = response.read()
        finally:
            close = getattr(response, "close", None)
            if close is not None:
                close()
        return status, HttpJsonTransport._decode_response(raw)

    @staticmethod
    def _read_error_body(response: Any) -> object:
        try:
            return HttpJsonTransport._decode_response(response.read())
        except ProtocolError:
            return {}
        finally:
            close = getattr(response, "close", None)
            if close is not None:
                close()

    @staticmethod
    def _decode_response(raw: object) -> object:
        if not isinstance(raw, bytes):
            raise ProtocolError("HTTP response body must be bytes")
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ProtocolError("HTTP response body must be UTF-8 JSON") from exc

    @staticmethod
    def _raise_url_error(exc: error.URLError) -> None:
        reason = exc.reason
        if isinstance(reason, (socket.timeout, TimeoutError)):
            raise TransportTimeout("HTTP transport timed out") from exc
        if isinstance(reason, ConnectionRefusedError):
            raise ConnectionRefused("HTTP connection refused") from exc
        if isinstance(reason, (ConnectionResetError, BrokenPipeError)):
            raise ConnectionClosed("HTTP connection closed") from exc
        raise ConnectionClosed("HTTP connection failed") from exc
