from __future__ import annotations

from dataclasses import replace
from contextlib import contextmanager
import hashlib
import json
import math
import threading
import time
from typing import Callable, Protocol

from .config import SimulatorConfig, SimulatorMode
from .logger import JsonlLogger
from .protocol import (
    ClearResponse, EnterResponse, ExitResponse, MeasureResponse, Point, ProtocolError,
    SessionState, validate_channel, validate_response, validate_utf8_identifier,
)


class TransportTimeout(RuntimeError):
    pass


class ConnectionClosed(RuntimeError):
    pass


class ConnectionRefused(RuntimeError):
    pass


class HttpStatusError(RuntimeError):
    pass


class ActionRejected(RuntimeError):
    pass


class Transport(Protocol):
    def post(self, path: str, body: bytes) -> tuple[int, object]: ...


class SimulatorClient:
    """Serial protocol client. Its transport is injected; it never opens a socket."""

    def __init__(self, transport: Transport, robot_id: str, *, arena_id: str = "default",
                  request_id_factory: Callable[[], str] | None = None,
                  logger: JsonlLogger | None = None,
                  mode: SimulatorMode = SimulatorMode.OFFLINE,
                  _validated_live_config: bool = False,
                  clock: Callable[[], float] = time.monotonic,
                  sleeper: Callable[[float], None] = time.sleep) -> None:
        validate_utf8_identifier(robot_id, field="robot_id", maximum_bytes=64)
        if arena_id != "default":
            raise ValueError("arena_id must be exactly ASCII default")
        if getattr(transport, "is_official_live_transport", False) and not _validated_live_config:
            raise ValueError("official HTTP transport requires validated live configuration")
        if mode is not SimulatorMode.OFFLINE and not _validated_live_config:
            raise ValueError("practice and formal modes require SimulatorClient.from_config")
        self._transport = transport
        self._robot_id = robot_id
        self._arena_id = arena_id
        self._ids = request_id_factory or self._default_id_factory()
        self._logger = logger
        self.mode = mode
        self._clock = clock
        self._sleeper = sleeper
        self._deadline: float | None = None
        self._reserve_s = 0.0
        self._lock = threading.Lock()
        self.state = SessionState()

    @classmethod
    def from_config(cls, transport: Transport, config: SimulatorConfig, *, arena_id: str = "default",
                    request_id_factory: Callable[[], str] | None = None,
                    logger: JsonlLogger | None = None,
                    clock: Callable[[], float] = time.monotonic,
                    sleeper: Callable[[float], None] = time.sleep) -> "SimulatorClient":
        """Build an injected-transport client only after mode authorization validates."""
        if not isinstance(config, SimulatorConfig):
            raise ValueError("config must be a SimulatorConfig")
        config.validate()
        robot_id = config.robot_id if config.mode is not SimulatorMode.OFFLINE else (config.robot_id or "offline")
        return cls(
            transport,
            robot_id,
            arena_id=arena_id,
            request_id_factory=request_id_factory,
            logger=logger,
            mode=config.mode,
            _validated_live_config=True,
            clock=clock,
            sleeper=sleeper,
        )

    @staticmethod
    def _default_id_factory() -> Callable[[], str]:
        counter = 0
        def next_id() -> str:
            nonlocal counter
            counter += 1
            return f"action-{counter}"
        return next_id

    def set_real_time_deadline(self, *, deadline: float, reserve_s: float) -> None:
        if isinstance(deadline, bool) or not isinstance(deadline, (int, float)):
            raise ValueError("deadline must be a number")
        if isinstance(reserve_s, bool) or not isinstance(reserve_s, (int, float)) or reserve_s < 0:
            raise ValueError("reserve_s must be a non-negative number")
        self._deadline = float(deadline)
        self._reserve_s = float(reserve_s)

    def enter(self) -> EnterResponse:
        with self._serialized():
            if self.state.phase != "new":
                raise RuntimeError("enter is only valid for a new client")
            _, response = self._execute_locked("/enter", {})
            try:
                remaining = response.get("remaining_real_duration_s")
                if not isinstance(remaining, int) or isinstance(remaining, bool) or not 0 <= remaining <= 1200:
                    raise ProtocolError("invalid enter remaining_real_duration_s")
                virtual = self._validated_virtual_time(response)
            except ProtocolError:
                self._desynchronize(response)
                raise
            self.state = SessionState("active", Point(0.0, 0.0), 1, virtual)
            return EnterResponse(virtual, remaining)

    def measure(self, position: Point, channel: int) -> MeasureResponse:
        validate_channel(channel)
        with self._serialized():
            self._require_active()
            _, response = self._execute_locked("/measure", {"position": self._point(position), "channel": channel})
            try:
                result = response.get("measure_result")
                if result not in {"no_signal", "near", "direction"}:
                    raise ProtocolError("invalid measure_result")
                svd = response.get("svd_deg")
                if result == "direction":
                    if isinstance(svd, bool) or not isinstance(svd, (int, float)) or not math.isfinite(svd) or not 0 <= svd < 360:
                        raise ProtocolError("direction result needs normalized svd_deg")
                    svd_value: float | None = float(svd)
                else:
                    if svd is not None:
                        raise ProtocolError("non-direction result must not include svd_deg")
                    svd_value = None
                virtual = self._validated_virtual_time(response)
            except ProtocolError:
                self._desynchronize(response)
                raise
            self.state = replace(self.state, position=position, measure_channel=channel, virtual_time_s=virtual)
            return MeasureResponse(virtual, result, svd_value)

    def clear(self, position: Point, channel: int) -> ClearResponse:
        validate_channel(channel)
        with self._serialized():
            self._require_active()
            _, response = self._execute_locked("/clear", {"position": self._point(position), "channel": channel})
            try:
                result = response.get("clear_result")
                if result not in {"success", "no_target_in_range"}:
                    raise ProtocolError("invalid clear_result")
                virtual = self._validated_virtual_time(response)
            except ProtocolError:
                self._desynchronize(response)
                raise
            self.state = replace(self.state, position=position, virtual_time_s=virtual)
            return ClearResponse(virtual, result)

    def exit(self) -> ExitResponse:
        with self._serialized():
            self._require_active()
            _, response = self._execute_locked("/exit", {})
            try:
                if response.get("exit_reason") != "user_exit":
                    raise ProtocolError("invalid exit_reason")
                virtual = self._validated_virtual_time(response)
            except ProtocolError:
                self._desynchronize(response)
                raise
            self.state = replace(self.state, phase="closed", virtual_time_s=virtual)
            return ExitResponse(virtual, "user_exit")

    @staticmethod
    def _point(point: Point) -> dict[str, float]:
        return {"x": point.x, "y": point.y}

    def _require_active(self) -> None:
        if self.state.phase == "desynchronized":
            raise RuntimeError("client is desynchronized")
        if self.state.phase != "active":
            raise RuntimeError("action requires an active session")

    @contextmanager
    def _serialized(self):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("concurrent new simulator action rejected")
        try:
            yield
        finally:
            self._lock.release()

    def _validated_virtual_time(self, response: dict) -> float:
        virtual = float(response["virtual_time_s"])
        if virtual < 0.0 or virtual < self.state.virtual_time_s:
            raise ProtocolError("virtual_time_s must be non-negative and non-decreasing")
        return virtual

    def _desynchronize(self, response: dict) -> None:
        if response.get("accepted") is True:
            self.state = replace(self.state, phase="desynchronized")

    def _execute_locked(self, path: str, fields: dict) -> tuple[bytes, dict]:
        request_id = self._ids()
        validate_utf8_identifier(request_id, field="request_id", maximum_bytes=128)
        payload = {"arena_id": self._arena_id, "robot_id": self._robot_id,
                   "request_id": request_id, **fields}
        body = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        audit_request = {
            "arena_id": self._arena_id,
            "request_id": request_id,
            "position": fields.get("position"),
            "channel": fields.get("channel"),
            "body_sha256": hashlib.sha256(body).hexdigest(),
        }
        for attempt in range(4):
            try:
                status, raw_response = self._post_with_remaining_timeout(path, body)
            except (TransportTimeout, ConnectionClosed, ConnectionRefused) as exc:
                self._log_attempt(path, request_id, None, None, None, self._transport_outcome(exc), audit_request)
                if self._retry_after_backoff(path, attempt):
                    continue
                raise TransportTimeout("retry budget exhausted") from exc
            try:
                if status != 200:
                    self._log_attempt(path, request_id, status, self._accepted_value(raw_response), raw_response,
                                      "http_retryable" if self._retryable_http_status(status) else "http_error", audit_request)
                    if self._retryable_http_status(status) and self._retry_after_backoff(path, attempt):
                        continue
                    raise HttpStatusError(f"simulator returned HTTP {status}")
                try:
                    response = validate_response(raw_response)
                except ProtocolError:
                    self._log_attempt(path, request_id, status, self._accepted_value(raw_response), raw_response,
                                      "protocol_error", audit_request)
                    if isinstance(raw_response, dict):
                        self._desynchronize(raw_response)
                    raise
                if response["accepted"] is not True:
                    self._log_attempt(path, request_id, status, False, response, "rejected", audit_request)
                    raise ActionRejected("simulator rejected action")
                self._log_attempt(path, request_id, status, True, response, "accepted", audit_request)
                return body, response
            except (HttpStatusError, ProtocolError, ActionRejected):
                raise
        raise TransportTimeout("retry budget exhausted")

    def _post_with_remaining_timeout(self, path: str, body: bytes) -> tuple[int, object]:
        timeout_s = self._remaining_attempt_timeout(path)
        if getattr(self._transport, "is_official_live_transport", False) and timeout_s is not None:
            return self._transport.post(path, body, timeout_s=timeout_s)
        return self._transport.post(path, body)

    def _remaining_attempt_timeout(self, path: str) -> float | None:
        if self._deadline is None:
            return None
        reserve_s = 0.0 if path == "/exit" else self._reserve_s
        timeout_s = self._deadline - self._clock() - reserve_s
        if timeout_s <= 0.0:
            raise TransportTimeout("real-time action budget exhausted")
        return timeout_s

    def _retry_after_backoff(self, path: str, attempt: int) -> bool:
        if attempt >= 3:
            return False
        delay_s = 0.05
        if self._deadline is not None:
            reserve_s = 0.0 if path == "/exit" else self._reserve_s
            if self._clock() + delay_s + reserve_s >= self._deadline:
                return False
        self._sleeper(delay_s)
        return True

    @staticmethod
    def _retryable_http_status(status: int) -> bool:
        return status in {409, 429} or 500 <= status <= 599

    def _log_attempt(self, path: str, request_id: str, status: int | None, accepted: bool | None,
                     response: object | None, outcome: str, request: dict) -> None:
        if self._logger:
            self._logger.record(path=path, request_id=request_id, robot_id=self._robot_id,
                                status=status, accepted=accepted, response=response, outcome=outcome,
                                request=request)

    @staticmethod
    def _accepted_value(response: object) -> bool | None:
        return response.get("accepted") if isinstance(response, dict) and isinstance(response.get("accepted"), bool) else None

    @staticmethod
    def _transport_outcome(exc: BaseException) -> str:
        if isinstance(exc, TransportTimeout):
            return "transport_timeout"
        if isinstance(exc, ConnectionRefused):
            return "connection_refused"
        return "connection_closed"
