from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from enum import Enum
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Callable

from .client import SimulatorClient, Transport
from .config import SimulatorConfig, SimulatorMode
from .logger import JsonlLogger


class RealTimeBudgetExceeded(RuntimeError):
    """Raised before a new action when the official real-time reserve is reached."""


class DeadlineRobot:
    """Strategy-facing client wrapper that checks the /enter wall-time budget."""

    def __init__(self, client: SimulatorClient, *, deadline: float,
                 clock: Callable[[], float], reserve_s: float) -> None:
        self._client = client
        self._deadline = deadline
        self._clock = clock
        self._reserve_s = reserve_s

    @property
    def state(self):
        return self._client.state

    def _check(self) -> None:
        if self._clock() + self._reserve_s >= self._deadline:
            raise RealTimeBudgetExceeded("official real-time safety reserve reached")

    def measure(self, position, channel):
        self._check()
        return self._client.measure(position, channel)

    def clear(self, position, channel):
        self._check()
        return self._client.clear(position, channel)


@dataclass(frozen=True)
class SessionRunResult:
    mode: SimulatorMode
    complete: bool
    exit_reason: str
    virtual_time_s: float
    wall_time_s: float
    remaining_real_duration_s: int
    log_size_bytes: int
    attempt_count: int


def _json_safe(value: Any) -> Any:
    if is_dataclass(value):
        return _json_safe(asdict(value))
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)


def _complete(result: Any) -> bool:
    if isinstance(result, dict):
        return result.get("complete") is True
    return getattr(result, "complete", False) is True


def run_validated_session(
    config: SimulatorConfig,
    *,
    log_path: Path,
    summary_path: Path,
    transport: Transport | None = None,
    q3_strategy: Callable[[Any, Any], Any] | None = None,
    q4_strategy: Callable[[Any, Any], Any] | None = None,
    clock: Callable[[], float] = time.monotonic,
    reserve_s: float = 5.0,
) -> SessionRunResult:
    """Run one validated live session; tests inject transport and perform no I/O."""
    config.validate()
    if config.mode is SimulatorMode.OFFLINE:
        raise ValueError("OFFLINE mode cannot start a live session")
    if isinstance(reserve_s, bool) or not isinstance(reserve_s, (int, float)) or reserve_s < 0.0:
        raise ValueError("reserve_s must be a non-negative number")
    if log_path == summary_path:
        raise ValueError("log_path and summary_path must be different")
    existing_outputs = [path for path in (log_path, summary_path) if path.exists()]
    if existing_outputs:
        names = ", ".join(str(path) for path in existing_outputs)
        raise FileExistsError(f"refusing to overwrite practice output: {names}")

    if q3_strategy is None or q4_strategy is None:
        from b_problem.strategy.q3 import execute_q3_strategy
        from b_problem.strategy.q4 import execute_q4_strategy
        q3_strategy = q3_strategy or execute_q3_strategy
        q4_strategy = q4_strategy or execute_q4_strategy

    log_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    active_transport = transport if transport is not None else config.build_http_transport()
    logger = JsonlLogger(log_path)
    started = clock()
    client = SimulatorClient.from_config(active_transport, config, logger=logger, clock=clock)
    strategy_result: Any = None
    remaining = 0
    exit_reason = "not_entered"
    deadline: float | None = None
    primary_exception: BaseException | None = None
    cleanup_exception: BaseException | None = None
    try:
        entered = client.enter()
        remaining = entered.remaining_real_duration_s
        deadline = clock() + remaining
        client.set_real_time_deadline(deadline=deadline, reserve_s=float(reserve_s))
        robot = DeadlineRobot(client, deadline=deadline, clock=clock, reserve_s=float(reserve_s))
        strategy = q3_strategy if config.mode in {SimulatorMode.PRACTICE_Q3, SimulatorMode.FORMAL_Q3} else q4_strategy
        try:
            strategy_result = strategy(robot, robot.state)
        except RealTimeBudgetExceeded:
            exit_reason = "real_time_guard"
    except BaseException as exc:
        primary_exception = exc
        raise
    finally:
        if client.state.phase == "active" and (deadline is None or clock() < deadline):
            try:
                exit_reason = client.exit().exit_reason
            except BaseException as exc:
                if primary_exception is None and exit_reason != "real_time_guard":
                    cleanup_exception = exc
        wall_time = max(0.0, clock() - started)
        complete = _complete(strategy_result)
        logger.close()
        log_size_bytes = log_path.stat().st_size
        attempt_count = sum(1 for line in log_path.read_text(encoding="utf-8").splitlines() if line)
        summary = {
            "mode": config.mode.value,
            "robot_id_hash": hashlib.sha256(config.robot_id.encode("utf-8")).hexdigest()[:16],
            "complete": complete,
            "exit_reason": exit_reason,
            "virtual_time_s": client.state.virtual_time_s,
            "wall_time_s": wall_time,
            "remaining_real_duration_s": remaining,
            "log_size_bytes": log_size_bytes,
            "attempt_count": attempt_count,
            "strategy_state": _json_safe(strategy_result),
        }
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        if cleanup_exception is not None:
            raise cleanup_exception

    return SessionRunResult(
        mode=config.mode,
        complete=complete,
        exit_reason=exit_reason,
        virtual_time_s=client.state.virtual_time_s,
        wall_time_s=wall_time,
        remaining_real_duration_s=remaining,
        log_size_bytes=log_size_bytes,
        attempt_count=attempt_count,
    )
