from __future__ import annotations

from dataclasses import dataclass
import json
import math
import threading
import time
from typing import Any, Callable

from .client import ConnectionClosed, TransportTimeout
from .protocol import Point


@dataclass
class MockTarget:
    channel: int
    position: Point
    receive_radius: float = 1000.0
    cleared: bool = False


class MockServer:
    """In-process protocol model for tests; it owns no socket."""

    def __init__(self, robot_id: str, targets: tuple[MockTarget, ...] = (), *,
                 max_virtual_duration_s: float = 360_000.0, max_real_duration_s: float = 1_200.0,
                 max_actions: int = 100_000, clock: Callable[[], float] = time.monotonic) -> None:
        if max_virtual_duration_s < 0.0 or max_real_duration_s < 0.0 or max_actions < 1:
            raise ValueError("mock budgets must be non-negative with at least one action")
        self.robot_id = robot_id
        self.targets = {target.channel: target for target in targets}
        self.entered = False
        self.closed = False
        self.position = Point(0.0, 0.0)
        self.measure_channel = 1
        self.virtual_time_s = 0.0
        self.ledger: dict[str, tuple[str, bytes, tuple[int, dict[str, Any]]]] = {}
        self.request_ids: list[str] = []
        self.request_bodies: list[bytes] = []
        self.accepted_virtual_times: list[float] = []
        self.accepted_action_count = 0
        self.max_virtual_duration_s = float(max_virtual_duration_s)
        self.max_real_duration_s = float(max_real_duration_s)
        self.max_actions = max_actions
        self._clock = clock
        self._started_at = clock()
        self.reject_next = False
        self.http_error_next: int | None = None
        self.timeout_after_accept_next = False
        self.closed_before_response_next = False
        self.block_next: threading.Event | None = None
        self.started_event: threading.Event | None = None

    def make_body(self, request_id: str, x: float | None = None, y: float | None = None,
                  channel: int | None = None) -> bytes:
        data: dict[str, Any] = {"arena_id": "default", "robot_id": self.robot_id, "request_id": request_id}
        if x is not None:
            data["position"] = {"x": x, "y": y}
            data["channel"] = channel
        return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def post(self, path: str, body: bytes) -> tuple[int, object]:
        try:
            data = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return 400, self._base(False)
        if not self._valid_request(path, data):
            return 400, self._base(False)
        request_id = data.get("request_id", "")
        self.request_ids.append(request_id)
        self.request_bodies.append(body)
        if self.block_next is not None:
            event, self.block_next = self.block_next, None
            if self.started_event:
                self.started_event.set()
            event.wait(2)
        if self.http_error_next is not None:
            code, self.http_error_next = self.http_error_next, None
            return code, self._base(False)
        previous = self.ledger.get(request_id)
        if previous is not None:
            if previous[0] != path or previous[1] != body:
                return 409, self._base(False)
            return previous[2]
        if self.reject_next:
            self.reject_next = False
            return 200, self._base(False)
        if path not in {"/enter", "/measure", "/clear", "/exit"}:
            return 404, self._base(False)
        if data.get("arena_id") != "default" or data.get("robot_id") != self.robot_id:
            return 200, self._base(False)
        if path == "/enter":
            if self.entered or self.closed:
                return 200, self._base(False)
            self.entered = True
            result = (200, {**self._base(True), "max_virtual_duration_s": self.max_virtual_duration_s,
                            "max_real_duration_s": self.max_real_duration_s,
                            "remaining_real_duration_s": self._remaining_real_duration_s()})
        elif not self.entered or self.closed:
            return 200, self._base(False)
        elif not self._can_accept(0.0):
            return 200, self._base(False)
        elif path == "/measure":
            result = self._measure(data)
        elif path == "/clear":
            result = self._clear(data)
        else:
            self.closed = True
            result = (200, {**self._base(True), "exit_reason": "user_exit"})
        self.ledger[request_id] = (path, body, result)
        if result[1]["accepted"]:
            self.accepted_action_count += 1
            self.accepted_virtual_times.append(float(result[1]["virtual_time_s"]))
        if self.timeout_after_accept_next:
            self.timeout_after_accept_next = False
            raise TransportTimeout("injected timeout after action accepted")
        if self.closed_before_response_next:
            self.closed_before_response_next = False
            raise ConnectionClosed("injected closed connection after action accepted")
        return result

    @staticmethod
    def _valid_request(path: str, data: object) -> bool:
        if path not in {"/enter", "/measure", "/clear", "/exit"} or not isinstance(data, dict):
            return False
        common = {"arena_id", "robot_id", "request_id"}
        allowed = common if path in {"/enter", "/exit"} else common | {"position", "channel"}
        if set(data) - allowed or not common <= set(data):
            return False
        if not isinstance(data["arena_id"], str) or not isinstance(data["robot_id"], str):
            return False
        if not isinstance(data["request_id"], str) or not data["request_id"]:
            return False
        if path in {"/enter", "/exit"}:
            return True
        position, channel = data.get("position"), data.get("channel")
        if not isinstance(position, dict) or set(position) != {"x", "y"}:
            return False
        if isinstance(channel, bool) or not isinstance(channel, int) or not 1 <= channel <= 20:
            return False
        return all(isinstance(position[key], (int, float)) and not isinstance(position[key], bool)
                   and math.isfinite(position[key]) and abs(position[key]) <= 2_000_000
                   for key in ("x", "y"))

    def _measure(self, data: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        point, channel = self._action_args(data)
        movement = self._distance(self.position, point)
        delta = movement / 5.0 + (1 if channel != self.measure_channel else 0) + 5
        if not self._can_accept(delta):
            return 200, self._base(False)
        self._move_to(point)
        self.virtual_time_s += (1 if channel != self.measure_channel else 0) + 5
        self.measure_channel = channel
        target = self.targets.get(channel)
        if target is None or target.cleared or self._distance(point, target.position) > target.receive_radius:
            result: dict[str, Any] = {**self._base(True), "measure_result": "no_signal"}
        elif self._distance(point, target.position) <= 5:
            result = {**self._base(True), "measure_result": "near"}
        else:
            angle = math.degrees(math.atan2(target.position.y - point.y, target.position.x - point.x)) % 360
            result = {**self._base(True), "measure_result": "direction", "svd_deg": round(angle, 2)}
        return 200, result

    def _clear(self, data: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        point, channel = self._action_args(data)
        target = self.targets.get(channel)
        success = target is not None and not target.cleared and self._distance(point, target.position) <= 20
        delta = self._distance(self.position, point) / 5.0 + (5 if success else 3)
        if not self._can_accept(delta):
            return 200, self._base(False)
        self._move_to(point)
        self.virtual_time_s += 5 if success else 3
        if success:
            target.cleared = True
        return 200, {**self._base(True), "clear_result": "success" if success else "no_target_in_range"}

    @staticmethod
    def _action_args(data: dict[str, Any]) -> tuple[Point, int]:
        position, channel = data.get("position"), data.get("channel")
        if not isinstance(position, dict) or not isinstance(channel, int) or not 1 <= channel <= 20:
            raise ValueError("mock action must be valid")
        return Point(float(position["x"]), float(position["y"])), channel

    def _move_to(self, point: Point) -> None:
        self.virtual_time_s += self._distance(self.position, point) / 5
        self.position = point

    def _can_accept(self, delta_s: float) -> bool:
        return (
            self.accepted_action_count < self.max_actions
            and self._clock() - self._started_at <= self.max_real_duration_s
            and self.virtual_time_s + delta_s <= self.max_virtual_duration_s
        )

    def _remaining_real_duration_s(self) -> int:
        return max(0, min(int(self.max_real_duration_s - (self._clock() - self._started_at)), int(self.max_real_duration_s)))

    @staticmethod
    def _distance(left: Point, right: Point) -> float:
        return math.hypot(left.x - right.x, left.y - right.y)

    def _base(self, accepted: bool) -> dict[str, Any]:
        return {"accepted": accepted, "real_timestamp_ms": 0, "virtual_time_s": self.virtual_time_s if accepted else 0}
