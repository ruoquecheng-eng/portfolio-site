from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .protocol import validate_utf8_identifier


PRACTICE_READY_TOKEN = "模拟器演练已就绪"
FORMAL_Q3_CONFIRMATION_TOKEN = "允许开始问题3正式测试"
FORMAL_Q4_CONFIRMATION_TOKEN = "允许开始问题4正式测试"


class SimulatorMode(str, Enum):
    OFFLINE = "OFFLINE"
    PRACTICE_Q3 = "PRACTICE_Q3"
    PRACTICE_Q4 = "PRACTICE_Q4"
    FORMAL_Q3 = "FORMAL_Q3"
    FORMAL_Q4 = "FORMAL_Q4"


@dataclass(frozen=True)
class SimulatorConfig:
    mode: SimulatorMode = SimulatorMode.OFFLINE
    robot_id: str | None = None
    port: int | None = None
    ready_signal: str | None = None
    hard_confirmation: str | None = None

    def validate(self) -> None:
        if not isinstance(self.mode, SimulatorMode):
            raise ValueError("mode must be a SimulatorMode")
        if self.robot_id is not None:
            validate_utf8_identifier(self.robot_id, field="robot_id", maximum_bytes=64)
        if self.mode is SimulatorMode.OFFLINE:
            if self.port is not None or self.ready_signal is not None or self.hard_confirmation is not None:
                raise ValueError("offline mode cannot carry live authorization fields")
            return
        if self.robot_id is None:
            raise ValueError("practice and formal modes require robot_id")
        if isinstance(self.port, bool) or not isinstance(self.port, int) or not 1 <= self.port <= 65535:
            raise ValueError("practice and formal modes require a port in 1..65535")
        if self.ready_signal != PRACTICE_READY_TOKEN:
            raise ValueError("practice and formal modes require the exact ready token")
        if self.mode in {SimulatorMode.FORMAL_Q3, SimulatorMode.FORMAL_Q4}:
            required = (FORMAL_Q3_CONFIRMATION_TOKEN if self.mode is SimulatorMode.FORMAL_Q3
                        else FORMAL_Q4_CONFIRMATION_TOKEN)
            if self.hard_confirmation != required:
                raise ValueError("formal mode requires its exact hard confirmation token")

    def build_http_transport(self, *, timeout_s: float = 10.0, opener=None):
        """Return a loopback-only transport bound to this validated live-mode port."""
        self.validate()
        if self.mode is SimulatorMode.OFFLINE:
            raise ValueError("offline mode has no HTTP transport")
        from .http_transport import HttpJsonTransport
        return HttpJsonTransport(self.port, timeout_s=timeout_s, opener=opener)
