"""Offline-safe simulator protocol client and mock."""
