"""Future-only BATCR / GTSP-lite routing for grouped Q4 clear representatives.

This module deliberately has no strategy entry point. It plans metadata-rich
clear tours for a future integration without changing CERT-D or CP08.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import inf
from typing import Iterable

from .q4 import Point


@dataclass(frozen=True)
class ClearRepresentative:
    channel: int
    candidate_id: str
    point: Point
    reason: str
    state: str


@dataclass(frozen=True)
class ClearSourceCluster:
    channel: int
    candidates: tuple[ClearRepresentative, ...]

    def __post_init__(self) -> None:
        if not 2 <= len(self.candidates) <= 5:
            raise ValueError("a clear-source cluster needs two through five representatives")
        if any(candidate.channel != self.channel for candidate in self.candidates):
            raise ValueError("every representative must preserve its source channel")
        if len({candidate.candidate_id for candidate in self.candidates}) != len(self.candidates):
            raise ValueError("representative ids must be unique within a source cluster")


@dataclass(frozen=True)
class BatcrOpenTour:
    greedy_route: tuple[ClearRepresentative, ...]
    nn_route: tuple[ClearRepresentative, ...]
    multi_start_nn_route: tuple[ClearRepresentative, ...]
    two_opt_route: tuple[ClearRepresentative, ...]
    deferred_clusters: tuple[ClearSourceCluster, ...]
    greedy_length_m: float
    nn_length_m: float
    multi_start_nn_length_m: float
    two_opt_length_m: float


def open_insertion_detour(
    previous: Point, following: Point | None, candidate: ClearRepresentative
) -> float:
    """Exact added distance for inserting a task into an open path."""
    if following is None:
        return previous.distance_to(candidate.point)
    return (
        previous.distance_to(candidate.point)
        + candidate.point.distance_to(following)
        - previous.distance_to(following)
    )


def _route_length(start: Point, route: Iterable[ClearRepresentative]) -> float:
    current = start
    total = 0.0
    for task in route:
        total += current.distance_to(task.point)
        current = task.point
    return total


def _best_insertion(
    start: Point, route: tuple[ClearRepresentative, ...], cluster: ClearSourceCluster
) -> tuple[float, int, ClearRepresentative]:
    best = (inf, 0, cluster.candidates[0])
    for index in range(len(route) + 1):
        previous = start if index == 0 else route[index - 1].point
        following = None if index == len(route) else route[index].point
        for candidate in cluster.candidates:
            proposal = (open_insertion_detour(previous, following, candidate), index, candidate)
            if (proposal[0], candidate.channel, candidate.candidate_id, candidate.point.x, candidate.point.y) < (
                best[0], best[2].channel, best[2].candidate_id, best[2].point.x, best[2].point.y
            ):
                best = proposal
    return best


def _nearest_neighbor(start: Point, tasks: Iterable[ClearRepresentative]) -> tuple[ClearRepresentative, ...]:
    remaining = list(tasks)
    current = start
    route: list[ClearRepresentative] = []
    while remaining:
        index, task = min(
            enumerate(remaining),
            key=lambda item: (
                current.distance_to(item[1].point), item[1].channel, item[1].candidate_id,
            ),
        )
        route.append(task)
        current = task.point
        remaining.pop(index)
    return tuple(route)


def _multi_start_nn(start: Point, tasks: tuple[ClearRepresentative, ...]) -> tuple[ClearRepresentative, ...]:
    if not tasks:
        return ()
    candidates = [_nearest_neighbor(start, tasks)]
    for first in tasks:
        candidates.append((first, *_nearest_neighbor(first.point, (task for task in tasks if task != first))))
    return min(
        candidates,
        key=lambda route: (_route_length(start, route), tuple((task.channel, task.candidate_id) for task in route)),
    )


def _open_two_opt(start: Point, route: Iterable[ClearRepresentative]) -> tuple[ClearRepresentative, ...]:
    best = tuple(route)
    best_length = _route_length(start, best)
    improved = True
    while improved:
        improved = False
        for first in range(len(best) - 1):
            for last in range(first + 1, len(best)):
                candidate = (*best[:first], *reversed(best[first:last + 1]), *best[last + 1:])
                candidate_length = _route_length(start, candidate)
                if candidate_length + 1e-9 < best_length:
                    best, best_length, improved = candidate, candidate_length, True
                    break
            if improved:
                break
    return best


def plan_batcr_open_tour(
    start: Point, clusters: Iterable[ClearSourceCluster], *, defer_detour_m: float
) -> BatcrOpenTour:
    """Greedily fuse one representative per source, deferring excessive detours."""
    if defer_detour_m < 0.0:
        raise ValueError("defer_detour_m must be non-negative")
    remaining = list(clusters)
    if len({cluster.channel for cluster in remaining}) != len(remaining):
        raise ValueError("source clusters must have unique channels")
    greedy: list[ClearRepresentative] = []
    deferred: list[ClearSourceCluster] = []
    while remaining:
        proposals = [(*_best_insertion(start, tuple(greedy), cluster), cluster) for cluster in remaining]
        detour, index, representative, cluster = min(
            proposals,
            key=lambda item: (item[0], item[3].channel, item[2].candidate_id),
        )
        remaining.remove(cluster)
        if detour > defer_detour_m:
            deferred.append(cluster)
            continue
        greedy.insert(index, representative)
    greedy_route = tuple(greedy)
    nn_route = _nearest_neighbor(start, greedy_route)
    multi_start = _multi_start_nn(start, greedy_route)
    two_opt = _open_two_opt(start, multi_start)
    return BatcrOpenTour(
        greedy_route=greedy_route,
        nn_route=nn_route,
        multi_start_nn_route=multi_start,
        two_opt_route=two_opt,
        deferred_clusters=tuple(deferred),
        greedy_length_m=_route_length(start, greedy_route),
        nn_length_m=_route_length(start, nn_route),
        multi_start_nn_length_m=_route_length(start, multi_start),
        two_opt_length_m=_route_length(start, two_opt),
    )
