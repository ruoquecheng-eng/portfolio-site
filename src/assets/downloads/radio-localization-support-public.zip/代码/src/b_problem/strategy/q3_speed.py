"""Speed-first, truth-free Q3 architecture ported from public incremental policies.

This module is deliberately feature-flagged.  It uses only public responses;
every experimental clear is accounted for only when the arena confirms it and
any unresolved channel retains the existing anchor-wedge fallback.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from math import atan2, cos, degrees, hypot, pi, radians, sin
from typing import Any, Iterable

from shapely.geometry import Point as SPoint, Polygon
from shapely.ops import nearest_points

from . import q3
from .q4 import Point as Q4Point
from .q4_routingplus import LiveJob
from .q34_receding_horizon import RecedingHorizonPlanner


Point = q3.Point
CHANNELS = q3.CHANNELS
_EPS = 1e-7
def _distance(first: Point, second: Point) -> float: return q3._distance(first, second)
def _radius(point: Point) -> float: return hypot(point.x, point.y)


class SpeedState(str, Enum):
    UNKNOWN = "UNKNOWN"
    PRESENT = "PRESENT"
    CLEARED = "CLEARED"
    ABSENT = "ABSENT"


@dataclass(frozen=True)
class SpeedAction:
    kind: str
    target: Point
    channel: int | None = None
    candidates: tuple[Point, ...] = ()


@dataclass
class SpeedConfig:
    ring_count: int = 9
    ring_radius_m: float = 1700.0
    nonempty_ring_count: int = 6
    nonempty_ring_radius_m: float = 1130.0
    batch_step_m: float = 100.0
    batch_choice: str = "information"
    batch_enabled: bool = True
    angular_neighbors: bool = True
    neighbor_angle_span_deg: float = 40.0
    negative_affine: bool = True
    negative_disks: bool = True
    negative_disk_sides: int = 48
    shallow_lookahead: bool = True
    optical_band: bool = True
    max_probes: int = 5
    clear_attempt_radius_m: float = 70.0
    guaranteed_clear_radius_m: float = 18.0
    probe_widths_m: tuple[float, ...] = (25.0, 75.0, 125.0)
    probe_quantiles: tuple[float, ...] = (0.2, 0.5, 0.8)
    receding_horizon: bool = False
    rh_k: int = 8
    rh_cheap_twoopt: bool = False
    rh_rollout: bool = False


@dataclass
class SpeedSession:
    channel: int
    anchor: Point
    anchor_bearing_deg: float
    positives: list[tuple[Point, float]] = field(default_factory=list)
    negatives: list[Point] = field(default_factory=list)
    probe_count: int = 0
    clear_attempts: set[Point] = field(default_factory=set)
    fallback_attempted: set[Point] = field(default_factory=set)
    fallback: tuple[Point, ...] = ()
    region: Any = None

    def __post_init__(self) -> None:
        if not self.positives:
            self.positives.append((self.anchor, self.anchor_bearing_deg))


@dataclass
class SpeedTelemetry:
    decisions: list[dict] = field(default_factory=list)
    selected: dict[str, int] = field(default_factory=dict)
    batch_moves: int = 0
    piggyback_reads: int = 0
    negative_affine_updates: int = 0
    negative_disk_updates: int = 0
    optical_sweeps: int = 0
    fallback_actions: int = 0
    region_history: list[dict] = field(default_factory=list)
    planner: dict = field(default_factory=dict)


@dataclass(frozen=True)
class SpeedExecutionResult:
    channel_states: dict[int, str]
    complete: bool
    candidate: str
    cp08_fallback_used: bool
    localized_channels: int
    anchor_fallback_channels: int
    telemetry: SpeedTelemetry


def build_ring_family(count: int, radius_m: float) -> tuple[Point, ...]:
    if count < 3 or radius_m <= 0.0:
        raise ValueError("ring count and radius must be positive")
    return (Point(0.0, 0.0),) + tuple(
        Point(radius_m * cos(2.0 * pi * index / count), radius_m * sin(2.0 * pi * index / count))
        for index in range(count)
    )


def regular_ring_coverage_margin(count:int, radius_m:float, *, target_radius_m:float=q3.TARGET_RADIUS,
                                 receive_radius_m:float=q3.RECEIVE_RADIUS_LOWER_BOUND)->float:
    """Exact center-plus-regular-ring Q3 discovery margin.

    In one Voronoi sector, the farthest nearest-station distance occurs at the
    origin/ring bisector or at the target-circle sector midpoint.  The formula
    is the six-ring certificate generalized to any regular count.
    """
    if count<3 or min(radius_m,target_radius_m,receive_radius_m)<=0: raise ValueError("invalid ring geometry")
    half=pi/count; cross=radius_m/(2.0*cos(half))
    boundary=(target_radius_m**2+radius_m**2-2.0*target_radius_m*radius_m*cos(half))**0.5
    worst=max(cross if cross<=target_radius_m else target_radius_m, min(target_radius_m,boundary))
    return receive_radius_m-worst


def affine_negative_halfplane(positive: Point, negative: Point):
    """Return the public necessary inequality |P-g| <= |Q-g|."""
    a = 2.0 * (negative.x - positive.x)
    b = 2.0 * (negative.y - positive.y)
    c = negative.x * negative.x + negative.y * negative.y - positive.x * positive.x - positive.y * positive.y
    return lambda point: a * point.x + b * point.y <= c + _EPS


def _response_result(response: Any) -> str | None:
    if isinstance(response, dict):
        return response.get("result", response.get("measure_result", response.get("clear_result")))
    if isinstance(response, str):
        return response
    return getattr(response, "result", getattr(response, "measure_result", getattr(response, "clear_result", None)))


def _bearing(response: Any) -> float | None:
    value = response.get("svd_deg") if isinstance(response, dict) else getattr(response, "svd_deg", None)
    return float(value) if isinstance(value, (int, float)) else None


def _outer_disk(center: Point, radius: float, sides: int = 96, *, outer: bool = False):
    """Polygonal disk with an explicit outer margin when used as a bound.

    GEOS buffers are inscribed regular polygons.  Intersecting a 1500 m
    direction disk with that polygon can otherwise exclude a legal point on
    the true circular boundary.  Negative disks deliberately retain the
    inscribed form so their subtraction remains conservative.
    """
    segments=max(8,sides//4)
    margin=radius*(1.0/cos(pi/(4.0*segments))-1.0)+1e-6 if outer else 0.0
    return SPoint(center.x, center.y).buffer(radius+margin,quad_segs=segments)


def _wedge(anchor: Point, bearing_deg: float, error_deg: float = 1.001):
    length = 4000.0
    left = radians(bearing_deg - error_deg)
    right = radians(bearing_deg + error_deg)
    return Polygon(((anchor.x, anchor.y), (anchor.x + length * cos(left), anchor.y + length * sin(left)),
                    (anchor.x + length * cos(right), anchor.y + length * sin(right))))


def _halfplane_geometry(positive: Point, negative: Point):
    dx, dy = negative.x - positive.x, negative.y - positive.y
    norm = hypot(dx, dy)
    if norm <= _EPS:
        return _outer_disk(Point(0.0, 0.0), 10000.0)
    # n·x <= c/norm. A finite 10 km strip fully contains the target disk.
    n = (dx / norm, dy / norm)
    c = (negative.x * negative.x + negative.y * negative.y - positive.x * positive.x - positive.y * positive.y) / (2.0 * norm)
    tangent = (-n[1], n[0]); span = 10000.0
    return Polygon(((n[0] * (c - span) - tangent[0] * span, n[1] * (c - span) - tangent[1] * span),
                    (n[0] * (c - span) + tangent[0] * span, n[1] * (c - span) + tangent[1] * span),
                    (n[0] * c + tangent[0] * span, n[1] * c + tangent[1] * span),
                    (n[0] * c - tangent[0] * span, n[1] * c - tangent[1] * span)))


def update_region(session: SpeedSession, config: SpeedConfig, telemetry: SpeedTelemetry | None = None):
    region = _outer_disk(Point(0.0, 0.0), q3.TARGET_RADIUS, outer=True)
    for point, bearing_deg in session.positives:
        region = region.intersection(_wedge(point, bearing_deg)).intersection(_outer_disk(point, 1500.0, outer=True))
    if config.negative_affine:
        for positive, _ in session.positives:
            for negative in session.negatives:
                region = region.intersection(_halfplane_geometry(positive, negative))
                if telemetry is not None:
                    telemetry.negative_affine_updates += 1
    if config.negative_disks:
        # The removed polygon is strictly inside the universally impossible
        # 1000 m disk after a Q3 no-signal observation.
        for negative in session.negatives:
            radius = 999.999 * cos(pi / config.negative_disk_sides)
            region = region.difference(_outer_disk(negative, radius, config.negative_disk_sides))
            if telemetry is not None:
                telemetry.negative_disk_updates += 1
    session.region = region
    if telemetry is not None:
        polygons=(region,) if getattr(region,"geom_type",None)=="Polygon" else tuple(item for item in getattr(region,"geoms",()) if item.geom_type=="Polygon")
        telemetry.region_history.append({"channel":session.channel,"vertices":[(point.x,point.y) for point in _vertices(region)],
                                         "components":[list(item.exterior.coords) for item in polygons],
                                         "positives":[(point.x,point.y,bearing) for point,bearing in session.positives],
                                         "negatives":[(point.x,point.y) for point in session.negatives]})
    return region


def _vertices(region: Any) -> tuple[Point, ...]:
    if region is None or region.is_empty:
        return ()
    if region.geom_type == "Polygon":
        return tuple(Point(float(x), float(y)) for x, y in tuple(region.exterior.coords)[:-1])
    polygons = [item for item in getattr(region, "geoms", ()) if item.geom_type == "Polygon"]
    if not polygons:
        return ()
    polygon = max(polygons, key=lambda item: item.area)
    return tuple(Point(float(x), float(y)) for x, y in tuple(polygon.exterior.coords)[:-1])


def _region_center(region: Any) -> Point:
    point = region.representative_point() if region is not None and not region.is_empty else SPoint(0.0, 0.0)
    return Point(float(point.x), float(point.y))


def _region_radius(region: Any, center: Point) -> float:
    return max((_distance(center, vertex) for vertex in _vertices(region)), default=float("inf"))


def _step(point: Point, bearing_deg: float, distance_m: float) -> Point:
    theta = radians(bearing_deg)
    return Point(point.x + distance_m * cos(theta), point.y + distance_m * sin(theta))


def _probe_candidates(session: SpeedSession, current: Point, next_scan: Point | None, config: SpeedConfig) -> tuple[Point, ...]:
    region = session.region
    center = _region_center(region)
    anchor, bearing_deg = session.positives[-1]
    theta = radians(bearing_deg)
    forward, side = (cos(theta), sin(theta)), (-sin(theta), cos(theta))
    vertices = _vertices(region)
    projections = [(vertex.x - anchor.x) * forward[0] + (vertex.y - anchor.y) * forward[1] for vertex in vertices] or [0.0]
    lo, hi = min(projections), max(projections)
    values = [center]
    for quantile in config.probe_quantiles:
        step = lo + quantile * (hi - lo)
        for width in config.probe_widths_m:
            for sign in (-1.0, 1.0):
                values.append(Point(anchor.x + step * forward[0] + sign * width * side[0],
                                    anchor.y + step * forward[1] + sign * width * side[1]))
    if next_scan is not None:
        values.append(next_scan)
    unique: list[Point] = []
    for point in values:
        if _radius(point) <= q3.TARGET_RADIUS + 1e-6 and not any(_distance(point, old) < 2.0 for old in unique):
            unique.append(point)
    def score(point: Point) -> tuple[float, float, float]:
        route = _distance(current, point) + (0.15 * _distance(point, next_scan) if next_scan is not None else 0.0)
        information = min((_distance(point, old) for old, _ in session.positives), default=0.0)
        return (route - 0.08 * information, point.x, point.y)
    return tuple(sorted(unique, key=score)[:10])


def _safe_clear_candidates(region: Any, current: Point, next_scan: Point | None, radius: float) -> tuple[Point, ...]:
    vertices = _vertices(region)
    if not vertices:
        return ()
    center = _region_center(region)
    raw = [center, current]
    if next_scan is not None:
        raw.append(next_scan)
        segment = Polygon()  # marker only; nearest projection follows below.
        _ = segment
    valid = [point for point in raw if all(_distance(point, vertex) <= radius + _EPS for vertex in vertices)]
    return tuple(sorted(dict.fromkeys(valid), key=lambda point: (_distance(current, point), point.x, point.y)))


def _fallback_points(session: SpeedSession) -> tuple[Point, ...]:
    if session.fallback:
        return session.fallback
    plan = q3.build_anchor_clearance_plan(channel=session.channel, anchor=session.anchor, bearing_deg=session.anchor_bearing_deg)
    session.fallback = tuple(action.position for action in plan.actions)
    return session.fallback


def session_action(session: SpeedSession, current: Point, next_scan: Point | None, config: SpeedConfig) -> SpeedAction:
    region = session.region if session.region is not None else update_region(session, config)
    center = _region_center(region)
    radius = _region_radius(region, center)
    safe = _safe_clear_candidates(region, current, next_scan, config.guaranteed_clear_radius_m)
    if safe:
        return SpeedAction("SOURCE_CLEAR", safe[0], session.channel, safe)
    # Public two-bearing ray crossings are an aggressive speed path only.
    # A failed clear is retained and the state continues to evolve normally.
    if len(session.positives) >= 2:
        first_point, first_bearing = session.positives[0]
        last_point, last_bearing = session.positives[-1]
        estimates = tuple(
            point for point in q3._fast_clear_candidates(first_point, first_bearing, last_point, last_bearing)
            if _radius(point) <= q3.TARGET_RADIUS + 1e-6 and point not in session.clear_attempts
        )
        if estimates:
            ordered = tuple(sorted(estimates, key=lambda point: (_distance(current, point), point.x, point.y)))
            return SpeedAction("SOURCE_CLEAR", ordered[0], session.channel, ordered[:5])
    if radius <= config.clear_attempt_radius_m and center not in session.clear_attempts:
        return SpeedAction("SOURCE_CLEAR", center, session.channel, (center,))
    if session.probe_count < config.max_probes:
        candidates = _probe_candidates(session, current, next_scan, config)
        if candidates:
            return SpeedAction("SOURCE_PROBE", candidates[0], session.channel, candidates)
    remaining = tuple(point for point in _fallback_points(session) if point not in session.fallback_attempted)
    if remaining:
        ordered = tuple(sorted(remaining, key=lambda point: (_distance(current, point), point.x, point.y)))
        return SpeedAction("SOURCE_FALLBACK", ordered[0], session.channel, ordered[:12])
    return SpeedAction("SOURCE_FALLBACK", session.anchor, session.channel, (session.anchor,))


def _choose_action(current: Point, scans: Iterable[Point], sessions: dict[int, SpeedSession], config: SpeedConfig,
                   planner: RecedingHorizonPlanner|None=None) -> SpeedAction | None:
    scan_values = tuple(scans)
    next_scan = min(scan_values, key=lambda point: (_distance(current, point), point.x, point.y)) if scan_values else None
    actions = [SpeedAction("CERT_SCAN", point) for point in scan_values]
    actions.extend(session_action(session, current, next_scan, config) for session in sessions.values())
    if not actions:
        return None
    if planner is not None:
        jobs=tuple(LiveJob((action.kind,action.channel,action.target.x,action.target.y),action.kind,
                           Q4Point(action.target.x,action.target.y),action.channel) for action in actions)
        selected=planner.choose(Q4Point(current.x,current.y),jobs)
        if selected is not None:
            return next(action for action in actions if (action.kind,action.channel,action.target.x,action.target.y)==selected.key)
    def score(action: SpeedAction) -> tuple[float, str, int]:
        value = _distance(current, action.target)
        if config.shallow_lookahead and action.kind == "SOURCE_PROBE" and next_scan is not None:
            value += 0.2 * _distance(action.target, next_scan)
        if action.kind == "CERT_SCAN" and sessions:
            value += 25.0  # one measurement action versus an already-localized source action
        return (value, action.kind, action.channel or 0)
    return min(actions, key=score)


def _record_clear(robot: Any, state: dict[int, SpeedState], channel: int, point: Point) -> bool:
    success = _response_result(robot.clear(point, channel)) == "success"
    if success:
        state[channel] = SpeedState.CLEARED
    return success


def _apply_measurement(
    robot: Any, state: dict[int, SpeedState], sessions: dict[int, SpeedSession], channel: int, point: Point,
    config: SpeedConfig, telemetry: SpeedTelemetry, *, scan: bool = False,
) -> str | None:
    response = robot.measure(point, channel)
    result = _response_result(response)
    if result == "near":
        state[channel] = SpeedState.PRESENT
        _record_clear(robot, state, channel, point)
        return result
    if result == "direction":
        bearing = _bearing(response)
        if bearing is not None:
            if channel not in sessions:
                sessions[channel] = SpeedSession(channel, point, bearing)
            else:
                sessions[channel].positives.append((point, bearing))
            state[channel] = SpeedState.PRESENT
            update_region(sessions[channel], config, telemetry)
        return result
    # A late/piggyback measurement after an actual clear can legitimately be
    # ``no_signal`` because that channel is already cleared.  It cannot be a
    # Q3 negative constraint on the former source position.
    if result == "no_signal" and state[channel] is SpeedState.PRESENT and channel in sessions:
        session = sessions[channel]
        if not any(_distance(point, old) <= 1e-6 for old in session.negatives):
            session.negatives.append(point)
            update_region(session, config, telemetry)
    return result


def _batch_after_scan(robot: Any, state: dict[int, SpeedState], sessions: dict[int, SpeedSession], origin: Point,
                      config: SpeedConfig, telemetry: SpeedTelemetry) -> None:
    if not config.batch_enabled:
        return
    eligible = [session for session in sessions.values() if state[session.channel] is SpeedState.PRESENT and session.probe_count == 0]
    if len(eligible) < 3:
        return
    choices = []
    for index in range(24):
        angle = 2.0 * pi * index / 24.0
        point = Point(origin.x + config.batch_step_m * cos(angle), origin.y + config.batch_step_m * sin(angle))
        score = 0.0
        for session in eligible:
            center = _region_center(session.region)
            score += min(300.0, _distance(point, center))
        choices.append((score, point))
    _, point = max(choices, key=lambda item: (item[0], -item[1].x, -item[1].y))
    telemetry.batch_moves += 1
    for session in eligible:
        _apply_measurement(robot, state, sessions, session.channel, point, config, telemetry)


def _piggyback(robot: Any, state: dict[int, SpeedState], sessions: dict[int, SpeedSession], point: Point,
               config: SpeedConfig, telemetry: SpeedTelemetry) -> None:
    if not config.angular_neighbors:
        return
    for session in list(sessions.values()):
        if state[session.channel] is not SpeedState.PRESENT or session.probe_count >= config.max_probes:
            continue
        if any(_distance(point, old) < 5.0 for old, _ in session.positives):
            continue
        vertices = _vertices(session.region)
        if not vertices or min(_distance(point, vertex) for vertex in vertices) > 1500.0:
            continue
        angles = sorted(atan2(vertex.y - point.y, vertex.x - point.x) for vertex in vertices)
        gaps = [(angles[(index + 1) % len(angles)] - angles[index]) % (2.0 * pi) for index in range(len(angles))]
        if 2.0 * pi - max(gaps) + _EPS < radians(config.neighbor_angle_span_deg):
            continue
        _apply_measurement(robot, state, sessions, session.channel, point, config, telemetry)
        session.probe_count += 1
        telemetry.piggyback_reads += 1


def execute_q3_speed(
    robot: Any, public_state: Any, *, config: SpeedConfig | None = None, telemetry: SpeedTelemetry | None = None,
) -> SpeedExecutionResult:
    """Atomic Q3 scan/source scheduler with all aggressive mechanisms gated."""
    config = config or SpeedConfig()
    telemetry = telemetry or SpeedTelemetry()
    rh=RecedingHorizonPlanner(k=config.rh_k,cheap_twoopt=config.rh_cheap_twoopt,rollout=config.rh_rollout) if config.receding_horizon else None
    state = {channel: SpeedState.UNKNOWN for channel in CHANNELS}
    sessions: dict[int, SpeedSession] = {}
    scanned: set[Point] = set()
    pending: set[Point] = {Point(0.0, 0.0)}
    current = Point(0.0, 0.0)
    ring_materialized = False
    localized = 0
    while pending or sessions:
        choice = _choose_action(current, pending, {channel: session for channel, session in sessions.items() if state[channel] is SpeedState.PRESENT}, config,rh)
        if choice is None:
            break
        before = current
        telemetry.decisions.append({"kind": choice.kind, "channel": choice.channel, "target": (choice.target.x, choice.target.y),
                                    "distance_m": _distance(before, choice.target), "scan_jobs": len(pending),
                                    "source_jobs": sum(value is SpeedState.PRESENT for value in state.values())})
        telemetry.selected[choice.kind] = telemetry.selected.get(choice.kind, 0) + 1
        if choice.kind == "CERT_SCAN":
            pending.remove(choice.target)
            scanned.add(choice.target)
            for channel in CHANNELS:
                if state[channel] is not SpeedState.UNKNOWN:
                    continue
                result = _apply_measurement(robot, state, sessions, channel, choice.target, config, telemetry, scan=True)
                if result == "direction":
                    localized += 1
            current = choice.target
            if not ring_materialized and choice.target == Point(0.0, 0.0):
                ring_materialized = True
                discovered = any(value is SpeedState.PRESENT for value in state.values())
                count = config.nonempty_ring_count if discovered else config.ring_count
                radius = config.nonempty_ring_radius_m if discovered else config.ring_radius_m
                if regular_ring_coverage_margin(count,radius)<=_EPS:
                    raise RuntimeError("Q3 regular-ring discovery certificate failed")
                pending.update(build_ring_family(count, radius)[1:])
            _batch_after_scan(robot, state, sessions, current, config, telemetry)
        else:
            session = sessions[choice.channel]
            if choice.kind == "SOURCE_CLEAR":
                if _record_clear(robot, state, session.channel, choice.target):
                    sessions.pop(session.channel, None)
                else:
                    session.clear_attempts.add(choice.target)
            elif choice.kind == "SOURCE_PROBE":
                _apply_measurement(robot, state, sessions, session.channel, choice.target, config, telemetry)
                session.probe_count += 1
            else:
                telemetry.fallback_actions += 1
                if _record_clear(robot, state, session.channel, choice.target):
                    sessions.pop(session.channel, None)
                else:
                    session.fallback_attempted.add(choice.target)
            current = choice.target
        _piggyback(robot, state, sessions, current, config, telemetry)
        if sum(value is SpeedState.CLEARED for value in state.values()) >= 16:
            break
        if not pending:
            for channel in CHANNELS:
                if state[channel] is SpeedState.UNKNOWN:
                    state[channel] = SpeedState.ABSENT
    complete = sum(value is SpeedState.CLEARED for value in state.values()) >= 16 or all(
        value in (SpeedState.CLEARED, SpeedState.ABSENT) for value in state.values()
    )
    cp08_used = False
    if not complete:
        cp08 = q3.execute_q3_strategy(robot, public_state)
        cp08_used = True
        complete = cp08.complete
        for channel, value in cp08.channel_states.items():
            state[channel] = SpeedState.CLEARED if value == q3.ChannelState.CLEARED else state[channel]
    if rh is not None: telemetry.planner=rh.telemetry()
    return SpeedExecutionResult({channel: value.value for channel, value in state.items()}, complete, "Q3-SPEED", cp08_used,
                                localized, telemetry.fallback_actions, telemetry)
