"""BATCR-A: CERT-D survey safety with optional shared second-bearing shortcuts.

This independent candidate never changes CERT-D or CP08.  A failed or absent
CERT-D certificate delegates immediately to exact CP08; a failed shared-B
shortcut leaves each original anchor-wedge clearance witness intact.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import atan2, degrees, hypot
from typing import Any, Callable, Iterable

from b_problem.batch_geometry import shared_second_bearing

from . import q4, q4_extreme
from .q4_cert_d import CERT_D_EDGE_M, CERT_D_STATION_COUNT, CertDStationCertificate
from .q4_static_routing import FutureRouteTrace, nearest_neighbor_route, open_two_opt


@dataclass(frozen=True)
class BatcrBatchTrace:
    station: q4.Point
    point_b: q4.Point | None
    channels_served: tuple[int, ...]
    reason: str


@dataclass(frozen=True)
class BatcrAExecutionResult:
    execution: q4.Q4ExecutionResult
    route_trace: tuple[FutureRouteTrace, ...]
    batch_trace: tuple[BatcrBatchTrace, ...]
    used_batcr_a: bool


def _load_cert_d_certificate() -> CertDStationCertificate | None:
    """Copy CERT-D's exact 31-station certificate gate without changing CERT-D."""
    try:
        from b_problem.certificate_experiments.q4_station_selection import (
            radial_support_candidate,
            required_radial_support,
        )
        candidate = radial_support_candidate(CERT_D_EDGE_M)
        required = required_radial_support(CERT_D_EDGE_M)
    except (ImportError, AttributeError, ValueError):
        return None
    if (
        candidate.edge_m != CERT_D_EDGE_M
        or len(candidate.stations) != CERT_D_STATION_COUNT
        or required != candidate.stations
    ):
        return None
    return CertDStationCertificate(candidate.stations, candidate.edge_m, "PROVED")


def _runtime_certificate_is_valid(certificate: CertDStationCertificate | None) -> bool:
    return (
        certificate is not None
        and certificate.analytic_status == "PROVED"
        and certificate.edge_m == CERT_D_EDGE_M
        and len(certificate.stations) == CERT_D_STATION_COUNT
        and all(isinstance(point, q4.Point) for point in certificate.stations)
    )


def _next_station(current: q4.Point, unvisited: Iterable[q4.Point]) -> q4.Point:
    points = tuple(unvisited)
    if not points:
        raise ValueError("unvisited stations must not be empty")
    return open_two_opt(current, nearest_neighbor_route(current, points))[0]


def _route_directions(origin: q4.Point, unvisited: Iterable[q4.Point]) -> tuple[float, ...]:
    headings = {
        degrees(atan2(point.y - origin.y, point.x - origin.x)) % 360.0
        for point in unvisited
        if point.distance_to(origin) > q4.TOLERANCE
    }
    return tuple(sorted(headings))


def _batch_anchor(anchor: q4_extreme.PositiveAnchor) -> shared_second_bearing.BatchAnchor:
    return shared_second_bearing.BatchAnchor(anchor.channel, anchor.bearing_deg, anchor.station.x, anchor.station.y)


def _try_shared_b(
    robot: Any,
    station: q4.Point,
    batch: tuple[q4_extreme.PositiveAnchor, ...],
    route_directions_deg: tuple[float, ...],
) -> tuple[BatcrBatchTrace, frozenset[int]]:
    """Attempt exactly one geometrically shared B, retaining all failed anchors."""
    if len(batch) < 2:
        return BatcrBatchTrace(station, None, (), "insufficient_batch_fast_c"), frozenset()
    best = shared_second_bearing.best_shared_second_bearing(
        tuple(_batch_anchor(anchor) for anchor in batch), route_directions_deg=route_directions_deg,
    )
    if len(best.served_channels) < 2 or best.nonparallel_pair_count < 1:
        return BatcrBatchTrace(station, None, (), "insufficient_viable_geometry_fast_c"), frozenset()
    point_b = q4.Point(best.x, best.y)
    by_channel = {anchor.channel: anchor for anchor in batch}
    cleared: set[int] = set()
    for channel in best.served_channels:
        anchor = by_channel[channel]
        response = robot.measure(point_b, channel)
        if not q4_extreme._accepted(response):  # noqa: SLF001 - shared public response adapter.
            continue
        result = q4_extreme._field(response, "result", "measure_result")  # noqa: SLF001
        if result == "near":
            if q4_extreme._try_fast_clear(robot, channel, point_b, corrections=True):  # noqa: SLF001 - bounded existing clear routine.
                cleared.add(channel)
            continue
        if result != "direction":
            continue
        second_bearing = q4_extreme._field(response, "svd_deg")  # noqa: SLF001
        if second_bearing is None:
            continue
        crossing = shared_second_bearing.forward_ray_intersection(
            _batch_anchor(anchor), second_x=point_b.x, second_y=point_b.y, second_bearing_deg=float(second_bearing),
        )
        if crossing is None:
            continue
        estimate = q4.Point(*crossing)
        if estimate.radius() <= q4.TARGET_RADIUS_M + q4.TOLERANCE and q4_extreme._try_fast_clear(  # noqa: SLF001
            robot, channel, estimate, corrections=True
        ):
            cleared.add(channel)
    return BatcrBatchTrace(station, point_b, best.served_channels, "shared_b_attempt"), frozenset(cleared)


def _try_single_anchor_fast_c(robot: Any, anchor: q4_extreme.PositiveAnchor) -> bool:
    """Use the existing per-source local path only when a shared B is unavailable."""
    return q4_extreme._direct_cross_range_pursuit(robot, anchor)  # noqa: SLF001 - unchanged FAST-C fallback path.


def execute_q4_batcr_a_strategy(
    robot: Any,
    public_state: Any,
    *,
    certificate_provider: Callable[[], CertDStationCertificate | None] = _load_cert_d_certificate,
    channels: Iterable[int] = range(1, 21),
) -> BatcrAExecutionResult:
    """Run certified 31-station survey, shared B when viable, anchor wedges otherwise."""
    try:
        certificate = certificate_provider()
    except Exception:
        certificate = None
    if not _runtime_certificate_is_valid(certificate):
        return BatcrAExecutionResult(q4.execute_q4_strategy(robot, public_state), (), (), False)

    selected = tuple(channels)
    states = {channel: q4.Q4ChannelState.UNKNOWN for channel in selected}
    evidence = {channel: [] for channel in selected}
    no_signal = {channel: set() for channel in selected}
    pending_grids: dict[int, q4.AnchorWedgeClearanceGrid] = {}
    route_trace: list[FutureRouteTrace] = []
    batch_trace: list[BatcrBatchTrace] = []
    unvisited = set(certificate.stations)
    station_id = 0

    while unvisited:
        current = q4_extreme._robot_position(robot, q4.Point(0.0, 0.0))  # noqa: SLF001
        station = _next_station(current, unvisited)
        route_trace.append(FutureRouteTrace(
            from_point=current, to_point=station, reason="batcr_a_cert_d_rolling_open_2opt",
            channel=None, task_type="survey", state="station_scan",
        ))
        unvisited.remove(station)
        batch: list[q4_extreme.PositiveAnchor] = []
        for channel in selected:
            if states[channel] is not q4.Q4ChannelState.UNKNOWN:
                continue
            response = robot.measure(station, channel)
            if not q4_extreme._accepted(response):  # noqa: SLF001
                continue
            result = q4_extreme._field(response, "result", "measure_result")  # noqa: SLF001
            if result == "no_signal":
                no_signal[channel].add(station_id)
                if len(no_signal[channel]) == CERT_D_STATION_COUNT:
                    states[channel] = q4.Q4ChannelState.ABSENT_CERTIFIED
                    evidence[channel].append("batcr_a_absent_certified")
                continue
            if result == "near":
                if q4_extreme._clear_succeeded(robot.clear(station, channel)):  # noqa: SLF001
                    states[channel] = q4.Q4ChannelState.CLEARED
                    evidence[channel].append("batcr_a_cleared_at_cert_d_station")
                else:
                    states[channel] = q4.Q4ChannelState.PRESENT_UNRESOLVED
                continue
            if result != "direction":
                continue
            bearing = q4_extreme._field(response, "svd_deg")  # noqa: SLF001
            if bearing is None:
                continue
            anchor = q4_extreme.PositiveAnchor(channel, station, float(bearing))
            grid = q4.build_anchor_clearance_grid(station, bearing_deg=float(bearing))
            states[channel] = q4.Q4ChannelState.PRESENT_UNRESOLVED
            pending_grids[channel] = grid
            batch.append(anchor)
            evidence[channel].append("batcr_a_positive_anchor_retained")

        if batch:
            trace, cleared = _try_shared_b(robot, station, tuple(batch), _route_directions(station, unvisited))
            batch_trace.append(trace)
            if trace.reason == "shared_b_attempt":
                for channel in trace.channels_served:
                    if channel in cleared:
                        states[channel] = q4.Q4ChannelState.CLEARED
                        pending_grids.pop(channel, None)
                        evidence[channel].append("batcr_a_shared_b_clear")
                    else:
                        evidence[channel].append("batcr_a_shared_b_anchor_wedge_fallback")
                for anchor in batch:
                    if anchor.channel not in trace.channels_served:
                        evidence[anchor.channel].append("batcr_a_not_served_anchor_wedge_fallback")
            else:
                for anchor in q4_extreme.order_positive_anchors(station, batch):  # noqa: SLF001
                    if _try_single_anchor_fast_c(robot, anchor):
                        states[anchor.channel] = q4.Q4ChannelState.CLEARED
                        pending_grids.pop(anchor.channel, None)
                        evidence[anchor.channel].append("batcr_fast_c_single_anchor_clear")
                    else:
                        evidence[anchor.channel].append("batcr_fast_c_single_anchor_anchor_wedge_fallback")
        station_id += 1

    tasks = tuple(
        (channel, grid.stations)
        for channel, grid in sorted(pending_grids.items())
        if states[channel] is q4.Q4ChannelState.PRESENT_UNRESOLVED
    )
    fallback_start = q4_extreme._robot_position(robot, q4.Point(0.0, 0.0))  # noqa: SLF001
    for channel, point in q4.multi_source_clear_route(fallback_start, tasks):
        if states[channel] is not q4.Q4ChannelState.PRESENT_UNRESOLVED:
            continue
        if q4_extreme._clear_succeeded(robot.clear(point, channel)):  # noqa: SLF001
            states[channel] = q4.Q4ChannelState.CLEARED
            evidence[channel].append("cleared_by_anchor_wedge")
    complete = sum(state is q4.Q4ChannelState.CLEARED for state in states.values()) >= 16 or all(
        state in (q4.Q4ChannelState.CLEARED, q4.Q4ChannelState.ABSENT_CERTIFIED)
        for state in states.values()
    )
    execution = q4.Q4ExecutionResult(
        channel_states={channel: state.value for channel, state in states.items()},
        channel_evidence={channel: tuple(items) for channel, items in evidence.items()},
        complete=complete,
    )
    return BatcrAExecutionResult(execution, tuple(route_trace), tuple(batch_trace), True)
