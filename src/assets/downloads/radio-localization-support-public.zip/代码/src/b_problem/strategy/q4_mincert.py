"""Runtime adapter for a prevalidated MINCERT station set only."""
from __future__ import annotations

from math import cos, radians, sin
from typing import Any, Iterable

from b_problem.certificate_experiments.q4_mincert import validate_directional_certificate
from b_problem.certificate_experiments.q4_21_certificate import candidate_21, certify_21

from . import q4
from .q4_cert_d import CertDExecutionResult, CertDStationCertificate, execute_q4_cert_d_strategy
from .q4_telemetry import RecoveryTelemetry


def mincert_certificate(stations: Iterable[q4.Point]) -> CertDStationCertificate:
    """Fail closed unless the offline conservative certificate passes."""
    frozen = frozenset(stations)
    audit = validate_directional_certificate(frozen)
    if audit.status != "PASS":
        raise ValueError(f"MINCERT validator rejected station set: {audit.detail}")
    return CertDStationCertificate(frozen, audit.max_active_triangle_edge_m or 0.0, "PROVED")


def certificate_21point() -> CertDStationCertificate:
    """Fail closed unless the finite 21-point certificate passes in-process."""
    stations = frozenset(candidate_21())
    audit = certify_21(tuple(stations))
    if not audit.certified or audit.oriented_pair_checks != 408:
        raise ValueError("21-point directional discovery certificate did not pass")
    return CertDStationCertificate(stations, audit.worst_receive_radius_m, "PROVED_21POINT")


def rotated_21point_certificate(angle_deg: float) -> CertDStationCertificate:
    """Re-run the finite certificate for a rigidly rotated 21-point layout.

    Rotation preserves the circular arena and all distance/closed-half-plane
    predicates, but we still execute the independent finite validator instead
    of relying on that observation at runtime.
    """
    theta=radians(angle_deg); c,s=cos(theta),sin(theta)
    stations=frozenset(q4.Point(c*p.x-s*p.y,s*p.x+c*p.y) for p in candidate_21())
    audit=certify_21(tuple(stations))
    if not audit.certified or audit.oriented_pair_checks != 408:
        raise ValueError("rotated 21-point certificate did not pass")
    return CertDStationCertificate(stations,audit.worst_receive_radius_m,"PROVED_21POINT_ROTATED")


def execute_q4_mincert_strategy(
    robot: Any, public_state: Any, certificate: CertDStationCertificate, *, channels: Iterable[int] = range(1, 21)
) -> CertDExecutionResult:
    """CERT-D execution policy with only its static station set replaced."""
    return execute_q4_cert_d_strategy(
        robot, public_state, certificate_provider=lambda: certificate, channels=channels, allow_prevalidated_certificate=True
    )


def execute_q4_mincert_mbfc_strategy(
    robot: Any, public_state: Any, certificate: CertDStationCertificate, *, channels: Iterable[int] = range(1, 21),
    telemetry: RecoveryTelemetry | None = None, shared_baseline: bool = False,
) -> CertDExecutionResult:
    """Experimental MBFC-A adapter; the frozen champion entry point stays unchanged."""
    return execute_q4_cert_d_strategy(
        robot, public_state, certificate_provider=lambda: certificate, channels=channels,
        allow_prevalidated_certificate=True, mbfc_enabled=True, telemetry=telemetry, shared_baseline=shared_baseline,
    )


def execute_q4_full_port_strategy(robot: Any, public_state: Any, certificate: CertDStationCertificate, *,
                                  routingplus: bool = True, shared_baseline: bool = True, telemetry=None,
                                  region_clear: bool = False, region_probe: bool = False, region_fallback: bool = False, alternating_region: bool = False,
                                  paired_negative: bool = False, adaptive_certificate_rotation: bool = False, early16: bool = True,
                                  receding_horizon: bool = False, rh_k: int = 8, rh_cheap_twoopt: bool = False, rh_rollout: bool = False):
    """Feature-flagged atomic mixed runtime; the frozen champion is unchanged."""
    from .q4_mixed_atomic import execute_q4_mixed_atomic
    return execute_q4_mixed_atomic(robot, public_state, certificate, routingplus=routingplus,
                                   shared_baseline=shared_baseline, telemetry=telemetry,
                                   region_clear=region_clear, region_probe=region_probe, region_fallback=region_fallback, alternating_region=alternating_region,
                                   paired_negative=paired_negative, adaptive_certificate_rotation=adaptive_certificate_rotation, early16=early16,
                                   receding_horizon=receding_horizon,rh_k=rh_k,rh_cheap_twoopt=rh_cheap_twoopt,rh_rollout=rh_rollout)
