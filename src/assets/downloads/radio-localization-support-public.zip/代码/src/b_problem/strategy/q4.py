"""Certified baseline geometry and recovery state for Q4 directional sources.

This module owns the Q4 strategy primitives only.  It does not call the
simulator and does not duplicate shared Q1 localization geometry.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from math import atan2, ceil, cos, hypot, radians, sin, sqrt
from typing import Any, Iterable


TARGET_RADIUS_M = 1800.0
MIN_RECEIVE_RADIUS_M = 1000.0
CLEAR_RADIUS_M = 20.0
SQRT3 = sqrt(3.0)
TOLERANCE = 1e-9


@dataclass(frozen=True, order=True)
class Point:
    x: float
    y: float

    def distance_to(self, other: "Point") -> float:
        return hypot(self.x - other.x, self.y - other.y)

    def radius(self) -> float:
        return hypot(self.x, self.y)

    def dot_from(self, origin: "Point", normal: "Point") -> float:
        return (self.x - origin.x) * normal.x + (self.y - origin.y) * normal.y


@dataclass(frozen=True)
class Triangle:
    a: Point
    b: Point
    c: Point

    @property
    def vertices(self) -> tuple[Point, Point, Point]:
        return (self.a, self.b, self.c)

    @property
    def signed_double_area(self) -> float:
        return (self.b.x - self.a.x) * (self.c.y - self.a.y) - (self.b.y - self.a.y) * (self.c.x - self.a.x)

    @property
    def is_non_degenerate(self) -> bool:
        return abs(self.signed_double_area) > TOLERANCE

    @property
    def max_edge_m(self) -> float:
        return max(self.a.distance_to(self.b), self.b.distance_to(self.c), self.c.distance_to(self.a))

    def contains_closed(self, point: Point) -> bool:
        """Closed barycentric containment, including edges and vertices."""
        if not self.is_non_degenerate:
            return False
        signs = []
        for start, end in ((self.a, self.b), (self.b, self.c), (self.c, self.a)):
            signs.append((end.x - start.x) * (point.y - start.y) - (end.y - start.y) * (point.x - start.x))
        return min(signs) >= -TOLERANCE or max(signs) <= TOLERANCE


@dataclass(frozen=True)
class CellScaleAssessment:
    edge_m: float
    status: str
    reason: str


def assess_triangle_edge(edge_m: float) -> CellScaleAssessment:
    """Assess only the stated triangular-cell sufficient condition.

    An edge above 1000 m is *not* a claim that every possible deployment
    fails.  It loses the simple uniform triangle-cell guarantee because a
    source can sit arbitrarily near one grid vertex while all other vertices
    are beyond the minimum receiving radius.
    """
    if edge_m <= 0.0:
        raise ValueError("edge_m must be positive")
    if edge_m <= MIN_RECEIVE_RADIUS_M + TOLERANCE:
        return CellScaleAssessment(edge_m, "PROVED", "Triangle-cell sufficient condition holds: every cell edge is at most 1000 m.")
    return CellScaleAssessment(
        edge_m,
        "NO_UNIVERSAL_GUARANTEE",
        "The single triangle-cell condition loses its universal guarantee; alternative deployments are not assessed here.",
    )


def _lattice_point(i: int, j: int, edge_m: float, origin: Point) -> Point:
    return Point(origin.x + edge_m * (i + j / 2.0), origin.y + edge_m * SQRT3 * j / 2.0)


def _index_limit(radius_m: float, edge_m: float, outer_layers: int) -> int:
    extended = radius_m + outer_layers * edge_m
    # Bounds both lattice coordinates for every point in the extended disk,
    # then leaves two full lattice layers of slack for the containing cell.
    return ceil(max(2.0 * extended / (SQRT3 * edge_m), extended / edge_m + extended / (SQRT3 * edge_m))) + 2


def _full_lattice_cells(radius_m: float, edge_m: float, origin: Point, outer_layers: int) -> tuple[tuple[Triangle, ...], frozenset[Point]]:
    limit = _index_limit(radius_m, edge_m, outer_layers)
    cells: list[Triangle] = []
    stations: set[Point] = set()
    for i in range(-limit, limit + 1):
        for j in range(-limit, limit + 1):
            p00 = _lattice_point(i, j, edge_m, origin)
            p10 = _lattice_point(i + 1, j, edge_m, origin)
            p01 = _lattice_point(i, j + 1, edge_m, origin)
            p11 = _lattice_point(i + 1, j + 1, edge_m, origin)
            first = Triangle(p00, p10, p01)
            second = Triangle(p10, p11, p01)
            cells.extend((first, second))
            stations.update(first.vertices)
            stations.update(second.vertices)
    return tuple(cells), frozenset(stations)


@dataclass(frozen=True)
class PointCoverageCertificate:
    source: Point
    cell: Triangle
    contains_source: bool
    all_vertices_scheduled: bool
    status: str


@dataclass(frozen=True)
class ContinuousCoverageCertificate:
    target_center: Point
    target_radius_m: float
    edge_m: float
    outer_extension_m: float
    cell_count: int
    station_count: int
    all_cell_vertices_scheduled: bool
    status: str
    proof: str


@dataclass(frozen=True)
class SurveyPlan:
    nominal_edge_m: float
    eta_m: float
    edge_m: float
    target_radius_m: float
    outer_extension_m: float
    cells: tuple[Triangle, ...]
    stations: frozenset[Point]
    route: tuple[Point, ...]

    def certificate_for_point(self, source: Point) -> PointCoverageCertificate:
        if source.radius() > self.target_radius_m + TOLERANCE:
            raise ValueError("source is outside the target circle")
        for cell in self.cells:
            if cell.contains_closed(source):
                scheduled = all(vertex in self.stations for vertex in cell.vertices)
                status = "PROVED" if scheduled and cell.max_edge_m <= MIN_RECEIVE_RADIUS_M + TOLERANCE else "UNRESOLVED"
                return PointCoverageCertificate(source, cell, True, scheduled, status)
        raise RuntimeError("construction error: target point has no scheduled containing cell")

    def continuous_coverage_certificate(self) -> ContinuousCoverageCertificate:
        assessment = assess_triangle_edge(self.edge_m)
        all_scheduled = all(all(vertex in self.stations for vertex in cell.vertices) for cell in self.cells)
        status = "PROVED" if assessment.status == "PROVED" and self.outer_extension_m >= self.edge_m and all_scheduled else "UNRESOLVED"
        return ContinuousCoverageCertificate(
            target_center=Point(0.0, 0.0),
            target_radius_m=self.target_radius_m,
            edge_m=self.edge_m,
            outer_extension_m=self.outer_extension_m,
            cell_count=len(self.cells),
            station_count=len(self.stations),
            all_cell_vertices_scheduled=all_scheduled,
            status=status,
            proof=(
                "A complete finite triangular-lattice patch covers a disk expanded by one edge layer; "
                "therefore every target-circle point lies in a scheduled closed triangular cell. "
                "Every such cell has maximum edge at most 1000 m."
            ),
        )


def build_survey_plan(
    *,
    target_radius_m: float = TARGET_RADIUS_M,
    nominal_edge_m: float = MIN_RECEIVE_RADIUS_M,
    eta_m: float = 1.0,
    outer_layers: int = 1,
) -> SurveyPlan:
    """Build a finite, one-layer-extended triangular survey plan.

    ``eta_m`` is explicit so the operational default is 999 m rather than an
    equality-sensitive 1000 m numerical boundary.
    """
    if target_radius_m <= 0.0:
        raise ValueError("target_radius_m must be positive")
    if eta_m <= 0.0:
        raise ValueError("eta_m must be positive")
    if outer_layers < 1:
        raise ValueError("outer_layers must be at least one")
    edge_m = nominal_edge_m - eta_m
    if edge_m <= 0.0:
        raise ValueError("eta_m must be smaller than nominal_edge_m")
    if assess_triangle_edge(edge_m).status != "PROVED":
        raise ValueError("actual triangular cell edge must not exceed 1000 m")
    all_cells, _ = _full_lattice_cells(target_radius_m, edge_m, Point(0.0, 0.0), outer_layers)
    # A cell containing a target-disk point has every vertex within R+h of
    # the origin.  Keeping this finite collar preserves continuous coverage
    # while avoiding the much larger square construction patch.
    cells = tuple(
        cell for cell in all_cells
        if min(vertex.radius() for vertex in cell.vertices) <= target_radius_m + edge_m + TOLERANCE
    )
    stations = frozenset(vertex for cell in cells for vertex in cell.vertices)
    return SurveyPlan(
        nominal_edge_m=nominal_edge_m,
        eta_m=eta_m,
        edge_m=edge_m,
        target_radius_m=target_radius_m,
        outer_extension_m=outer_layers * edge_m,
        cells=cells,
        stations=stations,
        route=_q4_snake_order(tuple(stations)),
    )


@dataclass(frozen=True)
class ClosedHalfPlaneReceptionCertificate:
    source: Point
    triangle: Triangle
    status: str
    non_degenerate_local_set: bool
    nonzero_neighbor_count: int

    def has_receiver_in_closed_halfplane(self, normal: Point, radius_m: float = MIN_RECEIVE_RADIUS_M) -> bool:
        if hypot(normal.x, normal.y) <= TOLERANCE:
            raise ValueError("half-plane normal must be non-zero")
        if self.status != "PROVED":
            return False
        return any(
            vertex.distance_to(self.source) <= radius_m + TOLERANCE
            and vertex.dot_from(self.source, normal) >= -TOLERANCE
            for vertex in self.triangle.vertices
        )


def closed_halfplane_reception_certificate(
    source: Point, triangle: Triangle, *, radius_m: float = MIN_RECEIVE_RADIUS_M
) -> ClosedHalfPlaneReceptionCertificate:
    """Prove at least one triangle vertex receives for any closed 180° half-plane."""
    if radius_m < MIN_RECEIVE_RADIUS_M:
        raise ValueError("certificate is intended for the stated 1000 m minimum radius")
    nonzero_neighbors = sum(vertex.distance_to(source) > TOLERANCE for vertex in triangle.vertices)
    proven = (
        triangle.is_non_degenerate
        and triangle.contains_closed(source)
        and triangle.max_edge_m <= radius_m + TOLERANCE
        and nonzero_neighbors >= 2
    )
    return ClosedHalfPlaneReceptionCertificate(
        source=source,
        triangle=triangle,
        status="PROVED" if proven else "UNRESOLVED",
        non_degenerate_local_set=triangle.is_non_degenerate and nonzero_neighbors >= 2,
        nonzero_neighbor_count=nonzero_neighbors,
    )


@dataclass(frozen=True)
class ClearanceGrid:
    center: Point
    target_radius_m: float
    spacing_m: float
    eta_c_m: float
    coverage_radius_m: float
    cells: tuple[Triangle, ...]
    stations: frozenset[Point]

    def coverage_certificate(self) -> "ClearanceCoverageCertificate":
        all_scheduled = all(all(vertex in self.stations for vertex in cell.vertices) for cell in self.cells)
        status = "PROVED" if self.coverage_radius_m <= CLEAR_RADIUS_M + TOLERANCE and all_scheduled else "UNRESOLVED"
        return ClearanceCoverageCertificate(
            center=self.center,
            target_radius_m=self.target_radius_m,
            spacing_m=self.spacing_m,
            coverage_radius_m=self.coverage_radius_m,
            all_cell_vertices_scheduled=all_scheduled,
            status=status,
        )

    def certificate_for_point(self, source: Point) -> PointCoverageCertificate:
        if source.distance_to(self.center) > self.target_radius_m + TOLERANCE:
            raise ValueError("source is outside the certified clearance disk")
        for cell in self.cells:
            if cell.contains_closed(source):
                scheduled = all(vertex in self.stations for vertex in cell.vertices)
                status = "PROVED" if scheduled and self.coverage_radius_m <= CLEAR_RADIUS_M + TOLERANCE else "UNRESOLVED"
                return PointCoverageCertificate(source, cell, True, scheduled, status)
        raise RuntimeError("construction error: clearance point has no containing cell")


@dataclass(frozen=True)
class ClearanceCoverageCertificate:
    center: Point
    target_radius_m: float
    spacing_m: float
    coverage_radius_m: float
    all_cell_vertices_scheduled: bool
    status: str


def build_clearance_grid(
    center: Point,
    *,
    target_radius_m: float = 1500.0,
    eta_c_m: float = 0.01,
    outer_layers: int = 1,
) -> ClearanceGrid:
    """Build a 20 m-covering triangular clear-point grid around an anchor."""
    if eta_c_m <= 0.0:
        raise ValueError("eta_c_m must be positive")
    spacing_m = CLEAR_RADIUS_M * SQRT3 - eta_c_m
    if spacing_m <= 0.0 or outer_layers < 1:
        raise ValueError("invalid clearance-grid parameters")
    cells, stations = _full_lattice_cells(target_radius_m, spacing_m, center, outer_layers)
    return ClearanceGrid(
        center=center,
        target_radius_m=target_radius_m,
        spacing_m=spacing_m,
        eta_c_m=eta_c_m,
        coverage_radius_m=spacing_m / SQRT3,
        cells=cells,
        stations=stations,
    )


# A full 1500 m disk grid is retained above only as a geometric compatibility
# helper.  The executable Q4 fallback below uses the much narrower first-
# bearing wedge and rejects itself when action/time/log estimates exceed caps.
ESTIMATED_LOG_BYTES_PER_ACTION = 256
MAX_VIRTUAL_SECONDS = 360000.0
MAX_LOG_BYTES = 2 * 1024 * 1024


@dataclass(frozen=True)
class WedgeSampleCoverageCertificate:
    sample_count: int
    all_samples_covered: bool
    maximum_nearest_distance_m: float
    continuous_sector_coverage: bool
    status: str
    proof: str = ""


@dataclass(frozen=True)
class WedgeResourceCertificate:
    projected_actions_for_16_channels: int
    projected_route_virtual_seconds: float
    estimated_log_bytes: int
    status: str
    reason: str


@dataclass(frozen=True)
class AnchorWedgeClearanceGrid:
    center: Point
    bearing_deg: float
    region_kind: str
    spacing_m: float
    eta_c_m: float
    coverage_radius_m: float
    stations: tuple[Point, ...]
    sample_coverage_certificate: WedgeSampleCoverageCertificate
    resource_certificate: WedgeResourceCertificate
    bounding_box_area_m2: float
    route_length_m: float

    def coverage_certificate(self) -> WedgeSampleCoverageCertificate:
        return self.sample_coverage_certificate


def _q4_angle_delta(angle_deg: float, bearing_deg: float) -> float:
    return (angle_deg - bearing_deg + 180.0) % 360.0 - 180.0


def _q4_wedge_samples(anchor: Point, bearing_deg: float, delta_deg: float) -> tuple[Point, ...]:
    samples: list[Point] = []
    radii = {0.0, 5.0, 20.0, 1000.0, 1500.0}
    radii.update(1500.0 * index / 75.0 for index in range(76))
    for radius in sorted(radii):
        for offset in (-delta_deg, -delta_deg / 2.0, 0.0, delta_deg / 2.0, delta_deg):
            angle = radians(bearing_deg + offset)
            point = Point(anchor.x + radius * cos(angle), anchor.y + radius * sin(angle))
            if point.radius() <= TARGET_RADIUS_M + TOLERANCE:
                samples.append(point)
    return tuple(dict.fromkeys(samples))


def _q4_box_grid(x_min: float, x_max: float, y_min: float, y_max: float, spacing_m: float) -> tuple[Point, ...]:
    pad = spacing_m
    row_step = SQRT3 * spacing_m / 2.0
    first_row = int((y_min - pad) // row_step)
    last_row = int(ceil((y_max + pad) / row_step))
    points: list[Point] = []
    for row in range(first_row, last_row + 1):
        offset = (row & 1) * spacing_m / 2.0
        first_col = int((x_min - pad - offset) // spacing_m)
        last_col = int(ceil((x_max + pad - offset) / spacing_m))
        points.extend(Point(column * spacing_m + offset, row * row_step) for column in range(first_col, last_col + 1))
    return tuple(dict.fromkeys(points))


def _q4_snake_order(points: tuple[Point, ...]) -> tuple[Point, ...]:
    rows: dict[float, list[Point]] = {}
    for point in points:
        rows.setdefault(point.y, []).append(point)
    ordered: list[Point] = []
    for index, y in enumerate(sorted(rows)):
        ordered.extend(sorted(rows[y], key=lambda point: point.x, reverse=bool(index % 2)))
    return tuple(ordered)


def _q4_route_length(anchor: Point, points: tuple[Point, ...]) -> float:
    return sum(first.distance_to(second) for first, second in zip((anchor, *points), points))


def multi_source_clear_route(
    start: Point, tasks: tuple[tuple[int, tuple[Point, ...]], ...]
) -> tuple[tuple[int, Point], ...]:
    """Nearest-neighbor fast path that preserves every independent clear witness.

    Reordering does not alter the certified fallback: if no clear succeeds,
    every point from every channel's clearance grid is still attempted.
    """
    remaining = [(channel, point) for channel, points in tasks for point in points]
    current = start
    route: list[tuple[int, Point]] = []
    while remaining:
        index, (channel, point) = min(
            enumerate(remaining),
            key=lambda item: (
                current.distance_to(item[1][1]), item[1][0], item[1][1].x, item[1][1].y,
            ),
        )
        route.append((channel, point))
        current = point
        remaining.pop(index)
    return tuple(route)


def _q4_distance_to_closed_sector(point: Point, *, radius_m: float, delta_deg: float) -> float:
    """Exact Euclidean distance from a local point to a closed circular sector."""
    angle = atan2(point.y, point.x)
    half_width = radians(delta_deg)
    radial_distance = hypot(point.x, point.y)
    if abs(angle) <= half_width + TOLERANCE:
        if radial_distance <= radius_m:
            return 0.0
        return radial_distance - radius_m

    def distance_to_segment(end: Point) -> float:
        length_squared = end.x * end.x + end.y * end.y
        projection = max(0.0, min(1.0, (point.x * end.x + point.y * end.y) / length_squared))
        return hypot(point.x - projection * end.x, point.y - projection * end.y)

    endpoint_angle = half_width if angle > 0.0 else -half_width
    endpoint = Point(radius_m * cos(endpoint_angle), radius_m * sin(endpoint_angle))
    other_endpoint = Point(radius_m * cos(-endpoint_angle), radius_m * sin(-endpoint_angle))
    return min(distance_to_segment(endpoint), distance_to_segment(other_endpoint))


def build_anchor_clearance_grid(
    anchor: Point,
    *,
    bearing_deg: float,
    delta_deg: float = 1.0,
    eta_c_m: float = 0.01,
) -> AnchorWedgeClearanceGrid:
    """Construct a sampled/cell-lattice check for the first-bearing narrow wedge."""
    if not 0.0 < delta_deg < 90.0 or eta_c_m <= 0.0:
        raise ValueError("invalid narrow-clearance parameters")
    spacing_m = CLEAR_RADIUS_M * SQRT3 - eta_c_m
    coverage_radius = spacing_m / SQRT3
    x_min, x_max = 0.0, 1500.0
    transverse = 1500.0 * sin(radians(delta_deg))
    y_min, y_max = -transverse, transverse
    candidates = _q4_box_grid(x_min, x_max, y_min, y_max, spacing_m)
    # Retain every lattice station that can be the nearest receiver of a
    # point in the closed sector.  The full lattice has covering radius C;
    # hence a nearest station of any sector point has distance at most C to
    # the sector and survives this filter.
    local_stations = _q4_snake_order(tuple(
        point for point in candidates
        if _q4_distance_to_closed_sector(point, radius_m=1500.0, delta_deg=delta_deg) <= coverage_radius + TOLERANCE
    ))
    heading = radians(bearing_deg)
    cosine, sine = cos(heading), sin(heading)
    stations = tuple(
        Point(anchor.x + cosine * point.x - sine * point.y, anchor.y + sine * point.x + cosine * point.y)
        for point in local_stations
    )
    samples = _q4_wedge_samples(anchor, bearing_deg, delta_deg)
    maximum_nearest = max(
        (min(sample.distance_to(point) for point in stations) for sample in samples),
        default=0.0,
    )
    sample_certificate = WedgeSampleCoverageCertificate(
        sample_count=len(samples),
        all_samples_covered=maximum_nearest <= coverage_radius + TOLERANCE,
        maximum_nearest_distance_m=maximum_nearest,
        continuous_sector_coverage=bool(local_stations),
        status="PROVED" if local_stations else "UNRESOLVED",
        proof=(
            "The full triangular lattice has covering radius spacing/sqrt(3). "
            "Every nearest lattice point of a closed-sector point is within that radius of the sector, "
            "so it survives the exact sector-distance filter."
        ),
    )
    # Compute order before rotation; rigid motion preserves all segment lengths.
    route_length = _q4_route_length(Point(0.0, 0.0), local_stations)
    projected_actions = len(stations) * 16
    projected_virtual = 16 * (3.0 * max(len(stations) - 1, 0) + 5.0 + route_length / 5.0)
    baseline_actions = len(build_survey_plan().stations) * 20
    estimated_log = (projected_actions + baseline_actions) * ESTIMATED_LOG_BYTES_PER_ACTION
    feasible = sample_certificate.continuous_sector_coverage and projected_virtual <= MAX_VIRTUAL_SECONDS and estimated_log <= MAX_LOG_BYTES
    resource_certificate = WedgeResourceCertificate(
        projected_actions_for_16_channels=projected_actions,
        projected_route_virtual_seconds=projected_virtual,
        estimated_log_bytes=estimated_log,
        status="FEASIBLE_ESTIMATE" if feasible else "REJECTED_UNRESOLVED",
        reason="Continuous sector coverage and estimated resource caps fit." if feasible else "Reject as main fallback: coverage core unavailable or cap exceeded.",
    )
    return AnchorWedgeClearanceGrid(
        center=anchor,
        bearing_deg=bearing_deg,
        region_kind="anchor_wedge",
        spacing_m=spacing_m,
        eta_c_m=eta_c_m,
        coverage_radius_m=coverage_radius,
        stations=stations,
        sample_coverage_certificate=sample_certificate,
        resource_certificate=resource_certificate,
        bounding_box_area_m2=(x_max - x_min) * (y_max - y_min),
        route_length_m=route_length,
    )


class MeasurementResult(str, Enum):
    DIRECTION = "direction"
    NO_SIGNAL = "no_signal"
    NEAR = "near"


class AnchorPhase(str, Enum):
    ANCHORED = "anchored"
    FALLBACK_CLEAR = "fallback_clear"
    CLEAR_PENDING = "clear_pending"


class RecoveryAction(str, Enum):
    CONTINUE_PURSUIT = "continue_pursuit"
    BEGIN_CERTIFIED_CLEAR_GRID = "begin_certified_clear_grid"
    CLEAR_NOW = "clear_now"


@dataclass
class AnchorState:
    """Retain the first positive direction through all active-pursuit failures."""

    station: Point
    channel: int
    bearing_deg: float
    phase: AnchorPhase = AnchorPhase.ANCHORED
    clearance_grid: ClearanceGrid | AnchorWedgeClearanceGrid | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        if not 1 <= self.channel <= 20:
            raise ValueError("channel must be in 1..20")

    def observe_active_pursuit(self, result: MeasurementResult) -> RecoveryAction:
        if result is MeasurementResult.NEAR:
            self.phase = AnchorPhase.CLEAR_PENDING
            return RecoveryAction.CLEAR_NOW
        if result is MeasurementResult.NO_SIGNAL:
            # The anchor fields are deliberately never overwritten or cleared:
            # a directional source may simply exclude the active test point.
            self.phase = AnchorPhase.FALLBACK_CLEAR
            self.clearance_grid = build_anchor_clearance_grid(self.station, bearing_deg=self.bearing_deg)
            return RecoveryAction.BEGIN_CERTIFIED_CLEAR_GRID
        return RecoveryAction.CONTINUE_PURSUIT


class Q4ChannelState(str, Enum):
    UNKNOWN = "unknown"
    PRESENT_UNRESOLVED = "present_unresolved"
    CLEARED = "cleared"
    ABSENT_CERTIFIED = "absent_certified"


@dataclass(frozen=True)
class Q4ExecutionResult:
    channel_states: dict[int, str]
    channel_evidence: dict[int, tuple[str, ...]]
    complete: bool


def _response_field(response: Any, name: str, default: Any = None) -> Any:
    if isinstance(response, dict):
        return response.get(name, default)
    if name == "accepted" and (isinstance(response, str) or hasattr(response, "result")):
        return True
    if isinstance(response, str):
        if name in {"result", "measure_result", "clear_result"}:
            return response
        if name == "success":
            return response == "success"
    return getattr(response, name, default)


def execute_q4_strategy(
    robot: Any, public_state: Any, *, precleared_channels: Iterable[int] = ()
) -> Q4ExecutionResult:
    """Duck-typed certified Q4 station survey with narrow-wedge clear fallback."""
    del public_state
    plan = build_survey_plan()
    stations = plan.route
    precleared = frozenset(precleared_channels)
    if any(not isinstance(channel, int) or isinstance(channel, bool) or not 1 <= channel <= 20 for channel in precleared):
        raise ValueError("precleared_channels must contain channel integers in 1..20")
    states: dict[int, Q4ChannelState] = {
        channel: Q4ChannelState.CLEARED if channel in precleared else Q4ChannelState.UNKNOWN
        for channel in range(1, 21)
    }
    no_signal: dict[int, set[int]] = {channel: set() for channel in range(1, 21)}
    evidence: dict[int, list[str]] = {
        channel: ["precleared_fast_path"] if channel in precleared else []
        for channel in range(1, 21)
    }
    pending_grids: dict[int, AnchorWedgeClearanceGrid] = {}
    for station_id, station in enumerate(stations):
        for channel in range(1, 21):
            if states[channel] is not Q4ChannelState.UNKNOWN:
                continue
            response = robot.measure(station, channel)
            accepted = _response_field(response, "accepted", False) is True
            result = _response_field(response, "result", _response_field(response, "measure_result", None))
            if not accepted or result is None:
                evidence[channel].append("rejected_measure")
                continue
            evidence[channel].append(str(result))
            if result == "no_signal":
                no_signal[channel].add(station_id)
                if len(no_signal[channel]) == len(stations):
                    states[channel] = Q4ChannelState.ABSENT_CERTIFIED
                continue
            if result == "near":
                clear_response = robot.clear(station, channel)
                if _response_field(clear_response, "accepted", False) is True and _response_field(clear_response, "success", _response_field(clear_response, "clear_result", None) == "success"):
                    states[channel] = Q4ChannelState.CLEARED
                    evidence[channel].append("near_clear_success")
                else:
                    states[channel] = Q4ChannelState.PRESENT_UNRESOLVED
                continue
            if result != "direction":
                evidence[channel].append("unknown_measure_result")
                continue
            bearing = _response_field(response, "svd_deg", None)
            if bearing is None:
                states[channel] = Q4ChannelState.PRESENT_UNRESOLVED
                evidence[channel].append("direction_without_bearing_unresolved")
                continue
            grid = build_anchor_clearance_grid(station, bearing_deg=float(bearing))
            evidence[channel].append(grid.resource_certificate.status)
            if grid.resource_certificate.status != "FEASIBLE_ESTIMATE":
                states[channel] = Q4ChannelState.PRESENT_UNRESOLVED
                continue
            states[channel] = Q4ChannelState.PRESENT_UNRESOLVED
            pending_grids[channel] = grid
    clear_start = stations[-1] if stations else Point(0.0, 0.0)
    tasks = tuple((channel, grid.stations) for channel, grid in sorted(pending_grids.items()))
    for channel, point in multi_source_clear_route(clear_start, tasks):
        if states[channel] is not Q4ChannelState.PRESENT_UNRESOLVED:
            continue
        clear_response = robot.clear(point, channel)
        if _response_field(clear_response, "accepted", False) is True and _response_field(clear_response, "success", _response_field(clear_response, "clear_result", None) == "success"):
            states[channel] = Q4ChannelState.CLEARED
            evidence[channel].append("cleared_by_anchor_wedge")
    complete = sum(state is Q4ChannelState.CLEARED for state in states.values()) >= 16 or all(
        state in (Q4ChannelState.CLEARED, Q4ChannelState.ABSENT_CERTIFIED) for state in states.values()
    )
    return Q4ExecutionResult(
        channel_states={channel: state.value for channel, state in states.items()},
        channel_evidence={channel: tuple(items) for channel, items in evidence.items()},
        complete=complete,
    )
