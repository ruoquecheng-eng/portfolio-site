"""Optional, passive telemetry for frozen Q4 strategy replay.

The wrapper delegates every public action unchanged.  It is intentionally not
imported by normal runtime entries, so telemetry cannot participate in a
decision.
"""
from __future__ import annotations

from dataclasses import asdict
from math import hypot
from typing import Any

from shapely import get_coordinates, minimum_bounding_circle
from shapely.geometry import Point as ShapelyPoint

from . import q4, q4_extreme
from .q4_mbfc import _region


class RecoveryTelemetry:
    def __init__(self, seed: int) -> None:
        self.seed = seed
        self.snapshots: list[dict[str, Any]] = []
        self.actions: list[dict[str, Any]] = []
        self._context: dict[str, Any] = {"global_phase": "INIT", "source_channel": None, "state": None}
        self.source_observations: dict[int, list[tuple[q4.Point, float]]] = {}
        self._index = 0

    def wrap(self, robot: Any) -> "TelemetryRobot":
        return TelemetryRobot(robot, self)

    def context(self, **values: Any) -> None:
        self._context.update(values)

    def feasible(self, observations: list[tuple[q4.Point, float]] | None) -> dict[str, Any] | None:
        if not observations:
            return None
        region = _region(tuple(observations))
        if region.is_empty:
            return {"representation": "MBFC_A_OUTER_SHAPELY_POLYGON", "empty": True}
        coords = get_coordinates(region)
        # Shapely's enclosing circle is an enclosing disk of the runtime's
        # actual outer polygon.  The additive tolerance is conservative.
        circle = minimum_bounding_circle(region)
        cx, cy = circle.centroid.x, circle.centroid.y
        max_vertex = max((hypot(x - cx, y - cy) for x, y in coords), default=0.0)
        radius = max_vertex + 1e-8
        x0, y0, x1, y1 = region.bounds
        return {"representation": "MBFC_A_OUTER_SHAPELY_POLYGON", "vertex_count": len(coords),
                "vertices": [[float(x), float(y)] for x, y in coords], "area_m2": region.area,
                "diameter_upper_m": hypot(x1 - x0, y1 - y0), "centroid": [region.centroid.x, region.centroid.y],
                "bounding_box": [x0, y0, x1, y1], "mec_algorithm": "shapely.minimum_bounding_circle",
                "mec_tolerance_m": 1e-8, "mec_center": [cx, cy], "mec_radius": radius,
                "certified_mec_radius_upper_bound": radius,
                "mec_encloses_every_serialized_vertex": True, "maximum_vertex_to_center_distance": max_vertex}

    def snapshot(self, robot: Any, *, kind: str, states: dict[int, Any] | None = None,
                 observations: dict[int, list[tuple[q4.Point, float]]] | None = None,
                 route_remaining: int | None = None, current_route_target: q4.Point | None = None,
                 jobs: list[dict[str, Any]] | None = None, **extra: Any) -> None:
        state = robot.public_state
        previous = self.actions[-1] if self.actions else None
        resolved = states or {}
        source = self._context.get("source_channel")
        observation_map = observations if observations is not None else self.source_observations
        obs = observation_map.get(source, []) if source is not None else []
        self.snapshots.append({"seed": self.seed, "decision_index": self._index, "decision_kind": kind,
                               "virtual_time_s": state.virtual_time_s, "robot_position": [state.position.x, state.position.y],
                               "current_measure_channel": state.measure_channel, "global_phase": self._context.get("global_phase"),
                               "previous_action_type": None if previous is None else previous["action_type"],
                               "previous_action_position": None if previous is None else previous["to_position"],
                               "previous_action_channel": None if previous is None else previous["channel"],
                               "source_currently_handled": source, "source_state": self._context.get("state"),
                               "unresolved_channels": [c for c, v in resolved.items() if getattr(v, "value", v) == "PRESENT_UNRESOLVED"],
                               "discovered_channels": sorted(observation_map.keys()),
                               "cleared_channels": [c for c, v in resolved.items() if getattr(v, "value", v) == "CLEARED"],
                               "certificate_stations_remaining": route_remaining, "current_certificate_route_index": None,
                               "fallback_active": self._context.get("global_phase") == "FALLBACK", "final_certificate_active": False,
                               "current_route_target": None if current_route_target is None else [current_route_target.x, current_route_target.y],
                               "pending_jobs": jobs or [], "serializable_multi_job_point": sum(x.get("currently_eligible", False) for x in (jobs or [])) >= 2,
                               "source_snapshot": None if source is None else {"channel": source, "positive_bearing_count": len(obs),
                                  "positive_bearing_observations": [[[p.x, p.y], bearing] for p, bearing in obs],
                                  "feasible_region": self.feasible(obs)}, **extra})
        self._index += 1


class TelemetryRobot:
    def __init__(self, robot: Any, telemetry: RecoveryTelemetry) -> None:
        self._robot, self._telemetry = robot, telemetry

    @property
    def public_state(self):
        return self._robot.public_state

    def _record(self, kind: str, position: q4.Point, channel: int, call):
        before = self.public_state
        response = call()
        after = self.public_state
        result = q4_extreme._field(response, "result", "measure_result", "clear_result", "success")
        self._telemetry.actions.append({"seed": self._telemetry.seed, "action_index": len(self._telemetry.actions),
            "decision_context": dict(self._telemetry._context), "action_type": kind,
            "from_position": [before.position.x, before.position.y], "to_position": [position.x, position.y],
            "move_distance_m": hypot(position.x - before.position.x, position.y - before.position.y),
            "move_time_s": hypot(position.x - before.position.x, position.y - before.position.y) / 5.0,
            "channel": channel, "result": result, "virtual_time_before_s": before.virtual_time_s,
            "virtual_time_after_s": after.virtual_time_s})
        return response

    def measure(self, position: q4.Point, channel: int):
        return self._record("measure", position, channel, lambda: self._robot.measure(position, channel))

    def clear(self, position: q4.Point, channel: int):
        return self._record("clear", position, channel, lambda: self._robot.clear(position, channel))
