"""Deterministic RoutingPlus planner for live Q4 jobs.

Pure routing state only: it cannot alter feasible regions or channel states.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from math import atan2
from typing import Iterable
from .q4 import Point

@dataclass(frozen=True)
class LiveJob:
    key: tuple
    kind: str
    target: Point
    channel: int | None = None
    candidates: tuple[Point, ...] = ()

def _dist(a: Point,b: Point)->float: return a.distance_to(b)
def _length(start: Point,jobs: tuple[LiveJob,...],route: list[int])->float:
    total=0.; cur=start
    for i in route: total+=_dist(cur,jobs[i].target);cur=jobs[i].target
    return total

class RoutingPlus:
    def __init__(self)->None:
        self.previous: tuple[tuple,...]=()
        self.calls=0; self.twoopt_gain=0.; self.oropt_gain=0.; self.warm_uses=0
    def _nn(self,start:Point,jobs:tuple[LiveJob,...])->list[int]:
        left=set(range(len(jobs)));out=[];cur=start
        while left:
            i=min(left,key=lambda k:(_dist(cur,jobs[k].target),jobs[k].key));out.append(i);left.remove(i);cur=jobs[i].target
        return out
    def _insert(self,start:Point,jobs:tuple[LiveJob,...])->list[int]:
        left=set(range(len(jobs))); route=[max(left,key=lambda i:(_dist(start,jobs[i].target),jobs[i].key))];left.remove(route[0])
        while left:
            cand=[]
            for i in left:
                for p in range(len(route)+1):
                    a=start if p==0 else jobs[route[p-1]].target;b=None if p==len(route) else jobs[route[p]].target
                    cand.append((_dist(a,jobs[i].target)+(0 if b is None else _dist(jobs[i].target,b)-_dist(a,b)),i,p))
            _,i,p=min(cand);route.insert(p,i);left.remove(i)
        return route
    def _twoopt(self,start:Point,jobs:tuple[LiveJob,...],route:list[int])->list[int]:
        route=list(route); improved=True
        while improved:
            improved=False;base=_length(start,jobs,route);best=route
            for i in range(len(route)-1):
                for j in range(i+1,len(route)):
                    trial=route[:i]+route[i:j+1][::-1]+route[j+1:]
                    if _length(start,jobs,trial)<_length(start,jobs,best)-1e-9:best=trial
            if _length(start,jobs,best)<base-1e-9:route=best;improved=True
        return route
    def _oropt(self,start:Point,jobs:tuple[LiveJob,...],route:list[int])->list[int]:
        route=list(route)
        for _ in range(12):
            baseline=_length(start,jobs,route); best=baseline; winner=None; n=len(route)
            for size in range(1,min(3,n-1)+1):
                for first in range(n-size+1):
                    chain=route[first:first+size]; rest=route[:first]+route[first+size:]
                    for insert in range(len(rest)+1):
                        variants=(chain,chain[::-1]) if size>1 else (chain,)
                        for variant in variants:
                            trial=rest[:insert]+variant+rest[insert:]
                            length=_length(start,jobs,trial)
                            if length<best-1e-9:best,winner=length,trial
            if winner is None:break
            route=self._twoopt(start,jobs,winner)
        return route
    def choose(self,start:Point,jobs:Iterable[LiveJob])->LiveJob|None:
        jobs=tuple(jobs)
        if not jobs:return None
        self.calls+=1
        angular=sorted(range(len(jobs)),key=lambda i:(atan2(jobs[i].target.y,jobs[i].target.x),jobs[i].key))
        if angular:
            cut=min(range(len(angular)),key=lambda i:_dist(start,jobs[angular[i]].target));angular=angular[cut:]+angular[:cut]
        seeds=[self._nn(start,jobs),self._insert(start,jobs),angular,[angular[0]]+angular[:0:-1] if len(angular)>1 else angular]
        keys={job.key:i for i,job in enumerate(jobs)}
        warm=[keys[k] for k in self.previous if k in keys]
        if warm:
            warm += [i for i in range(len(jobs)) if i not in warm];seeds.append(warm);self.warm_uses+=1
        initial=min(_length(start,jobs,s) for s in seeds)
        route=min((self._twoopt(start,jobs,s) for s in seeds),key=lambda r:_length(start,jobs,r))
        after_two=_length(start,jobs,route);self.twoopt_gain+=max(0.,initial-after_two)
        route=self._oropt(start,jobs,route);self.oropt_gain+=max(0.,after_two-_length(start,jobs,route))
        self.previous=tuple(jobs[i].key for i in route);return jobs[route[0]]


class RegionNN:
    """Select one live job and one legal finite service point."""
    def __init__(self, *, alternating: bool = False, rounds: int = 3) -> None:
        self.alternating=alternating;self.rounds=rounds;self.calls=0;self.service_gain_m=0.0
    @staticmethod
    def _points(job: LiveJob) -> tuple[Point, ...]: return job.candidates or (job.target,)
    def choose(self, start: Point, jobs: Iterable[LiveJob]) -> LiveJob | None:
        values=tuple(jobs)
        if not values:return None
        self.calls+=1
        if not self.alternating:
            job,point=min(((job,point) for job in values for point in self._points(job)),key=lambda item:(_dist(start,item[1]),item[0].key,item[1].x,item[1].y))
            return replace(job,target=point)
        working=tuple(replace(job,target=min(self._points(job),key=lambda point:(_dist(start,point),point.x,point.y))) for job in values)
        helper=RoutingPlus();route=helper._nn(start,working)
        for _ in range(self.rounds):
            before=_length(start,working,route);mutable=list(working)
            for pos,index in enumerate(route):
                prev=start if pos==0 else mutable[route[pos-1]].target
                nxt=None if pos+1==len(route) else mutable[route[pos+1]].target
                target=min(self._points(values[index]),key=lambda point:(_dist(prev,point)+(0. if nxt is None else _dist(point,nxt)),point.x,point.y))
                mutable[index]=replace(values[index],target=target)
            working=tuple(mutable);self.service_gain_m+=max(0.,before-_length(start,working,route));route=helper._twoopt(start,working,route);route=helper._oropt(start,working,route)
        return working[route[0]]
