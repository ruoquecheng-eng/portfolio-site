"""Survey-integrated Q4 acceleration candidates with the CP08 proof path intact.

Both candidates execute the same certified CP08 station survey. They only add
bounded actions after a public ``direction`` observation; a failed shortcut is
left for CP08's existing anchor-wedge clearance route.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import cos, radians, sin
from typing import Any, Iterable

from b_problem.localization.q4_all_bearing import BearingObservation, all_positive_bearing_fit, point_satisfies_bearing_set

from . import q4


Point = q4.Point
LOS_PURSUIT_M = 400.0
CROSS_RANGE_M = 300.0
FAST_C_PURSUIT_M = 300.0
LOCAL_CORRECTION_M = 15.0
MAX_LOCAL_CORRECTIONS = 4


@dataclass(frozen=True)
class PositiveAnchor:
    """One CP08-certified direction observation retained for fallback."""

    channel: int
    station: Point
    bearing_deg: float


def _field(response: Any, *names: str) -> Any:
    if isinstance(response, dict):
        for name in names:
            if name in response:
                return response[name]
    for name in names:
        if hasattr(response, name):
            return getattr(response, name)
    if isinstance(response, str) and any(name in {"result", "measure_result", "clear_result"} for name in names):
        return response
    return None


def _accepted(response: Any) -> bool:
    return _field(response, "accepted") is not False


def _step(point: Point, bearing_deg: float, distance_m: float) -> Point:
    angle = radians(bearing_deg)
    return Point(point.x + distance_m * cos(angle), point.y + distance_m * sin(angle))


def _cross(first: Point, second: Point) -> float:
    return first.x * second.y - first.y * second.x


def triangulated_early_estimate(
    anchor: PositiveAnchor, second_station: Point, second_bearing_deg: float
) -> Point | None:
    """Intersect two forward public bearing rays, rejecting parallel/backward rays."""
    first_direction = _step(Point(0.0, 0.0), anchor.bearing_deg, 1.0)
    second_direction = _step(Point(0.0, 0.0), second_bearing_deg, 1.0)
    denominator = _cross(first_direction, second_direction)
    if abs(denominator) <= 1e-9:
        return None
    delta = Point(second_station.x - anchor.station.x, second_station.y - anchor.station.y)
    first_scale = _cross(delta, second_direction) / denominator
    second_scale = _cross(delta, first_direction) / denominator
    if first_scale < 0.0 or second_scale < 0.0:
        return None
    estimate = Point(
        anchor.station.x + first_scale * first_direction.x,
        anchor.station.y + first_scale * first_direction.y,
    )
    return estimate if estimate.radius() <= q4.TARGET_RADIUS_M + 1e-6 else None


def _clear_succeeded(response: Any) -> bool:
    return _accepted(response) and _field(response, "success", "clear_result") in (True, "success")


def order_positive_anchors(start: Point, anchors: Iterable[PositiveAnchor]) -> tuple[PositiveAnchor, ...]:
    """Rolling nearest-anchor ordering used by the batched candidate.

    The ordering changes only shortcut travel; every retained anchor remains in
    the CP08 fallback set regardless of its position here.
    """
    remaining = list(anchors)
    ordered: list[PositiveAnchor] = []
    current = start
    while remaining:
        index, chosen = min(
            enumerate(remaining),
            key=lambda item: (current.distance_to(item[1].station), item[1].channel),
        )
        ordered.append(chosen)
        current = chosen.station
        remaining.pop(index)
    return tuple(ordered)


def _try_fast_clear(robot: Any, channel: int, point: Point, *, corrections: bool) -> bool:
    """Early clear, with local corrections reserved for a ``near`` witness."""
    attempts = [point]
    if corrections:
        for dx, dy in ((LOCAL_CORRECTION_M, 0.0), (-LOCAL_CORRECTION_M, 0.0),
                       (0.0, LOCAL_CORRECTION_M), (0.0, -LOCAL_CORRECTION_M))[:MAX_LOCAL_CORRECTIONS]:
            attempts.append(Point(point.x + dx, point.y + dy))
    return any(_clear_succeeded(robot.clear(candidate, channel)) for candidate in attempts)


def _los_pursuit(robot: Any, anchor: PositiveAnchor) -> bool:
    """FAST-A's deliberately weaker co-linear control, retained as a comparator."""
    probe = _step(anchor.station, anchor.bearing_deg, LOS_PURSUIT_M)
    response = robot.measure(probe, anchor.channel)
    if not _accepted(response):
        return False
    result = _field(response, "result", "measure_result")
    if result == "near":
        return _try_fast_clear(robot, anchor.channel, probe, corrections=True)
    if result != "direction":
        return False
    bearing = _field(response, "svd_deg")
    if bearing is None:
        return False
    return _try_fast_clear(
        robot, anchor.channel, _step(probe, float(bearing), LOS_PURSUIT_M), corrections=False
    )


def _cross_range_pursuit(robot: Any, anchor: PositiveAnchor, *, speculative: bool) -> bool:
    """FAST-B/C: short pursuit, one lateral bearing, and bounded clear candidates."""
    pursuit = _step(anchor.station, anchor.bearing_deg, LOS_PURSUIT_M)
    pursuit_response = robot.measure(pursuit, anchor.channel)
    if not _accepted(pursuit_response):
        return False
    pursuit_result = _field(pursuit_response, "result", "measure_result")
    if pursuit_result == "no_signal":
        # One inexpensive return-to-certified-anchor recovery, then preserve
        # the existing wedge proof instead of widening an unobserved search.
        robot.measure(anchor.station, anchor.channel)
        return False
    if pursuit_result == "near":
        return _try_fast_clear(robot, anchor.channel, pursuit, corrections=True)
    if pursuit_result != "direction":
        return False
    pursuit_bearing = _field(pursuit_response, "svd_deg")
    if pursuit_bearing is None:
        return False
    if speculative and _try_fast_clear(robot, anchor.channel, pursuit, corrections=False):
        return True
    # Direction alone carries no range. A lateral second station produces the
    # non-parallel ray needed for an independently derived point estimate.
    for sign in (1.0, -1.0):
        lateral = _step(pursuit, float(pursuit_bearing) + sign * 90.0, CROSS_RANGE_M)
        lateral_response = robot.measure(lateral, anchor.channel)
        if not _accepted(lateral_response):
            continue
        lateral_result = _field(lateral_response, "result", "measure_result")
        if lateral_result == "no_signal":
            continue
        if lateral_result == "near" and _try_fast_clear(robot, anchor.channel, lateral, corrections=True):
            return True
        if lateral_result != "direction":
            continue
        lateral_bearing = _field(lateral_response, "svd_deg")
        if lateral_bearing is None:
            continue
        estimate = triangulated_early_estimate(anchor, lateral, float(lateral_bearing))
        if estimate is not None and _try_fast_clear(robot, anchor.channel, estimate, corrections=True):
            return True
    return False


def _direct_cross_range_pursuit(robot: Any, anchor: PositiveAnchor) -> bool:
    """FAST-C: omit the co-linear remeasure and acquire the lateral ray directly."""
    pursuit = _step(anchor.station, anchor.bearing_deg, FAST_C_PURSUIT_M)
    for sign in (1.0, -1.0):
        lateral = _step(pursuit, anchor.bearing_deg + sign * 90.0, CROSS_RANGE_M)
        telemetry = getattr(robot, "_telemetry", None)
        if telemetry is not None:
            telemetry.context(global_phase="SOURCE_HANDLER", source_channel=anchor.channel,
                              state="SECOND_BEARING" if sign > 0 else "LOCALIZATION_RECOVERY",
                              trigger_function="_direct_cross_range_pursuit",
                              trigger_reason="scheduled_lateral_bearing",
                              trigger_values={"lateral_sign": sign, "cross_range_m": CROSS_RANGE_M})
            telemetry.snapshot(robot, kind="RECOVERY_DECISION" if sign < 0 else "SOURCE_HANDLER",
                               current_route_target=lateral,
                               jobs=[{"job_id": f"lateral_{anchor.channel}_{sign}", "job_type": "SOURCE_LOCALIZATION",
                                      "source_channel": anchor.channel, "target_position": [lateral.x, lateral.y],
                                      "reason": "fast_c_lateral_bearing", "currently_eligible": True,
                                      "distance_from_robot": _robot_position(robot, lateral).distance_to(lateral),
                                      "estimated_move_time": _robot_position(robot, lateral).distance_to(lateral)/5,
                                      "source_state": "PRESENT_UNRESOLVED", "correctness_dependency": "CP08_anchor_fallback_retained"}])
        response = robot.measure(lateral, anchor.channel)
        if not _accepted(response):
            continue
        result = _field(response, "result", "measure_result")
        if result == "no_signal":
            continue
        if result == "near" and _try_fast_clear(robot, anchor.channel, lateral, corrections=True):
            return True
        if result != "direction":
            continue
        bearing = _field(response, "svd_deg")
        if bearing is None:
            continue
        estimate = triangulated_early_estimate(anchor, lateral, float(bearing))
        if estimate is not None:
            if telemetry is not None:
                telemetry.context(global_phase="SOURCE_HANDLER", source_channel=anchor.channel, state="CLEAR_APPROACH",
                                  trigger_function="triangulated_early_estimate", trigger_reason="two_positive_bearings",
                                  trigger_values={"lateral_sign": sign})
                telemetry.snapshot(robot, kind="CLEAR_DECISION", current_route_target=estimate,
                                   jobs=[{"job_id": f"clear_{anchor.channel}", "job_type": "SOURCE_CLEAR", "source_channel": anchor.channel,
                                          "target_position": [estimate.x, estimate.y], "reason": "triangulated_early_estimate",
                                          "currently_eligible": True, "distance_from_robot": _robot_position(robot, estimate).distance_to(estimate),
                                          "estimated_move_time": _robot_position(robot, estimate).distance_to(estimate)/5,
                                          "source_state": "PRESENT_UNRESOLVED", "correctness_dependency": "CP08_anchor_fallback_retained"}])
        if estimate is not None and _try_fast_clear(robot, anchor.channel, estimate, corrections=True):
            return True
    return False


def _direct_cross_range_pursuit_all_bearing(robot: Any, anchor: PositiveAnchor) -> bool:
    """SMAR-0: reuse both scheduled lateral measurements before one heuristic clear.

    There is no new observation waypoint here.  The conservative anchor wedge
    remains untouched and is used by CERT-D if the numeric shortcut fails.
    """
    pursuit = _step(anchor.station, anchor.bearing_deg, FAST_C_PURSUIT_M)
    observations = [BearingObservation(anchor.station, anchor.bearing_deg)]
    for sign in (1.0, -1.0):
        lateral = _step(pursuit, anchor.bearing_deg + sign * 90.0, CROSS_RANGE_M)
        response = robot.measure(lateral, anchor.channel)
        if not _accepted(response):
            continue
        result = _field(response, "result", "measure_result")
        if result == "near" and _try_fast_clear(robot, anchor.channel, lateral, corrections=True):
            return True
        if result != "direction":
            continue
        bearing = _field(response, "svd_deg")
        if bearing is not None:
            observations.append(BearingObservation(lateral, float(bearing)))
    fit = all_positive_bearing_fit(observations)
    if fit.degenerate or fit.estimate is None or fit.estimate.radius() > q4.TARGET_RADIUS_M + 1e-6:
        return False
    # This is a public-wedge/range gate, not a probabilistic confidence claim.
    # It prevents a numerical fit outside the broadest possible receive domain;
    # exact 1000 m versus 1500 m radius remains unknown until a clear response.
    if not point_satisfies_bearing_set(fit.estimate, observations, max_range_m=1500.0):
        return False
    return _try_fast_clear(robot, anchor.channel, fit.estimate, corrections=True)


def _robot_position(robot: Any, fallback: Point) -> Point:
    state = getattr(robot, "public_state", None)
    if callable(state):
        state = state()
    position = getattr(state, "position", None)
    if position is None:
        return fallback
    return Point(float(position.x), float(position.y))


def execute_q4_survey_speed_strategy(
    robot: Any,
    public_state: Any,
    *,
    candidate: str = "fast_b",
    channels: Iterable[int] = range(1, 21),
    max_shortcuts: int | None = None,
) -> q4.Q4ExecutionResult:
    """Run FAST-A/FAST-B inside CP08's certified survey and clearance route."""
    if candidate not in {"fast_a", "fast_b", "fast_c"}:
        raise ValueError("candidate must be fast_a, fast_b, or fast_c")
    if max_shortcuts is not None and max_shortcuts < 0:
        raise ValueError("max_shortcuts must be non-negative or None")
    selected = tuple(channels)
    plan = q4.build_survey_plan()
    states = {channel: "UNKNOWN" for channel in selected}
    evidence = {channel: [] for channel in selected}
    no_signal = {channel: set() for channel in selected}
    pending_grids: dict[int, q4.AnchorWedgeClearanceGrid] = {}
    shortcut_attempts = 0

    for station_id, station in enumerate(plan.route):
        batch: list[PositiveAnchor] = []
        for channel in selected:
            if states[channel] != "UNKNOWN":
                continue
            response = robot.measure(station, channel)
            if not _accepted(response):
                continue
            result = _field(response, "result", "measure_result")
            if result == "no_signal":
                no_signal[channel].add(station_id)
                if len(no_signal[channel]) == len(plan.route):
                    states[channel] = q4.Q4ChannelState.ABSENT_CERTIFIED
                    evidence[channel].append("absent_certified")
                continue
            if result == "near":
                if _clear_succeeded(robot.clear(station, channel)):
                    states[channel] = q4.Q4ChannelState.CLEARED
                    evidence[channel].append("cleared_at_survey_station")
                else:
                    states[channel] = q4.Q4ChannelState.PRESENT_UNRESOLVED
                continue
            if result != "direction":
                continue
            bearing = _field(response, "svd_deg")
            if bearing is None:
                continue
            anchor = PositiveAnchor(channel, station, float(bearing))
            grid = q4.build_anchor_clearance_grid(station, bearing_deg=float(bearing))
            if grid is None:
                continue
            states[channel] = q4.Q4ChannelState.PRESENT_UNRESOLVED
            pending_grids[channel] = grid
            evidence[channel].append("positive_anchor_retained")
            if candidate == "fast_a":
                if max_shortcuts is not None and shortcut_attempts >= max_shortcuts:
                    evidence[channel].append("fast_a_time_debt_fallback")
                elif _los_pursuit(robot, anchor):
                    shortcut_attempts += 1
                    states[channel] = q4.Q4ChannelState.CLEARED
                    pending_grids.pop(channel, None)
                    evidence[channel].append("fast_a_los_clear")
                else:
                    shortcut_attempts += 1
                    evidence[channel].append("fast_a_anchor_wedge_fallback")
            else:
                batch.append(anchor)
        if candidate in {"fast_b", "fast_c"}:
            for anchor in order_positive_anchors(station, batch):
                if states[anchor.channel] is not q4.Q4ChannelState.PRESENT_UNRESOLVED:
                    continue
                if max_shortcuts is not None and shortcut_attempts >= max_shortcuts:
                    evidence[anchor.channel].append(f"{candidate}_time_debt_fallback")
                elif (
                    _direct_cross_range_pursuit(robot, anchor)
                    if candidate == "fast_c"
                    else _cross_range_pursuit(robot, anchor, speculative=False)
                ):
                    shortcut_attempts += 1
                    states[anchor.channel] = q4.Q4ChannelState.CLEARED
                    pending_grids.pop(anchor.channel, None)
                    evidence[anchor.channel].append(f"{candidate}_cross_range_clear")
                else:
                    shortcut_attempts += 1
                    evidence[anchor.channel].append(f"{candidate}_anchor_wedge_fallback")

    tasks = [
        (channel, grid.stations)
        for channel, grid in sorted(pending_grids.items())
        if states[channel] is q4.Q4ChannelState.PRESENT_UNRESOLVED
    ]
    for channel, point in q4.multi_source_clear_route(_robot_position(robot, plan.route[-1]), tuple(tasks)):
        if states[channel] is not q4.Q4ChannelState.PRESENT_UNRESOLVED:
            continue
        if _clear_succeeded(robot.clear(point, channel)):
            states[channel] = q4.Q4ChannelState.CLEARED
            evidence[channel].append("cleared_by_anchor_wedge")
    complete = sum(state is q4.Q4ChannelState.CLEARED for state in states.values()) >= 16 or all(
        state in (q4.Q4ChannelState.CLEARED, q4.Q4ChannelState.ABSENT_CERTIFIED)
        for state in states.values()
    )
    return q4.Q4ExecutionResult(
        channel_states={channel: state.value for channel, state in states.items()},
        channel_evidence={channel: tuple(items) for channel, items in evidence.items()},
        complete=complete,
    )
