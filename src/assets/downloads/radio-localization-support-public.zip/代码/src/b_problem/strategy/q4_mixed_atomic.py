"""Atomic mixed SCAN/SOURCE runtime for the certified Q4 experiment line."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Iterable
from types import SimpleNamespace
from . import q4, q4_extreme
from .q4_cert_d import CertDExecutionResult, CertDStationCertificate, _runtime_certificate_is_valid, _shared_baseline
from .q4_mbfc import build_mbfc_cover
from .q4_routingplus import LiveJob, RoutingPlus, RegionNN
from .q4_region_speed import clear_service_candidates, localization_candidates, positive_outer_vertices
from .q4_static_routing import FutureRouteTrace
from b_problem.localization.q4_pair_certificate import PairBinding
from .q34_receding_horizon import RecedingHorizonPlanner

@dataclass
class SourceSession:
    anchor: q4_extreme.PositiveAnchor
    observations: list[tuple[q4.Point,float]]
    fallback: tuple[q4.Point,...]
    phase: str="LOCALIZE"
    lateral_sign: int=1
    target: q4.Point|None=None
    fallback_index: int=0
    fallback_attempted:set[q4.Point]=field(default_factory=set)
    snapshot_version:int=0
    pair_binding:PairBinding|None=None
    failed_clear_exclusions:set[q4.Point]=field(default_factory=set)

@dataclass
class MixedTelemetry:
    decisions:list[dict]=field(default_factory=list)
    selected:dict[str,int]=field(default_factory=dict)
    planner:dict=field(default_factory=dict)
    region_history:list[dict]=field(default_factory=list)

def _lateral(session:SourceSession)->q4.Point:
    pursuit=q4_extreme._step(session.anchor.station,session.anchor.bearing_deg,q4_extreme.FAST_C_PURSUIT_M)
    return q4_extreme._step(pursuit,session.anchor.bearing_deg+90.0*session.lateral_sign,q4_extreme.CROSS_RANGE_M)

def _source_job(session:SourceSession,ch:int,*,current:q4.Point|None=None,next_scan:q4.Point|None=None,region_clear:bool=False,region_probe:bool=False,region_fallback:bool=False)->LiveJob|None:
    if session.phase=="LOCALIZE":
        candidates=localization_candidates(session.anchor,route_goal=next_scan) if region_probe else ()
        return LiveJob(("source",ch,"localize",session.lateral_sign),"SOURCE_LOCALIZATION_STEP",_lateral(session),ch,candidates)
    if session.phase=="CLEAR" and session.target is not None:
        candidates=clear_service_candidates(positive_outer_vertices(session.observations),current=current,next_goal=next_scan) if region_clear and current is not None else ()
        return LiveJob(("source",ch,"clear"),"SOURCE_CLEAR_STEP",session.target,ch,candidates)
    if session.phase=="FALLBACK":
        remaining=tuple(point for point in session.fallback if point not in session.fallback_attempted)
        if not remaining:return None
        # Failed clears form an auxiliary non-convex ledger.  It ranks cover
        # witnesses away from already disproved 20 m disks but never cuts the
        # convex hard source representation or certifies a result.
        ordered=tuple(sorted(remaining,key=lambda point:(-min((point.distance_to(old) for old in session.failed_clear_exclusions),default=0.0),current.distance_to(point),point.x,point.y))) if region_fallback and current is not None else remaining
        return LiveJob(("source",ch,"fallback",len(session.fallback_attempted)),"SOURCE_FALLBACK_STEP",ordered[0],ch,ordered[:4] if region_fallback else ())
    return None

def _prepare_fallback(session:SourceSession)->None:
    mbfc=build_mbfc_cover(tuple(session.observations),session.fallback)
    if mbfc.enabled:session.fallback=mbfc.candidates
    session.phase="FALLBACK"

def execute_q4_mixed_atomic(
    robot:Any, public_state:Any, certificate:CertDStationCertificate, *, channels:Iterable[int]=range(1,21),
    routingplus:bool=True, shared_baseline:bool=True, telemetry:MixedTelemetry|None=None,
    region_clear:bool=False, region_probe:bool=False, region_fallback:bool=False, alternating_region:bool=False,
    paired_negative:bool=False, adaptive_certificate_rotation:bool=False, early16:bool=True,
    receding_horizon:bool=False, rh_k:int=8, rh_cheap_twoopt:bool=False, rh_rollout:bool=False,
)->CertDExecutionResult:
    """Execute one live job at a time; source jobs issue exactly one public action."""
    if not _runtime_certificate_is_valid(certificate):
        return CertDExecutionResult(q4.execute_q4_strategy(robot,public_state),(),False)
    # The directional-shadow position cut remains disabled until independently
    # derived for this API.  ``paired_negative`` therefore enables only the
    # identity-bound evidence ledger, never a Q4 source-position contraction.
    if adaptive_certificate_rotation:
        from .q4_mincert import rotated_21point_certificate
        current=q4_extreme._robot_position(robot,q4.Point(0.,0.))
        candidates=tuple(rotated_21point_certificate(angle) for angle in range(0,30,3))
        certificate=min(candidates,key=lambda item:min(current.distance_to(point) for point in item.stations))
    selected=tuple(channels); states={ch:"UNKNOWN" for ch in selected}; evidence={ch:[] for ch in selected}
    no_signal={ch:set() for ch in selected}; sessions:dict[int,SourceSession]={}; positive:dict[int,list[tuple[q4.Point,float]]]={}
    unvisited=set(certificate.stations); planner=RoutingPlus(); region_planner=RegionNN(alternating=alternating_region,rounds=2)
    rh=RecedingHorizonPlanner(k=rh_k,cheap_twoopt=rh_cheap_twoopt,rollout=rh_rollout); trace:list[FutureRouteTrace]=[]; tel=telemetry or MixedTelemetry(); scan_index=0
    previous_route:tuple[LiveJob,...]=()
    while unvisited or any(states[ch] is q4.Q4ChannelState.PRESENT_UNRESOLVED for ch in selected):
        if early16 and sum(s is q4.Q4ChannelState.CLEARED for s in states.values())>=16:
            break
        current=q4_extreme._robot_position(robot,q4.Point(0.,0.)); jobs=[]
        jobs.extend(LiveJob(("scan",p.x,p.y),"CERT_SCAN",p) for p in unvisited)
        next_scan=min(unvisited,key=lambda point:(current.distance_to(point),point.x,point.y)) if unvisited else None
        jobs.extend(job for ch,s in sorted(sessions.items()) if states[ch] is q4.Q4ChannelState.PRESENT_UNRESOLVED for job in (_source_job(s,ch,current=current,next_scan=next_scan,region_clear=region_clear,region_probe=region_probe,region_fallback=region_fallback),) if job)
        if not jobs:break
        nscan=sum(j.kind=="CERT_SCAN" for j in jobs); nsource=len(jobs)-nscan
        nn_choice=min(jobs,key=lambda job:(current.distance_to(job.target),job.key))
        routing_choice=planner.choose(current,jobs) if (routingplus and receding_horizon) else None
        if receding_horizon:chosen=rh.choose(current,jobs,routing_choice=routing_choice)
        elif region_clear or region_probe or region_fallback or alternating_region:chosen=region_planner.choose(current,jobs)
        elif routingplus:chosen=planner.choose(current,jobs)
        else:chosen=min(jobs,key=lambda j:(current.distance_to(j.target),j.key))
        assert chosen is not None
        live_by_key={job.key:job for job in jobs}
        previous_suffix=previous_route[1:]
        surviving=[job for job in previous_suffix if job.key in live_by_key]
        source_displacements=[]
        for old in previous_suffix:
            if old.channel is None: continue
            latest=next((job for job in jobs if job.channel==old.channel and job.kind==old.kind),None)
            if latest is not None: source_displacements.append(old.target.distance_to(latest.target))
        tel.decisions.append({"n_scan_jobs":nscan,"n_source_jobs":nsource,"pool_size":len(jobs),"mixed_pool":nscan>0 and nsource>0,
                              "multi_source_pool":nsource>=2,"selected_job_type":chosen.kind,"selected_channel":chosen.channel,
                              "distance_to_selected_job":current.distance_to(chosen.target),"nn_job_key":repr(nn_choice.key),
                              "routing_job_key":repr(routing_choice.key) if routing_choice else None,"selected_job_key":repr(chosen.key),
                              "changed_from_nn":chosen.key!=nn_choice.key,
                              "suffix_survival_rate":len(surviving)/max(1,len(previous_suffix)),
                              "mean_source_anchor_displacement_m":sum(source_displacements)/max(1,len(source_displacements))})
        tel.selected[chosen.kind]=tel.selected.get(chosen.kind,0)+1
        trace.append(FutureRouteTrace(current,chosen.target,"mixed_atomic_routingplus" if routingplus else "mixed_atomic_nn",chosen.channel,
                                      "survey" if chosen.kind=="CERT_SCAN" else "source",chosen.kind))
        if chosen.kind=="CERT_SCAN":
            station=chosen.target;unvisited.remove(station);batch=[]
            for ch in selected:
                if states[ch]!="UNKNOWN":continue
                response=robot.measure(station,ch)
                if not q4_extreme._accepted(response):continue
                result=q4_extreme._field(response,"result","measure_result")
                if result=="no_signal":
                    no_signal[ch].add(scan_index)
                    if len(no_signal[ch])==len(certificate.stations):states[ch]=q4.Q4ChannelState.ABSENT_CERTIFIED;evidence[ch].append("21point_absent_certified")
                elif result=="near":
                    if q4_extreme._clear_succeeded(robot.clear(station,ch)):states[ch]=q4.Q4ChannelState.CLEARED;evidence[ch].append("scan_near_clear")
                    else:states[ch]=q4.Q4ChannelState.PRESENT_UNRESOLVED
                elif result=="direction":
                    bearing=q4_extreme._field(response,"svd_deg")
                    if bearing is None:continue
                    anchor=q4_extreme.PositiveAnchor(ch,station,float(bearing));grid=q4.build_anchor_clearance_grid(station,bearing_deg=float(bearing))
                    if grid is None:continue
                    states[ch]=q4.Q4ChannelState.PRESENT_UNRESOLVED;positive[ch]=[(station,float(bearing))]
                    session=SourceSession(anchor,positive[ch],grid.stations)
                    if paired_negative:
                        # No measurement is scheduled until the unresolved
                        # directional cut has a production proof.  Keeping the
                        # ledger object preserves generation/snapshot binding
                        # and makes accidental generic no_signal use impossible.
                        session.pair_binding=PairBinding(0,ch,0,(station,station),(station,))
                        evidence[ch].append("pair_ledger_created_cut_disabled")
                    sessions[ch]=session;batch.append(anchor);evidence[ch].append("anchor_retained")
            if shared_baseline:
                before=q4_extreme._robot_position(robot,station)
                moves,_reads=_shared_baseline(robot,batch,states,positive,evidence,{ch:SimpleNamespace(stations=s.fallback) for ch,s in sessions.items()})
                after=q4_extreme._robot_position(robot,before)
                if moves:trace.append(FutureRouteTrace(before,after,"shared50",None,"source","SHARED_BASELINE"))
            scan_index+=1
        else:
            ch=chosen.channel;assert ch is not None;session=sessions[ch]
            if chosen.kind=="SOURCE_LOCALIZATION_STEP":
                response=robot.measure(chosen.target,ch);result=q4_extreme._field(response,"result","measure_result")
                if result=="direction":
                    bearing=q4_extreme._field(response,"svd_deg")
                    if bearing is not None:
                        session.observations.append((chosen.target,float(bearing)));session.snapshot_version+=1
                        tel.region_history.append({"channel":ch,"observations":tuple(session.observations),"snapshot_version":session.snapshot_version})
                        estimate=q4_extreme.triangulated_early_estimate(session.anchor,chosen.target,float(bearing))
                        if estimate is not None:session.target=estimate;session.phase="CLEAR"
                        else:_prepare_fallback(session)
                elif result=="near":session.target=chosen.target;session.phase="CLEAR"
                elif session.lateral_sign>0:session.lateral_sign=-1
                else:_prepare_fallback(session)
            else:
                response=robot.clear(chosen.target,ch)
                if q4_extreme._clear_succeeded(response):states[ch]=q4.Q4ChannelState.CLEARED;evidence[ch].append("atomic_clear_success")
                else:
                    evidence[ch].append("atomic_clear_failed_retained")
                    session.failed_clear_exclusions.add(chosen.target)
                    if chosen.kind=="SOURCE_CLEAR_STEP":_prepare_fallback(session)
                    else:session.fallback_attempted.add(chosen.target);session.fallback_index+=1
        # This is telemetry only: a deterministic residual route gives a
        # comparable "plan survival" denominator at the next replan.
        previous_route=tuple(sorted(jobs,key=lambda job:(job is not chosen,current.distance_to(job.target),job.key)))
    complete=sum(s is q4.Q4ChannelState.CLEARED for s in states.values())>=16 or all(s in (q4.Q4ChannelState.CLEARED,q4.Q4ChannelState.ABSENT_CERTIFIED) for s in states.values())
    mixed=sum(bool(row["mixed_pool"]) for row in tel.decisions); multi=sum(bool(row["multi_source_pool"]) for row in tel.decisions)
    base={"mixed_pool_rate":mixed/max(1,len(tel.decisions)),"multi_source_pool_rate":multi/max(1,len(tel.decisions)),
          "selected_scan_count":tel.selected.get("CERT_SCAN",0),"selected_source_count":sum(value for key,value in tel.selected.items() if key!="CERT_SCAN"),
          "paired_negative":"BOUND_LEDGER_ONLY_DIRECTIONAL_CUT_DISABLED" if paired_negative else "DISABLED","adaptive_rotation":adaptive_certificate_rotation,
          "early16":early16}
    base|={"mean_suffix_survival_rate":sum(row["suffix_survival_rate"] for row in tel.decisions)/max(1,len(tel.decisions)),
           "mean_source_anchor_displacement_m":sum(row["mean_source_anchor_displacement_m"] for row in tel.decisions)/max(1,len(tel.decisions)),
           "actual_changed_from_nn_rate":sum(bool(row["changed_from_nn"]) for row in tel.decisions)/max(1,len(tel.decisions))}
    planner_values={"calls":region_planner.calls,"twoopt_gain_m":0.,"oropt_gain_m":0.,"warm_uses":0,"service_point_gain_m":region_planner.service_gain_m} if (region_clear or region_probe or region_fallback or alternating_region) and not receding_horizon else {"calls":planner.calls,"twoopt_gain_m":planner.twoopt_gain,"oropt_gain_m":planner.oropt_gain,"warm_uses":planner.warm_uses,"service_point_gain_m":0.}
    if receding_horizon:planner_values|=rh.telemetry()
    tel.planner=planner_values|base
    execution=q4.Q4ExecutionResult({ch:getattr(s,"value",s) for ch,s in states.items()},{ch:tuple(v) for ch,v in evidence.items()},complete)
    return CertDExecutionResult(execution,tuple(trace),True)
