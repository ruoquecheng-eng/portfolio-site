"""Finite service-point candidates for experimental Q4 speed routing."""
from __future__ import annotations

from math import cos, hypot, radians, sin, sqrt
from typing import Iterable

from shapely.geometry import LineString, Point as SPoint
from shapely.ops import nearest_points

from b_problem.geometry import Point as GeometryPoint, minimum_enclosing_circle

from . import q4
from .q4_extreme import PositiveAnchor
from .q4_mbfc import _region


CLEAR_SERVICE_MARGIN_M = 2.0
CLEAR_SERVICE_RADIUS_M = q4.CLEAR_RADIUS_M - CLEAR_SERVICE_MARGIN_M


def positive_outer_vertices(observations: Iterable[tuple[q4.Point, float]]) -> tuple[q4.Point, ...]:
    try:
        geometry = _region(tuple(observations))
        if geometry.is_empty or geometry.geom_type != "Polygon":
            return ()
        return tuple(q4.Point(float(x), float(y)) for x, y in tuple(geometry.exterior.coords)[:-1])
    except Exception:
        return ()


def is_clear_service_point(point: q4.Point, vertices: Iterable[q4.Point]) -> bool:
    values = tuple(vertices)
    return bool(values) and all(point.distance_to(vertex) <= CLEAR_SERVICE_RADIUS_M + 1e-7 for vertex in values)


def _intersections(a: q4.Point, b: q4.Point) -> tuple[q4.Point, ...]:
    distance = a.distance_to(b)
    radius = CLEAR_SERVICE_RADIUS_M
    if distance <= 1e-8 or distance > 2.0 * radius + 1e-8:
        return ()
    mid = q4.Point((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
    height = sqrt(max(0.0, radius * radius - distance * distance / 4.0))
    nx, ny = -(b.y - a.y) / distance, (b.x - a.x) / distance
    return (q4.Point(mid.x + height * nx, mid.y + height * ny), q4.Point(mid.x - height * nx, mid.y - height * ny))


def clear_service_candidates(
    vertices: Iterable[q4.Point], *, current: q4.Point, next_goal: q4.Point | None = None
) -> tuple[q4.Point, ...]:
    values = tuple(vertices)
    if not values or max((a.distance_to(b) for i, a in enumerate(values) for b in values[i + 1 :]), default=0.0) > 2.0 * CLEAR_SERVICE_RADIUS_M + 1e-7:
        return ()
    try:
        service = SPoint(values[0].x, values[0].y).buffer(CLEAR_SERVICE_RADIUS_M, quad_segs=48)
        for vertex in values[1:]:
            service = service.intersection(SPoint(vertex.x, vertex.y).buffer(CLEAR_SERVICE_RADIUS_M, quad_segs=48))
            if service.is_empty:
                return ()
        raw = []
        nearest = nearest_points(SPoint(current.x, current.y), service)[1]
        raw.append(q4.Point(float(nearest.x), float(nearest.y)))
        if next_goal is not None:
            route = LineString(((current.x, current.y), (next_goal.x, next_goal.y)))
            point = nearest_points(route, service)[1]
            raw.append(q4.Point(float(point.x), float(point.y)))
        mec = minimum_enclosing_circle(tuple(GeometryPoint(vertex.x, vertex.y) for vertex in values))
        raw.append(q4.Point(mec.center.x, mec.center.y))
        for vertex in values:
            dx, dy = current.x - vertex.x, current.y - vertex.y
            length = hypot(dx, dy)
            if length > 1e-8:
                raw.append(q4.Point(vertex.x + CLEAR_SERVICE_RADIUS_M * dx / length, vertex.y + CLEAR_SERVICE_RADIUS_M * dy / length))
        for i, a in enumerate(values):
            for b in values[i + 1 :]:
                raw.extend(_intersections(a, b))
        result = []
        for point in raw:
            if is_clear_service_point(point, values) and not any(point.distance_to(old) < 1e-6 for old in result):
                result.append(point)
        return tuple(sorted(result, key=lambda point: (current.distance_to(point), point.x, point.y)))
    except Exception:
        return ()


def localization_candidates(anchor: PositiveAnchor, *, route_goal: q4.Point | None = None) -> tuple[q4.Point, ...]:
    """Small public-data-only probe family for one atomic source job."""
    values: list[q4.Point] = []
    for forward in (150.0, 300.0, 450.0):
        theta = radians(anchor.bearing_deg)
        pursuit = q4.Point(anchor.station.x + forward * cos(theta), anchor.station.y + forward * sin(theta))
        for sign in (1.0, -1.0):
            lateral = radians(anchor.bearing_deg + sign * 90.0)
            values.append(q4.Point(pursuit.x + 300.0 * cos(lateral), pursuit.y + 300.0 * sin(lateral)))
    if route_goal is not None:
        theta = radians(anchor.bearing_deg)
        projection = (route_goal.x - anchor.station.x) * cos(theta) + (route_goal.y - anchor.station.y) * sin(theta)
        forward = min(450.0, max(0.0, projection))
        for sign in (1.0, -1.0):
            lateral = radians(anchor.bearing_deg + sign * 90.0)
            values.append(q4.Point(anchor.station.x + forward * cos(theta) + 300.0 * cos(lateral),
                                   anchor.station.y + forward * sin(theta) + 300.0 * sin(lateral)))
    unique: list[q4.Point] = []
    for point in values:
        if not any(point.distance_to(old) < 1e-7 for old in unique):
            unique.append(point)
    return tuple(unique)
