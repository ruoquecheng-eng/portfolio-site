"""Planning strategies for the CUMCM B problem."""
