"""Explicit CERT-D Q4 candidate: a certified reduced survey with CP08 fallback."""
from __future__ import annotations

from dataclasses import dataclass
from math import cos, pi, sin
from typing import Any, Callable, Iterable
from types import SimpleNamespace

from . import q4, q4_extreme
from .q4_mbfc import build_mbfc_cover
from .q4_static_routing import FutureRouteTrace, nearest_neighbor_route, open_two_opt
from .q4_telemetry import RecoveryTelemetry


CERT_D_EDGE_M = 925.0
CERT_D_STATION_COUNT = 31


@dataclass(frozen=True)
class CertDStationCertificate:
    stations: frozenset[q4.Point]
    edge_m: float
    analytic_status: str


@dataclass(frozen=True)
class CertDExecutionResult:
    execution: q4.Q4ExecutionResult
    route_trace: tuple[FutureRouteTrace, ...]
    used_cert_d: bool


class _ObservationRobot:
    """Transparent public-interface recorder used only during a fast pursuit."""
    def __init__(self, robot: Any, channel: int, observations: list[tuple[q4.Point, float]]) -> None:
        self._robot, self._channel, self._observations = robot, channel, observations
    @property
    def public_state(self):
        return self._robot.public_state
    @property
    def _telemetry(self):
        return getattr(self._robot, "_telemetry", None)
    def measure(self, position: q4.Point, channel: int):
        response = self._robot.measure(position, channel)
        if channel == self._channel and q4_extreme._field(response, "result", "measure_result") == "direction":
            bearing = q4_extreme._field(response, "svd_deg")
            if bearing is not None:
                self._observations.append((q4.Point(float(position.x), float(position.y)), float(bearing)))
                if self._telemetry is not None:
                    self._telemetry.source_observations[self._channel] = self._observations
        return response
    def clear(self, position: q4.Point, channel: int):
        return self._robot.clear(position, channel)


def _load_cert_d_certificate() -> CertDStationCertificate | None:
    try:
        from b_problem.certificate_experiments.q4_station_selection import (
            radial_support_candidate,
            required_radial_support,
        )

        candidate = radial_support_candidate(CERT_D_EDGE_M)
        required = required_radial_support(CERT_D_EDGE_M)
    except (ImportError, AttributeError, ValueError):
        return None
    if (
        candidate.edge_m != CERT_D_EDGE_M
        or len(candidate.stations) != CERT_D_STATION_COUNT
        or required != candidate.stations
    ):
        return None
    return CertDStationCertificate(candidate.stations, candidate.edge_m, "PROVED")


def _runtime_certificate_is_valid(certificate: CertDStationCertificate | None) -> bool:
    if certificate is None or not all(isinstance(point, q4.Point) for point in certificate.stations):
        return False
    if certificate.analytic_status == "PROVED":
        return certificate.edge_m == CERT_D_EDGE_M and len(certificate.stations) == CERT_D_STATION_COUNT
    # A separate finite oriented-pair/Voronoi proof, re-run by its constructor.
    return certificate.analytic_status == "PROVED_21POINT" and len(certificate.stations) == 21


def rolling_open_route_next(current: q4.Point, unvisited: Iterable[q4.Point]) -> q4.Point:
    """Recompute an anchored open 2-opt path and take its first station."""
    points = tuple(unvisited)
    if not points:
        raise ValueError("unvisited stations must not be empty")
    return open_two_opt(current, nearest_neighbor_route(current, points))[0]


def _shared_baseline(
    robot: Any, batch: list[q4_extreme.PositiveAnchor], states: dict[int, Any],
    positive_history: dict[int, list[tuple[q4.Point, float]]], evidence: dict[int, list[str]],
    pending_grids: dict[int, Any],
) -> tuple[int, int]:
    """One optional 50 m move to add safe positive bearings for fresh sources.

    The score is route-only heuristic.  A direction appends an ordinary
    conservative bearing; generic no_signal is logged and changes no region.
    """
    fresh = [a for a in batch if states[a.channel] is q4.Q4ChannelState.PRESENT_UNRESOLVED]
    if len(fresh) < 2:
        return 0, 0
    origin = q4_extreme._robot_position(robot, fresh[0].station)
    options: list[tuple[float, int, q4.Point, list[q4_extreme.PositiveAnchor]]] = []
    for index in range(24):
        angle = 2.0 * pi * index / 24.0
        point = q4.Point(origin.x + 50.0 * cos(angle), origin.y + 50.0 * sin(angle))
        selected: list[q4_extreme.PositiveAnchor] = []
        score = 0.0
        for anchor in fresh:
            estimate = q4.Point(anchor.station.x + 1000.0 * cos(anchor.bearing_deg * pi / 180.0),
                                anchor.station.y + 1000.0 * sin(anchor.bearing_deg * pi / 180.0))
            first = q4.Point(anchor.station.x - estimate.x, anchor.station.y - estimate.y)
            second = q4.Point(point.x - estimate.x, point.y - estimate.y)
            denominator = first.radius() * second.radius()
            parallax = abs(first.x * second.y - first.y * second.x) / denominator if denominator > 1e-9 else 0.0
            if parallax >= 0.025:
                selected.append(anchor)
                score += 1000.0 * parallax
        score -= origin.distance_to(point)
        if selected:
            options.append((score, index, point, selected))
    if not options:
        return 0, 0
    score, _index, point, selected = max(options, key=lambda item: (item[0], -item[1]))
    if score <= 0.0:
        return 0, 0
    current_channel = getattr(getattr(robot, "public_state", None), "measure_channel", None)
    selected.sort(key=lambda anchor: (anchor.channel != current_channel, anchor.channel))
    reads = 0
    for anchor in selected:
        if states[anchor.channel] is not q4.Q4ChannelState.PRESENT_UNRESOLVED:
            continue
        response = robot.measure(point, anchor.channel)
        if not q4_extreme._accepted(response):
            continue
        result = q4_extreme._field(response, "result", "measure_result")
        reads += 1
        if result == "direction":
            bearing = q4_extreme._field(response, "svd_deg")
            if bearing is not None:
                positive_history[anchor.channel].append((point, float(bearing)))
                evidence[anchor.channel].append("shared50_positive_bearing")
        elif result == "near":
            if q4_extreme._clear_succeeded(robot.clear(point, anchor.channel)):
                states[anchor.channel] = q4.Q4ChannelState.CLEARED
                pending_grids.pop(anchor.channel, None)
                evidence[anchor.channel].append("shared50_near_clear")
            else:
                evidence[anchor.channel].append("shared50_near_failed_clear_retained")
        elif result == "no_signal":
            evidence[anchor.channel].append("shared50_no_signal_record_only")
    return 1, reads


def execute_q4_cert_d_strategy(
    robot: Any,
    public_state: Any,
    *,
    certificate_provider: Callable[[], CertDStationCertificate | None] = _load_cert_d_certificate,
    channels: Iterable[int] = range(1, 21),
    local_pursuit: Callable[[Any, q4_extreme.PositiveAnchor], bool] = q4_extreme._direct_cross_range_pursuit,
    allow_prevalidated_certificate: bool = False,
    mbfc_enabled: bool = False,
    shared_baseline: bool = False,
    telemetry: RecoveryTelemetry | None = None,
) -> CertDExecutionResult:
    """Execute CERT-D only after all reduced-survey proof invariants are present."""
    try:
        certificate = certificate_provider()
    except Exception:
        certificate = None
    certificate_valid = _runtime_certificate_is_valid(certificate) or (
        allow_prevalidated_certificate
        and certificate is not None
        and certificate.analytic_status == "PROVED"
        and len(certificate.stations) >= 3
    )
    if not certificate_valid:
        return CertDExecutionResult(q4.execute_q4_strategy(robot, public_state), (), False)

    # Optional wrapper is observational only: all public calls and arguments
    # remain exactly those selected by the pre-existing control flow.
    if telemetry is not None:
        robot = telemetry.wrap(robot)

    selected = tuple(channels)
    states = {channel: "UNKNOWN" for channel in selected}
    evidence = {channel: [] for channel in selected}
    no_signal = {channel: set() for channel in selected}
    pending_grids: dict[int, q4.AnchorWedgeClearanceGrid] = {}
    positive_history: dict[int, list[tuple[q4.Point, float]]] = {}
    route_trace: list[FutureRouteTrace] = []
    unvisited = set(certificate.stations)
    station_id = 0

    while unvisited:
        current = q4_extreme._robot_position(robot, q4.Point(0.0, 0.0))  # noqa: SLF001 - read-only position adapter.
        station = rolling_open_route_next(current, unvisited)
        if telemetry is not None:
            telemetry.context(global_phase="CERT_ROUTE", source_channel=None, state="SCAN")
            telemetry.snapshot(robot, kind="GLOBAL_SCHEDULER", states=states, observations=positive_history,
                               route_remaining=len(unvisited), current_route_target=station,
                               jobs=[{"job_id": f"cert_scan_{station_id}", "job_type": "CERT_SCAN", "target_position": [station.x, station.y],
                                      "reason": "cert_d_rolling_open_2opt", "currently_eligible": True,
                                      "distance_from_robot": current.distance_to(station), "estimated_move_time": current.distance_to(station) / 5,
                                      "route_station_index": station_id, "correctness_dependency": "directional_discovery_certificate"}])
        route_trace.append(FutureRouteTrace(
            from_point=current, to_point=station, reason="cert_d_rolling_open_2opt",
            channel=None, task_type="survey", state="station_scan",
        ))
        unvisited.remove(station)
        batch: list[q4_extreme.PositiveAnchor] = []
        for channel in selected:
            if states[channel] != "UNKNOWN":
                continue
            response = robot.measure(station, channel)
            if not q4_extreme._accepted(response):  # noqa: SLF001 - same public-response adapter as FAST-C.
                continue
            result = q4_extreme._field(response, "result", "measure_result")  # noqa: SLF001
            if result == "no_signal":
                no_signal[channel].add(station_id)
                if len(no_signal[channel]) == len(certificate.stations):
                    states[channel] = q4.Q4ChannelState.ABSENT_CERTIFIED
                    evidence[channel].append("cert_d_absent_certified")
                continue
            if result == "near":
                if q4_extreme._clear_succeeded(robot.clear(station, channel)):  # noqa: SLF001
                    states[channel] = q4.Q4ChannelState.CLEARED
                    evidence[channel].append("cleared_at_cert_d_station")
                else:
                    states[channel] = q4.Q4ChannelState.PRESENT_UNRESOLVED
                continue
            if result != "direction":
                continue
            bearing = q4_extreme._field(response, "svd_deg")  # noqa: SLF001
            if bearing is None:
                continue
            anchor = q4_extreme.PositiveAnchor(channel, station, float(bearing))
            positive_history[channel] = [(station, float(bearing))]
            if telemetry is not None:
                telemetry.source_observations[channel] = positive_history[channel]
            grid = q4.build_anchor_clearance_grid(station, bearing_deg=float(bearing))
            if grid is None:
                continue
            states[channel] = q4.Q4ChannelState.PRESENT_UNRESOLVED
            pending_grids[channel] = grid
            evidence[channel].append("cert_d_positive_anchor_retained")
            batch.append(anchor)
        if shared_baseline:
            _shared_baseline(robot, batch, states, positive_history, evidence, pending_grids)
        for anchor in q4_extreme.order_positive_anchors(station, batch):
            if states[anchor.channel] is not q4.Q4ChannelState.PRESENT_UNRESOLVED:
                continue
            observed = positive_history[anchor.channel]
            if telemetry is not None:
                telemetry.context(global_phase="SOURCE_HANDLER", source_channel=anchor.channel, state="SECOND_BEARING")
                telemetry.snapshot(robot, kind="SOURCE_HANDLER", states=states, observations=positive_history,
                                   route_remaining=len(unvisited), current_route_target=station,
                                   jobs=[{"job_id": f"source_{anchor.channel}", "job_type": "SOURCE_LOCALIZATION", "source_channel": anchor.channel,
                                          "target_position": [anchor.station.x, anchor.station.y], "reason": "fast_c_cross_range", "currently_eligible": True,
                                          "distance_from_robot": q4_extreme._robot_position(robot, station).distance_to(anchor.station),
                                          "estimated_move_time": q4_extreme._robot_position(robot, station).distance_to(anchor.station)/5,
                                          "source_state": "PRESENT_UNRESOLVED", "correctness_dependency": "CP08_anchor_fallback_retained"}])
            if local_pursuit(_ObservationRobot(robot, anchor.channel, observed), anchor):
                states[anchor.channel] = q4.Q4ChannelState.CLEARED
                pending_grids.pop(anchor.channel, None)
                evidence[anchor.channel].append("cert_d_fast_c_clear")
            else:
                if mbfc_enabled:
                    baseline = pending_grids[anchor.channel].stations
                    mbfc = build_mbfc_cover(tuple(observed), baseline)
                    if mbfc.enabled:
                        pending_grids[anchor.channel] = SimpleNamespace(stations=mbfc.candidates)  # type: ignore[assignment]
                        evidence[anchor.channel].append("mbfc_enabled")
                    else:
                        evidence[anchor.channel].append(f"mbfc_revert_{mbfc.revert}")
                evidence[anchor.channel].append("cert_d_anchor_wedge_fallback")
            if telemetry is not None:
                telemetry.context(global_phase="CERT_ROUTE", source_channel=None, state="SCAN")
        station_id += 1

    tasks = tuple(
        (channel, grid.stations)
        for channel, grid in sorted(pending_grids.items())
        if states[channel] is q4.Q4ChannelState.PRESENT_UNRESOLVED
    )
    fallback_start = q4_extreme._robot_position(robot, q4.Point(0.0, 0.0))  # noqa: SLF001
    for channel, point in q4.multi_source_clear_route(fallback_start, tasks):
        if states[channel] is not q4.Q4ChannelState.PRESENT_UNRESOLVED:
            continue
        if telemetry is not None:
            telemetry.context(global_phase="FALLBACK", source_channel=channel, state="SOURCE_FALLBACK")
            telemetry.snapshot(robot, kind="CLEAR_DECISION", states=states, observations=positive_history, route_remaining=0,
                               jobs=[{"job_id": f"fallback_{channel}", "job_type": "SOURCE_FALLBACK", "source_channel": channel,
                                      "target_position": [point.x, point.y], "reason": "anchor_wedge_certified_clear", "currently_eligible": True,
                                      "distance_from_robot": q4_extreme._robot_position(robot, point).distance_to(point),
                                      "estimated_move_time": q4_extreme._robot_position(robot, point).distance_to(point)/5,
                                      "source_state": "PRESENT_UNRESOLVED", "correctness_dependency": "anchor_wedge_cover"}])
        if q4_extreme._clear_succeeded(robot.clear(point, channel)):  # noqa: SLF001
            states[channel] = q4.Q4ChannelState.CLEARED
            evidence[channel].append("cleared_by_anchor_wedge")
    complete = sum(state is q4.Q4ChannelState.CLEARED for state in states.values()) >= 16 or all(
        state in (q4.Q4ChannelState.CLEARED, q4.Q4ChannelState.ABSENT_CERTIFIED)
        for state in states.values()
    )
    execution = q4.Q4ExecutionResult(
        channel_states={channel: state.value for channel, state in states.items()},
        channel_evidence={channel: tuple(items) for channel, items in evidence.items()},
        complete=complete,
    )
    return CertDExecutionResult(execution, tuple(route_trace), True)
