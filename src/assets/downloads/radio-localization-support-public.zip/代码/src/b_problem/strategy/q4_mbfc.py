"""Conservative, static-entry multi-bearing fallback cover (MBFC-A)."""
from __future__ import annotations
from dataclasses import dataclass
from math import ceil, cos, floor, pi, radians, sin, sqrt
from shapely.geometry import Point as SPoint, Polygon
from .q4 import CLEAR_RADIUS_M, Point, TARGET_RADIUS_M

RANGE_M=1500.0; ERR_DEG=1.0; EPS=0.01; SPACING=CLEAR_RADIUS_M*sqrt(3)-0.01; COVER=SPACING/sqrt(3)
@dataclass(frozen=True)
class MBFCResult:
    candidates: tuple[Point,...]; first_area_m2: float; multi_area_m2: float; enabled: bool; revert: str|None
def _circle(c:Point,r:float,n:int=720):
 R=(r+EPS)/cos(pi/n);return Polygon([(c.x+R*cos(2*pi*i/n),c.y+R*sin(2*pi*i/n)) for i in range(n)])
def _wedge(c:Point,b:float):
 a=radians(b-ERR_DEG-EPS);z=radians(b+ERR_DEG+EPS);L=5000.;return Polygon([(c.x,c.y),(c.x+L*cos(a),c.y+L*sin(a)),(c.x+L*cos(z),c.y+L*sin(z))])
def _region(observations:tuple[tuple[Point,float],...]):
 g=_circle(Point(0.,0.),TARGET_RADIUS_M)
 for p,b in observations:g=g.intersection(_wedge(p,b)).intersection(_circle(p,RANGE_M))
 return g
def _cover(g):
 if g.is_empty:return ()
 x0,y0,x1,y1=g.bounds;dy=sqrt(3)*SPACING/2;out=[]
 for row in range(floor((y0-COVER)/dy),ceil((y1+COVER)/dy)+1):
  y=row*dy;off=(row&1)*SPACING/2
  for col in range(floor((x0-COVER-off)/SPACING),ceil((x1+COVER-off)/SPACING)+1):
   x=col*SPACING+off
   if g.distance(SPoint(x,y))<=COVER+EPS:out.append(Point(x,y))
 return tuple(out)
def build_mbfc_cover(observations:tuple[tuple[Point,float],...], baseline:tuple[Point,...])->MBFCResult:
 """Fail closed: outer geometry or coverage anomaly returns baseline unchanged."""
 try:
  if len(observations)<2:return MBFCResult(baseline,0.,0.,False,'no_benefit')
  first=_region(observations[:1]);multi=_region(observations)
  if multi.is_empty or not multi.is_valid:return MBFCResult(baseline,first.area,0.,False,'empty_region')
  candidates=_cover(multi)
  if not candidates:return MBFCResult(baseline,first.area,multi.area,False,'coverage')
  # The full lattice covering radius is COVER<20; retaining every center
  # within COVER of the outer region is the analytic coverage certificate.
  if len(candidates)>=len(baseline):return MBFCResult(baseline,first.area,multi.area,False,'no_benefit')
  return MBFCResult(candidates,first.area,multi.area,True,None)
 except Exception:return MBFCResult(baseline,0.,0.,False,'geometry')
