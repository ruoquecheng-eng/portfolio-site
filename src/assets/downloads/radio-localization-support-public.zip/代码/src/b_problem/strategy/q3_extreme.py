"""Offline Q3 speed candidates with the CP08-certified fallback retained."""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

from b_problem.strategy import q3


_CROSS_RANGE_DEG = 55.0
_FAST_B_RING_RADIUS_M = 1125.0


@dataclass(frozen=True)
class ExtremeExecutionResult:
    channel_states: dict[int, q3.ChannelState]
    complete: bool
    candidate: str
    cp08_fallback_used: bool
    localized_channels: int
    anchor_fallback_channels: int


@dataclass(frozen=True)
class FastCSettings:
    """Public-geometry-only knobs for the aggressive Q3 clear-now ablation."""

    forward_m: float = 750.0
    lateral_m: float = 80.0
    lateral_mode: str = "condition"
    clear_now: str = "very"
    retry_cap: int = 5
    time_debt_m: float = 350.0
    condition_degrees: float = 2.0


def build_fast_b_survey_plan() -> q3.SurveyPlan:
    """Return the independently checked shorter certified Q3 survey ring."""
    plan = q3.build_center_ring_plan(ring_radius=_FAST_B_RING_RADIUS_M)
    if plan.coverage_certificate.margin <= 0.0:
        raise RuntimeError("FAST-B survey ring lost its 1000 m coverage certificate")
    return plan


def _result(response: Any) -> str | None:
    if isinstance(response, dict):
        return response.get("result", response.get("measure_result", response.get("clear_result")))
    if isinstance(response, str):
        return response
    return getattr(response, "result", getattr(response, "measure_result", getattr(response, "clear_result", None)))


def _bearing(response: Any) -> float | None:
    value = response.get("svd_deg") if isinstance(response, dict) else getattr(response, "svd_deg", None)
    return float(value) if isinstance(value, (int, float)) and math.isfinite(value) else None


def _point_at(origin: q3.Point, bearing_deg: float, offset_deg: float, distance_m: float = 1000.0) -> q3.Point:
    angle = math.radians(bearing_deg + offset_deg)
    return q3.Point(
        origin.x + distance_m * math.cos(angle),
        origin.y + distance_m * math.sin(angle),
    )


def _safe_los_lateral_pair(pursuit_m: float, lateral_m: float) -> bool:
    """Check reception for the complete first ±1 degree direction wedge."""
    squared = pursuit_m * pursuit_m + lateral_m * lateral_m
    minimum_projection = pursuit_m * math.cos(math.radians(1.0)) - lateral_m * math.sin(math.radians(1.0))
    return (
        math.hypot(pursuit_m, lateral_m) <= q3.RECEIVE_RADIUS_LOWER_BOUND
        and minimum_projection > 0.0
        and squared <= 2.0 * q3.RECEIVE_RADIUS_LOWER_BOUND * minimum_projection
    )


def _nearest_station(current: q3.Point, remaining: set[int], plan: q3.SurveyPlan) -> int:
    return min(remaining, key=lambda station_id: (q3._distance(current, plan.stations[station_id]), station_id))


def _cross_station(
    anchor: q3.Point, bearing_deg: float, *, dynamic: bool, next_station: q3.Point | None
) -> q3.Point:
    candidates = tuple(_point_at(anchor, bearing_deg, sign * _CROSS_RANGE_DEG) for sign in (-1.0, 1.0))
    if not dynamic or next_station is None:
        return candidates[1]
    # Both signs have the same conservative-reception and angular-separation
    # properties.  Use only public route geometry as a tie-breaker.
    return min(candidates, key=lambda point: (q3._distance(point, next_station), point.x, point.y))


def _try_clear(robot: Any, tracker: q3.ChannelTracker, channel: int, point: q3.Point) -> tuple[bool, q3.Point]:
    response = robot.clear(point, channel)
    success = _result(response) == "success"
    tracker.record_clear(channel, point, accepted=True, success=success)
    return success, point


def _pursue(
    robot: Any,
    tracker: q3.ChannelTracker,
    *,
    channel: int,
    anchor: q3.Point,
    bearing_deg: float,
    dynamic: bool,
    next_station: q3.Point | None,
    los_pursuit: bool,
    pursuit_m: float,
    lateral_m: float,
) -> q3.Point:
    """Try a safe pursuit/cross-range observation, early clear, then correction."""
    if los_pursuit:
        pursuit = _point_at(anchor, bearing_deg, 0.0, pursuit_m)
        pursuit_response = robot.measure(pursuit, channel)
        pursuit_result = _result(pursuit_response)
        if pursuit_result == "near":
            _try_clear(robot, tracker, channel, pursuit)
            return pursuit
        if pursuit_result != "direction":
            return pursuit
        # The configured LOS/lateral pair is used only when its universal
        # first-bearing reception condition has been checked by the caller.
        second = _point_at(pursuit, bearing_deg, 90.0, lateral_m)
    else:
        second = _cross_station(anchor, bearing_deg, dynamic=dynamic, next_station=next_station)
    second_response = robot.measure(second, channel)
    second_result = _result(second_response)
    if second_result == "near":
        _try_clear(robot, tracker, channel, second)
        return second
    second_bearing = _bearing(second_response) if second_result == "direction" else None
    if second_bearing is None:
        return second

    estimates = q3._fast_clear_candidates(anchor, bearing_deg, second, second_bearing)
    if not estimates:
        return second
    estimate = estimates[0]
    if _try_clear(robot, tracker, channel, estimate)[0]:
        return estimate

    correction_response = robot.measure(estimate, channel)
    correction_result = _result(correction_response)
    if correction_result == "near":
        _try_clear(robot, tracker, channel, estimate)
        return estimate
    correction_bearing = _bearing(correction_response) if correction_result == "direction" else None
    if correction_bearing is None:
        return estimate

    # The correction point is close to the initial intersection estimate.  Test
    # the two least-travel additional wedge intersections, then defer to CP08.
    refined = q3._fast_clear_candidates(anchor, bearing_deg, estimate, correction_bearing)
    for point in sorted(refined, key=lambda candidate: q3._distance(estimate, candidate))[:2]:
        if _try_clear(robot, tracker, channel, point)[0]:
            return point
        estimate = point
    return estimate


def _bearing_gap(first_deg: float, second_deg: float) -> float:
    """Return the unsigned wrapped bearing separation in degrees."""
    return abs((second_deg - first_deg + 180.0) % 360.0 - 180.0)


def _pursue_fast_c(
    robot: Any,
    tracker: q3.ChannelTracker,
    *,
    channel: int,
    anchor: q3.Point,
    bearing_deg: float,
    settings: FastCSettings,
) -> q3.Point:
    """Immediately turn one anchor into bounded, geometry-ranked clear tries.

    A forward observation is always inside the first ±1 degree reception wedge.
    A short lateral observation is made only when the forward bearing does not
    separate the two rays enough to support a stable direct-clear estimate.
    Failed attempts leave the channel open for its certified anchor/CP08 paths.
    """
    forward = _point_at(anchor, bearing_deg, 0.0, settings.forward_m)
    forward_response = robot.measure(forward, channel)
    if _result(forward_response) == "near":
        _try_clear(robot, tracker, channel, forward)
        return forward
    if _result(forward_response) != "direction":
        return forward
    forward_bearing = _bearing(forward_response)
    if forward_bearing is None:
        return forward

    use_lateral = settings.lateral_mode == "fixed" or (
        settings.lateral_mode == "condition"
        and _bearing_gap(bearing_deg, forward_bearing) < settings.condition_degrees
    )
    observation_point, observation_bearing = forward, forward_bearing
    if use_lateral:
        lateral = _point_at(forward, bearing_deg, 90.0, settings.lateral_m)
        lateral_response = robot.measure(lateral, channel)
        if _result(lateral_response) == "near":
            _try_clear(robot, tracker, channel, lateral)
            return lateral
        if _result(lateral_response) != "direction":
            return lateral
        lateral_bearing = _bearing(lateral_response)
        if lateral_bearing is None:
            return lateral
        observation_point, observation_bearing = lateral, lateral_bearing

    candidates = q3._fast_clear_candidates(anchor, bearing_deg, observation_point, observation_bearing)
    level_limit = {"strict": 1, "moderate": 2, "aggressive": 3, "very": 5}.get(settings.clear_now)
    if level_limit is None:
        raise ValueError("clear_now must be strict, moderate, aggressive, or very")
    if settings.lateral_mode not in {"fixed", "condition", "none"}:
        raise ValueError("lateral_mode must be fixed, condition, or none")
    # Distance is an explicit time-debt proxy: 5 m/s turns the configured
    # local movement allowance into an ordering and bounded retry decision.
    ordered = sorted(candidates, key=lambda point: (q3._distance(observation_point, point), point.x, point.y))
    permitted: list[q3.Point] = []
    debt = 0.0
    previous = observation_point
    for point in ordered[:min(level_limit, settings.retry_cap)]:
        increment = q3._distance(previous, point)
        if permitted and debt + increment > settings.time_debt_m:
            continue
        permitted.append(point)
        debt += increment
        previous = point
    for point in permitted:
        if _try_clear(robot, tracker, channel, point)[0]:
            return point
        observation_point = point
    return observation_point


def _execute(
    robot: Any, public_state: Any, *, name: str, dynamic: bool, los_pursuit: bool, batch_station_scan: bool,
    pursuit_m: float = 650.0, lateral_m: float = 350.0, plan: q3.SurveyPlan | None = None,
    fast_c_settings: FastCSettings | None = None,
) -> ExtremeExecutionResult:
    """Run an immediate-localisation survey without weakening absence coverage."""
    if pursuit_m <= 0.0 or lateral_m <= 0.0:
        raise ValueError("pursuit distances must be positive")
    if los_pursuit and not _safe_los_lateral_pair(pursuit_m, lateral_m):
        raise ValueError("LOS/lateral pair must retain universal second-reception coverage")
    plan = plan or q3.build_center_ring_plan()
    tracker = q3.ChannelTracker(plan)
    anchors: dict[int, tuple[q3.Point, float]] = {}
    current = q3.Point(0.0, 0.0)
    remaining = set(range(len(plan.stations)))
    localized = 0

    while remaining:
        station_id = 0 if 0 in remaining else (
            _nearest_station(current, remaining, plan) if dynamic else min(remaining)
        )
        remaining.remove(station_id)
        station = plan.stations[station_id]
        next_station = plan.stations[_nearest_station(station, remaining, plan)] if dynamic and remaining else None
        discoveries: list[tuple[int, float]] = []
        for channel in q3.CHANNELS:
            if tracker.state_of(channel) is not q3.ChannelState.UNKNOWN:
                continue
            response = robot.measure(station, channel)
            observation = _result(response)
            immediate = tracker.record_measurement(channel, station_id, accepted=observation is not None, result=observation or "")
            current = station
            if immediate is not None:
                _try_clear(robot, tracker, channel, immediate.position)
                continue
            if observation != "direction":
                continue
            bearing_deg = _bearing(response)
            if bearing_deg is None:
                continue
            anchors[channel] = (station, bearing_deg)
            localized += 1
            if batch_station_scan:
                discoveries.append((channel, bearing_deg))
            else:
                current = (
                    _pursue_fast_c(
                        robot, tracker, channel=channel, anchor=station, bearing_deg=bearing_deg,
                        settings=fast_c_settings,
                    )
                    if fast_c_settings is not None else _pursue(
                        robot, tracker, channel=channel, anchor=station, bearing_deg=bearing_deg,
                        dynamic=dynamic, next_station=next_station, los_pursuit=los_pursuit,
                        pursuit_m=pursuit_m, lateral_m=lateral_m,
                    )
                )
        for channel, bearing_deg in discoveries:
            current = _pursue(
                robot, tracker, channel=channel, anchor=station, bearing_deg=bearing_deg,
                dynamic=dynamic, next_station=next_station, los_pursuit=los_pursuit,
                pursuit_m=pursuit_m, lateral_m=lateral_m,
            )

    anchor_fallbacks = 0
    for channel, (anchor, bearing_deg) in anchors.items():
        if tracker.state_of(channel) is q3.ChannelState.CLEARED:
            continue
        fallback = q3.build_anchor_clearance_plan(channel=channel, anchor=anchor, bearing_deg=bearing_deg)
        resources = q3.certify_clearance_resources(
            fallback, baseline_virtual_seconds=q3.survey_cost(plan, q3.snake_scan_plan(plan)).virtual_seconds,
            fallback_start=current,
        )
        if resources.status != "FEASIBLE_ESTIMATE":
            continue
        anchor_fallbacks += 1
        for action in fallback.actions:
            success, current = _try_clear(robot, tracker, channel, action.position)
            if success:
                break

    if tracker.is_complete():
        return ExtremeExecutionResult(dict(tracker.states), True, name, False, localized, anchor_fallbacks)

    # CP08 is the ultimate safe recovery path for transport irregularities or
    # an unexpected unresolved channel.  Its implementation is not modified.
    cp08 = q3.execute_q3_strategy(robot, public_state=public_state)
    return ExtremeExecutionResult(dict(cp08.channel_states), cp08.complete, name, True, localized, anchor_fallbacks)


def execute_q3_fast_a(robot: Any, public_state: Any) -> ExtremeExecutionResult:
    """FAST-A: 650 m LOS pursuit, then a safe 350 m lateral observation."""
    return _execute(
        robot, public_state, name="FAST-A", dynamic=True, los_pursuit=True, batch_station_scan=True,
    )


def execute_q3_fast_b(robot: Any, public_state: Any) -> ExtremeExecutionResult:
    """FAST-B: batched pursuit with a shorter independently certified survey ring."""
    return _execute(
        robot, public_state, name="FAST-B", dynamic=True, los_pursuit=True, batch_station_scan=True,
        pursuit_m=500.0, lateral_m=200.0, plan=build_fast_b_survey_plan(),
    )


def execute_q3_safe7_1130(robot: Any, public_state: Any) -> ExtremeExecutionResult:
    """Seven-point Q3 discovery candidate with a positive analytic margin."""
    plan=q3.build_center_ring_plan(ring_radius=1130.0)
    if plan.coverage_certificate.margin <= 0.0:
        raise RuntimeError("Q3 safe7 discovery certificate failed")
    return _execute(robot,public_state,name="SAFE7-1130",dynamic=True,los_pursuit=True,batch_station_scan=True,
                    pursuit_m=500.0,lateral_m=200.0,plan=plan)


def execute_q3_fast_c(
    robot: Any,
    public_state: Any,
    *,
    forward_m: float = 750.0,
    lateral_m: float = 80.0,
    lateral_mode: str = "condition",
    clear_now: str = "very",
    retry_cap: int = 5,
    time_debt_m: float = 350.0,
) -> ExtremeExecutionResult:
    """FAST-C: immediate bounded retries, retaining anchor then CP08 recovery."""
    settings = FastCSettings(
        forward_m=forward_m,
        lateral_m=lateral_m,
        lateral_mode=lateral_mode,
        clear_now=clear_now,
        retry_cap=retry_cap,
        time_debt_m=time_debt_m,
    )
    return _execute(
        robot, public_state, name="FAST-C", dynamic=True, los_pursuit=True, batch_station_scan=False,
        pursuit_m=forward_m, lateral_m=lateral_m, plan=build_fast_b_survey_plan(), fast_c_settings=settings,
    )
