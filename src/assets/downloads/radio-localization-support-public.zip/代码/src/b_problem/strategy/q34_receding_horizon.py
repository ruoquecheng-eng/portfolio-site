"""Truth-free, first-action receding-horizon ranking for live Q3/Q4 jobs.

The planner never mutates a strategy state.  Its rollouts are bounded cost
quadrature used only to rank the next public atomic action.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

from .q4 import Point
from .q4_routingplus import LiveJob, RoutingPlus


def _length(start:Point,jobs:tuple[LiveJob,...],order:list[int])->float:
    total=0.; cursor=start
    for index in order: total+=cursor.distance_to(jobs[index].target); cursor=jobs[index].target
    return total


def _nn_order(start:Point,jobs:tuple[LiveJob,...])->list[int]:
    left=set(range(len(jobs))); order=[]; cursor=start
    while left:
        index=min(left,key=lambda item:(cursor.distance_to(jobs[item].target),jobs[item].key))
        order.append(index);left.remove(index);cursor=jobs[index].target
    return order


def _cheap_twoopt(start:Point,jobs:tuple[LiveJob,...],order:list[int])->list[int]:
    # One bounded pass avoids the expensive multi-seed rolling objective.
    best=list(order); base=_length(start,jobs,best)
    for first in range(len(best)-1):
        for last in range(first+1,len(best)):
            trial=best[:first]+best[first:last+1][::-1]+best[last+1:]
            value=_length(start,jobs,trial)
            if value<base-1e-9: best,base=trial,value
    return best


@dataclass(frozen=True)
class RHScore:
    key:tuple
    immediate_s:float
    residual_s:float
    continuation_s:float
    discovery_delay_s:float
    total_s:float


class RecedingHorizonPlanner:
    """Evaluate at most K action anchors using a cheap post-action residual."""
    def __init__(self,*,k:int=8,cheap_twoopt:bool=False,rollout:bool=False)->None:
        self.k=k;self.cheap_twoopt=cheap_twoopt;self.rollout=rollout
        self.calls=0;self.candidate_count=0;self.changed_from_nn=0;self.nn_selected=0;self.routing_selected=0
        self.residual_sum=0.;self.predicted_sum=0.;self.hard_state_mutations=0;self.scores:list[RHScore]=[]

    @staticmethod
    def _action_seconds(job:LiveJob)->float:
        if "CLEAR" in job.kind: return 5.0
        return 6.0 if "SCAN" in job.kind else 6.0

    def _candidate_indices(self,start:Point,jobs:tuple[LiveJob,...],routing:LiveJob|None)->tuple[int,...]:
        nn=_nn_order(start,jobs)[0]
        candidates=[nn]
        for predicate in (lambda job:"SCAN" in job.kind,lambda job:"SOURCE" in job.kind,
                          lambda job:"CLEAR" in job.kind):
            selected=[index for index,job in enumerate(jobs) if predicate(job)]
            if selected:candidates.append(min(selected,key=lambda index:(start.distance_to(jobs[index].target),jobs[index].key)))
        if routing is not None:
            candidates.extend(index for index,job in enumerate(jobs) if job.key==routing.key)
        # Information/discovery proxies only influence ranking; no state change.
        source=[index for index,job in enumerate(jobs) if "SOURCE" in job.kind]
        scans=[index for index,job in enumerate(jobs) if "SCAN" in job.kind]
        if source:candidates.append(max(source,key=lambda index:(start.distance_to(jobs[index].target),jobs[index].key)))
        if scans:candidates.append(min(scans,key=lambda index:(start.distance_to(jobs[index].target),jobs[index].key)))
        return tuple(dict.fromkeys(candidates))[:self.k]

    def choose(self,start:Point,jobs:Iterable[LiveJob],*,routing_choice:LiveJob|None=None)->LiveJob|None:
        values=tuple(jobs)
        if not values:return None
        self.calls+=1; nn_index=_nn_order(start,values)[0]; indices=self._candidate_indices(start,values,routing_choice)
        self.candidate_count+=len(indices); ranked=[]
        for index in indices:
            job=values[index]; remaining=values[:index]+values[index+1:]
            order=_nn_order(job.target,remaining) if remaining else []
            if self.cheap_twoopt and len(order)>2:order=_cheap_twoopt(job.target,remaining,order)
            residual_m=_length(job.target,remaining,order)
            immediate=start.distance_to(job.target)/5.0+self._action_seconds(job)
            continuation=0.0
            if self.rollout and "SOURCE" in job.kind:
                # Bounded public-outcome quadrature: direction/no-signal/near
                # affect only an expected continuation-cost surrogate.
                continuation=0.12*min(1500.0,residual_m)/5.0
            delay=0.0
            if "SOURCE" in job.kind and any("SCAN" in item.kind for item in values): delay=3.0
            score=RHScore(job.key,immediate,residual_m/5.0,continuation,delay,immediate+residual_m/5.0+continuation+delay)
            ranked.append((score,job))
        score,choice=min(ranked,key=lambda item:(item[0].total_s,item[1].key))
        self.scores.append(score);self.residual_sum+=score.residual_s;self.predicted_sum+=score.total_s
        if choice.key==values[nn_index].key:self.nn_selected+=1
        else:self.changed_from_nn+=1
        if routing_choice is not None and choice.key==routing_choice.key:self.routing_selected+=1
        return choice

    def telemetry(self)->dict:
        return {"calls":self.calls,"candidate_first_actions_mean":self.candidate_count/max(1,self.calls),
                "nn_first_selected_rate":self.nn_selected/max(1,self.calls),"routingplus_first_selected_rate":self.routing_selected/max(1,self.calls),
                "rh_changed_first_action_rate":self.changed_from_nn/max(1,self.calls),
                "mean_predicted_residual_cost_s":self.residual_sum/max(1,self.calls),
                "mean_predicted_total_cost_s":self.predicted_sum/max(1,self.calls),"hard_state_mutations":self.hard_state_mutations}
