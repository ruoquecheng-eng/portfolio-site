"""Certified baseline planning primitives for Q3 omnidirectional sources."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import math
from typing import Any

from b_problem.geometry import Circle, Point


TARGET_RADIUS = 1800.0
RECEIVE_RADIUS_LOWER_BOUND = 1000.0
RING_RADIUS = 1200.0
CHANNELS = tuple(range(1, 21))


def _distance(first: Point, second: Point) -> float:
    return math.hypot(first.x - second.x, first.y - second.y)


@dataclass(frozen=True)
class CoverageCertificate:
    stations: tuple[Point, ...]
    target_radius: float
    receive_lower_bound: float
    worst_nearest_distance: float

    @property
    def margin(self) -> float:
        return self.receive_lower_bound - self.worst_nearest_distance

    def nearest_distance(self, point: Point) -> float:
        return min(_distance(point, station) for station in self.stations)


@dataclass(frozen=True)
class SurveyPlan:
    stations: tuple[Point, ...]
    route: tuple[Point, ...]
    coverage_certificate: CoverageCertificate


@dataclass(frozen=True)
class ScanAction:
    station_id: int
    position: Point
    channel: int


@dataclass(frozen=True)
class ClearAction:
    channel: int
    position: Point


@dataclass(frozen=True)
class SurveyCost:
    route_length: float
    movement_seconds: float
    measure_seconds: float
    switch_seconds: float

    @property
    def virtual_seconds(self) -> float:
        return self.movement_seconds + self.measure_seconds + self.switch_seconds


def _six_ring_worst_distance(target_radius: float, ring_radius: float) -> float:
    """Exact farthest nearest-station distance for center plus six equal ring sites."""
    half_sector = math.pi / 6.0
    cosine = math.cos(half_sector)
    crossover = ring_radius / (2.0 * cosine)
    outer = math.sqrt(target_radius**2 + ring_radius**2 - 2.0 * target_radius * ring_radius * cosine)
    if target_radius <= crossover:
        return target_radius
    return max(crossover, min(target_radius, outer))


def build_center_ring_plan(
    target_radius: float = TARGET_RADIUS,
    receive_lower_bound: float = RECEIVE_RADIUS_LOWER_BOUND,
    ring_radius: float = RING_RADIUS,
) -> SurveyPlan:
    """Build the analytic center-plus-six-ring Q3 coverage baseline."""
    if min(target_radius, receive_lower_bound, ring_radius) <= 0.0:
        raise ValueError("radii must be positive")
    center = Point(0.0, 0.0)
    ring = tuple(
        Point(ring_radius * math.cos(index * math.pi / 3.0), ring_radius * math.sin(index * math.pi / 3.0))
        for index in range(6)
    )
    stations = (center, *ring)
    worst = _six_ring_worst_distance(target_radius, ring_radius)
    certificate = CoverageCertificate(stations, target_radius, receive_lower_bound, worst)
    return SurveyPlan(stations, stations, certificate)


def snake_scan_plan(plan: SurveyPlan, channels: tuple[int, ...] = CHANNELS, initial_channel: int = 1) -> tuple[ScanAction, ...]:
    """Scan all unresolved channels in alternating orders without avoidable switches."""
    if set(channels) != set(CHANNELS) or initial_channel not in channels:
        raise ValueError("the fixed survey scans each channel 1..20 exactly once per station")
    current = initial_channel
    actions: list[ScanAction] = []
    for station_id, position in enumerate(plan.route):
        order = tuple(channel for channel in channels if channel >= current) + tuple(channel for channel in reversed(channels) if channel < current)
        actions.extend(ScanAction(station_id, position, channel) for channel in order)
        current = order[-1]
    return tuple(actions)


def survey_cost(plan: SurveyPlan, actions: tuple[ScanAction, ...], speed_mps: float = 5.0) -> SurveyCost:
    """Compute virtual cost using only accepted measure-action mechanics."""
    if speed_mps <= 0.0:
        raise ValueError("speed must be positive")
    route_length = sum(_distance(first, second) for first, second in zip(plan.route, plan.route[1:]))
    switches = sum(first.channel != second.channel for first, second in zip(actions, actions[1:]))
    return SurveyCost(route_length, route_length / speed_mps, 5.0 * len(actions), float(switches))


class ChannelState(str, Enum):
    UNKNOWN = "unknown"
    PRESENT_LOCALIZING = "present_localizing"
    CLEARED = "cleared"
    ABSENT_CERTIFIED = "absent_certified"


@dataclass
class ChannelTracker:
    """State machine retaining every unfulfilled absence-proof obligation."""

    plan: SurveyPlan
    states: dict[int, ChannelState] = field(default_factory=lambda: {channel: ChannelState.UNKNOWN for channel in CHANNELS})
    _no_signal_stations: dict[int, set[int]] = field(default_factory=lambda: {channel: set() for channel in CHANNELS})
    _failed_clears: dict[int, list[Point]] = field(default_factory=lambda: {channel: [] for channel in CHANNELS})

    def state_of(self, channel: int) -> ChannelState:
        return self.states[channel]

    def record_measurement(self, channel: int, station_id: int, *, accepted: bool, result: str) -> ClearAction | None:
        """Apply a simulator response; rejected/unknown responses create no evidence."""
        if channel not in CHANNELS or station_id not in range(len(self.plan.stations)) or not accepted:
            return None
        state = self.states[channel]
        if state in (ChannelState.CLEARED, ChannelState.ABSENT_CERTIFIED):
            return None
        if result == "direction":
            self.states[channel] = ChannelState.PRESENT_LOCALIZING
            return None
        if result == "near":
            self.states[channel] = ChannelState.PRESENT_LOCALIZING
            return ClearAction(channel, self.plan.stations[station_id])
        if result != "no_signal":
            return None
        if state is ChannelState.UNKNOWN:
            self._no_signal_stations[channel].add(station_id)
            if len(self._no_signal_stations[channel]) == len(self.plan.stations):
                self.states[channel] = ChannelState.ABSENT_CERTIFIED
        return None

    def record_clear(self, channel: int, position: Point, *, accepted: bool, success: bool) -> None:
        """Only a successful accepted clear resolves a channel globally."""
        if channel not in CHANNELS or not accepted:
            return
        if success:
            self.states[channel] = ChannelState.CLEARED
        else:
            self._failed_clears[channel].append(position)

    def failed_clear_points(self, channel: int) -> tuple[Point, ...]:
        return tuple(self._failed_clears[channel])

    def remaining_obligations(self) -> tuple[tuple[int, int], ...]:
        """Return every (station, channel) scan still needed for absence certification."""
        obligations = []
        for channel in CHANNELS:
            if self.states[channel] is not ChannelState.UNKNOWN:
                continue
            obligations.extend((station_id, channel) for station_id in range(len(self.plan.stations)) if station_id not in self._no_signal_stations[channel])
        return tuple(obligations)

    def is_complete(self) -> bool:
        if sum(state is ChannelState.CLEARED for state in self.states.values()) >= 16:
            return True
        return all(state in (ChannelState.CLEARED, ChannelState.ABSENT_CERTIFIED) for state in self.states.values())


def hybrid_scan_plan(tracker: ChannelTracker) -> tuple[ScanAction, ...]:
    """Resume only outstanding UNKNOWN-channel survey obligations after a detour."""
    return tuple(
        ScanAction(station_id, tracker.plan.stations[station_id], channel)
        for station_id, channel in tracker.remaining_obligations()
    )


@dataclass(frozen=True)
class ClearancePlan:
    kind: str
    actions: tuple[ClearAction, ...]
    coverage_radius: float
    certified: bool
    eta_c_m: float = 0.0
    resource_status: str = "LEGACY_GEOMETRY_ONLY"


def _triangular_box_cover(box: Circle, coverage_radius: float) -> tuple[Point, ...]:
    """Cover a circle's bounding box using a padded triangular lattice.

    A triangular lattice with side ``sqrt(3)*coverage_radius`` has covering
    radius ``coverage_radius``.  Padding each coordinate by that radius retains
    every lattice point that could be nearest to a point in the bounding box.
    """
    spacing = math.sqrt(3.0) * coverage_radius
    row_step = 1.5 * coverage_radius
    x_min = box.center.x - box.radius - coverage_radius
    x_max = box.center.x + box.radius + coverage_radius
    y_min = box.center.y - box.radius - coverage_radius
    y_max = box.center.y + box.radius + coverage_radius
    first_row = math.floor(y_min / row_step)
    last_row = math.ceil(y_max / row_step)
    points: list[Point] = []
    for row in range(first_row, last_row + 1):
        offset = (row & 1) * spacing / 2.0
        first_col = math.floor((x_min - offset) / spacing)
        last_col = math.ceil((x_max - offset) / spacing)
        points.extend(Point(column * spacing + offset, row * row_step) for column in range(first_col, last_col + 1))
    return tuple(points)


def clearance_plan(channel: int, mec: Circle, clear_radius: float = 20.0) -> ClearancePlan:
    """Use one certified MEC-center clear or a certified triangular fallback."""
    if channel not in CHANNELS or clear_radius <= 0.0:
        raise ValueError("invalid channel or clearance radius")
    if mec.radius <= clear_radius:
        return ClearancePlan("single_clear", (ClearAction(channel, mec.center),), clear_radius, True, 0.0, "CERTIFIED_SINGLE_CLEAR")
    eta_c_m = min(0.01, clear_radius / 2.0)
    grid_radius = clear_radius - eta_c_m
    points = _triangular_box_cover(mec, grid_radius)
    return ClearancePlan(
        "triangular_fallback",
        tuple(ClearAction(channel, point) for point in points),
        grid_radius,
        True,
        eta_c_m,
        "LEGACY_GEOMETRY_ONLY",
    )


# The legacy MEC helper above remains for compatibility with the first-batch
# Q3 tests.  The executable fallback below starts from the actual first
# direction wedge instead of treating an arbitrary 1500 m enclosing circle as
# a runnable primary plan.

DEFAULT_CLEAR_ETA_M = 0.01
MAX_VIRTUAL_SECONDS = 360000.0
MAX_LOG_BYTES = 2 * 1024 * 1024
ESTIMATED_LOG_BYTES_PER_ACTION = 256
SQRT3 = math.sqrt(3.0)
SAFE_SECOND_OFFSET_DEG = 5.0


@dataclass(frozen=True)
class SampleCoverageCertificate:
    sample_count: int
    all_samples_covered: bool
    maximum_nearest_distance_m: float
    coverage_radius_m: float
    continuous_sector_coverage: bool
    status: str
    proof: str = ""


@dataclass(frozen=True)
class ClearanceResourceCertificate:
    per_channel_actions: int
    projected_actions_for_16_channels: int
    baseline_virtual_seconds: float
    route_start: Point
    route_length_m: float
    projected_minimum_virtual_seconds: float
    projected_route_virtual_seconds: float
    estimated_log_bytes: int
    status: str
    reason: str


@dataclass(frozen=True)
class AnchorClearancePlan:
    kind: str
    channel: int
    anchor: Point
    bearing_deg: float
    delta_deg: float
    eta_c_m: float
    spacing_m: float
    coverage_radius_m: float
    actions: tuple[ClearAction, ...]
    sample_coverage_certificate: SampleCoverageCertificate
    bounding_box_area_m2: float
    route_length_m: float


def _angle_delta_deg(angle_deg: float, bearing_deg: float) -> float:
    return (angle_deg - bearing_deg + 180.0) % 360.0 - 180.0


def _in_anchor_wedge(point: Point, anchor: Point, bearing_deg: float, delta_deg: float, target_radius: float) -> bool:
    distance = _distance(point, anchor)
    if distance > 1500.0 + 1e-9 or _distance(point, Point(0.0, 0.0)) > target_radius + 1e-9:
        return False
    if distance <= 1e-9:
        return True
    return abs(_angle_delta_deg(math.degrees(math.atan2(point.y - anchor.y, point.x - anchor.x)), bearing_deg)) <= delta_deg + 1e-9


def _anchor_wedge_samples(anchor: Point, bearing_deg: float, delta_deg: float, target_radius: float) -> tuple[Point, ...]:
    samples: list[Point] = []
    radii = {0.0, 5.0, 20.0, 1000.0, 1500.0}
    radii.update(1500.0 * index / 75.0 for index in range(76))
    for radius in sorted(radii):
        for offset in (-delta_deg, -delta_deg / 2.0, 0.0, delta_deg / 2.0, delta_deg):
            angle = math.radians(bearing_deg + offset)
            candidate = Point(anchor.x + radius * math.cos(angle), anchor.y + radius * math.sin(angle))
            if _in_anchor_wedge(candidate, anchor, bearing_deg, delta_deg, target_radius):
                samples.append(candidate)
    return tuple(dict.fromkeys(samples))


def _triangular_box_points(x_min: float, x_max: float, y_min: float, y_max: float, spacing_m: float) -> tuple[Point, ...]:
    """Return a padded triangular-lattice patch whose Voronoi radius is h/sqrt(3)."""
    pad = spacing_m
    row_step = SQRT3 * spacing_m / 2.0
    first_row = math.floor((y_min - pad) / row_step)
    last_row = math.ceil((y_max + pad) / row_step)
    points: list[Point] = []
    for row in range(first_row, last_row + 1):
        offset = (row & 1) * spacing_m / 2.0
        first_col = math.floor((x_min - pad - offset) / spacing_m)
        last_col = math.ceil((x_max + pad - offset) / spacing_m)
        points.extend(Point(column * spacing_m + offset, row * row_step) for column in range(first_col, last_col + 1))
    return tuple(dict.fromkeys(points))


def _snake_order(points: tuple[Point, ...]) -> tuple[Point, ...]:
    rows: dict[float, list[Point]] = {}
    for point in points:
        rows.setdefault(point.y, []).append(point)
    ordered: list[Point] = []
    for index, y in enumerate(sorted(rows)):
        ordered.extend(sorted(rows[y], key=lambda point: point.x, reverse=bool(index % 2)))
    return tuple(ordered)


def _route_length(start: Point, points: tuple[Point, ...]) -> float:
    return sum(_distance(first, second) for first, second in zip((start, *points), points))


def _distance_to_closed_sector(point: Point, *, radius_m: float, delta_deg: float) -> float:
    """Return exact Euclidean distance from local ``point`` to a closed sector."""
    angle = math.atan2(point.y, point.x)
    half_width = math.radians(delta_deg)
    radial_distance = math.hypot(point.x, point.y)
    if abs(angle) <= half_width + 1e-9:
        return max(0.0, radial_distance - radius_m)

    def distance_to_segment(end: Point) -> float:
        length_squared = end.x * end.x + end.y * end.y
        projection = max(0.0, min(1.0, (point.x * end.x + point.y * end.y) / length_squared))
        return math.hypot(point.x - projection * end.x, point.y - projection * end.y)

    upper = Point(radius_m * math.cos(half_width), radius_m * math.sin(half_width))
    lower = Point(radius_m * math.cos(-half_width), radius_m * math.sin(-half_width))
    return min(distance_to_segment(upper), distance_to_segment(lower))


def build_anchor_clearance_plan(
    *,
    channel: int,
    anchor: Point,
    bearing_deg: float,
    delta_deg: float = 1.0,
    eta_c_m: float = DEFAULT_CLEAR_ETA_M,
    target_radius: float = TARGET_RADIUS,
) -> AnchorClearancePlan:
    """Build a narrow first-bearing wedge clearance grid with explicit margin."""
    if channel not in CHANNELS or not 0.0 < delta_deg < 90.0 or eta_c_m <= 0.0:
        raise ValueError("invalid anchor clearance parameters")
    spacing_m = 20.0 * SQRT3 - eta_c_m
    coverage_radius_m = spacing_m / SQRT3
    # Build the lattice in bearing-aligned coordinates.  The complete first-
    # bearing cone is contained in 0<=longitudinal<=1500 and
    # |transverse|<=1500*sin(delta), independent of the world bearing.
    x_min, x_max = 0.0, 1500.0
    transverse = 1500.0 * math.sin(math.radians(delta_deg))
    y_min, y_max = -transverse, transverse
    candidates = _triangular_box_points(x_min, x_max, y_min, y_max, spacing_m)
    # The full lattice covers the closed sector with radius h/sqrt(3).  A
    # nearest lattice point to any sector point is itself no farther than that
    # radius from the sector, so this exact-distance filter cannot discard it.
    local_points = _snake_order(tuple(
        point for point in candidates
        if _distance_to_closed_sector(point, radius_m=1500.0, delta_deg=delta_deg) <= coverage_radius_m + 1e-9
    ))
    heading = math.radians(bearing_deg)
    cosine, sine = math.cos(heading), math.sin(heading)
    points = tuple(
        Point(anchor.x + cosine * point.x - sine * point.y, anchor.y + sine * point.x + cosine * point.y)
        for point in local_points
    )
    samples = _anchor_wedge_samples(anchor, bearing_deg, delta_deg, target_radius)
    maximum_nearest = max(min(_distance(sample, point) for point in points) for sample in samples)
    sample_certificate = SampleCoverageCertificate(
        sample_count=len(samples),
        all_samples_covered=maximum_nearest <= coverage_radius_m + 1e-9,
        maximum_nearest_distance_m=maximum_nearest,
        coverage_radius_m=coverage_radius_m,
        continuous_sector_coverage=bool(local_points),
        status="PROVED" if local_points else "UNRESOLVED",
        proof=(
            "The full triangular lattice covers the closed sector with radius spacing/sqrt(3). "
            "Every nearest lattice point of a sector point is within that radius of the sector and survives the exact-distance filter."
        ),
    )
    return AnchorClearancePlan(
        kind="anchor_wedge_clearance",
        channel=channel,
        anchor=anchor,
        bearing_deg=bearing_deg,
        delta_deg=delta_deg,
        eta_c_m=eta_c_m,
        spacing_m=spacing_m,
        coverage_radius_m=coverage_radius_m,
        actions=tuple(ClearAction(channel, point) for point in points),
        sample_coverage_certificate=sample_certificate,
        bounding_box_area_m2=(x_max - x_min) * (y_max - y_min),
        # Rigid rotation/translation preserves the bearing-aligned snake route.
        route_length_m=_route_length(anchor, points),
    )


def certify_clearance_resources(
    plan: AnchorClearancePlan,
    *,
    baseline_virtual_seconds: float,
    max_channels: int = 16,
    max_virtual_seconds: float = MAX_VIRTUAL_SECONDS,
    max_log_bytes: int = MAX_LOG_BYTES,
    baseline_actions: int = 140,
    fallback_start: Point | None = None,
) -> ClearanceResourceCertificate:
    """Reject a fallback as main-strategy evidence when either global budget fails."""
    count = len(plan.actions)
    projected_actions = count * max_channels
    route_start = fallback_start if fallback_start is not None else plan.anchor
    route_length_m = _route_length(route_start, tuple(action.position for action in plan.actions))
    # A no-target clear costs 3 s; a final successful clear costs 5 s.  The
    # route figure is the conservative all-points traversal from the anchor.
    minimum = baseline_virtual_seconds + max_channels * 3.0 * count
    routed = baseline_virtual_seconds + max_channels * (3.0 * max(count - 1, 0) + 5.0 + route_length_m / 5.0)
    estimated_log = (projected_actions + baseline_actions) * ESTIMATED_LOG_BYTES_PER_ACTION
    feasible = (
        plan.sample_coverage_certificate.all_samples_covered
        and routed <= max_virtual_seconds
        and estimated_log <= max_log_bytes
    )
    return ClearanceResourceCertificate(
        per_channel_actions=count,
        projected_actions_for_16_channels=projected_actions,
        baseline_virtual_seconds=baseline_virtual_seconds,
        route_start=route_start,
        route_length_m=route_length_m,
        projected_minimum_virtual_seconds=minimum,
        projected_route_virtual_seconds=routed,
        estimated_log_bytes=estimated_log,
        status="FEASIBLE_ESTIMATE" if feasible else "REJECTED_UNRESOLVED",
        reason=("Sample and resource estimates fit the stated caps." if feasible else "Fallback exceeds a cap or lacks sample coverage; reject it as a complete main strategy."),
    )


def _field(response: Any, name: str, default: Any = None) -> Any:
    if isinstance(response, dict):
        return response.get(name, default)
    if name == "accepted" and (isinstance(response, str) or hasattr(response, "result")):
        return True
    if isinstance(response, str):
        if name in {"result", "measure_result", "clear_result"}:
            return response
        if name == "success":
            return response == "success"
    return getattr(response, name, default)


def _ray_intersection(
    first_position: Point,
    first_bearing_deg: float,
    second_position: Point,
    second_bearing_deg: float,
) -> Point | None:
    """Return the forward-ray crossing, or ``None`` for a degenerate pair.

    This is deliberately a fast-path estimate: bearings retain their ±1°
    uncertainty, so callers must retain a certified fallback after a miss.
    """
    first_angle = math.radians(first_bearing_deg)
    second_angle = math.radians(second_bearing_deg)
    first_direction = Point(math.cos(first_angle), math.sin(first_angle))
    second_direction = Point(math.cos(second_angle), math.sin(second_angle))
    determinant = first_direction.x * second_direction.y - first_direction.y * second_direction.x
    if abs(determinant) <= 1e-9:
        return None
    delta = Point(second_position.x - first_position.x, second_position.y - first_position.y)
    first_distance = (delta.x * second_direction.y - delta.y * second_direction.x) / determinant
    second_distance = (delta.x * first_direction.y - delta.y * first_direction.x) / determinant
    if first_distance < 0.0 or second_distance < 0.0:
        return None
    return Point(
        first_position.x + first_distance * first_direction.x,
        first_position.y + first_distance * first_direction.y,
    )


def _safe_second_station(anchor: Point, bearing_deg: float) -> Point:
    """Place a non-collinear, still-safe receiver 1000 m from the anchor."""
    angle = math.radians(bearing_deg + SAFE_SECOND_OFFSET_DEG)
    return Point(anchor.x + RECEIVE_RADIUS_LOWER_BOUND * math.cos(angle), anchor.y + RECEIVE_RADIUS_LOWER_BOUND * math.sin(angle))


def _fast_clear_candidates(
    first_position: Point,
    first_bearing_deg: float,
    second_position: Point,
    second_bearing_deg: float,
) -> tuple[Point, ...]:
    """Return a small, target-disk-filtered heuristic candidate set.

    The center rays are first.  The four endpoint crossings cover systematic
    ±1° endpoint cases cheaply, but are not used as a proof of clearance.
    """
    candidates: list[Point] = []
    center = _ray_intersection(first_position, first_bearing_deg, second_position, second_bearing_deg)
    if center is not None:
        candidates.append(center)
    for first_offset in (-1.0, 1.0):
        for second_offset in (-1.0, 1.0):
            candidate = _ray_intersection(
                first_position,
                first_bearing_deg + first_offset,
                second_position,
                second_bearing_deg + second_offset,
            )
            if candidate is not None:
                candidates.append(candidate)
    unique: list[Point] = []
    for candidate in candidates:
        if _distance(candidate, Point(0.0, 0.0)) > TARGET_RADIUS + 1e-9:
            continue
        if all(_distance(candidate, previous) > 1e-6 for previous in unique):
            unique.append(candidate)
    return tuple(unique)


@dataclass(frozen=True)
class StrategyExecutionResult:
    channel_states: dict[int, ChannelState]
    channel_evidence: dict[int, tuple[str, ...]]
    complete: bool


def execute_q3_strategy(robot: Any, public_state: Any) -> StrategyExecutionResult:
    """Duck-typed Q3 baseline: seven stations × twenty channels plus safe fallback.

    ``robot.measure(position, channel)`` must return an object/dict containing
    ``accepted`` and ``result``; a direction response also supplies ``svd_deg``.
    ``robot.clear(position, channel)`` returns ``accepted`` and ``success``.
    ``public_state`` is intentionally accepted for benchmark integration but
    never treated as hidden simulator truth.
    """
    del public_state
    plan = build_center_ring_plan()
    tracker = ChannelTracker(plan)
    evidence: dict[int, list[str]] = {channel: [] for channel in CHANNELS}
    direction_history: dict[int, list[tuple[Point, float]]] = {channel: [] for channel in CHANNELS}
    fast_path_attempted: set[int] = set()
    safe_second_station_attempted: set[int] = set()
    baseline = survey_cost(plan, snake_scan_plan(plan)).virtual_seconds
    for action in snake_scan_plan(plan):
        if tracker.state_of(action.channel) in (ChannelState.CLEARED, ChannelState.ABSENT_CERTIFIED):
            continue
        response = robot.measure(action.position, action.channel)
        accepted = _field(response, "accepted", False) is True
        result = _field(response, "result", _field(response, "measure_result", None))
        immediate = tracker.record_measurement(action.channel, action.station_id, accepted=accepted, result=result)
        if not accepted or result is None:
            evidence[action.channel].append("rejected_measure")
            continue
        evidence[action.channel].append(str(result))
        if immediate is not None:
            clear_response = robot.clear(immediate.position, immediate.channel)
            tracker.record_clear(immediate.channel, immediate.position, accepted=_field(clear_response, "accepted", False) is True, success=_field(clear_response, "success", _field(clear_response, "clear_result", None) == "success"))
            continue
        if result != "direction":
            continue
        bearing = _field(response, "svd_deg", None)
        if bearing is None:
            evidence[action.channel].append("direction_without_bearing_unresolved")
            continue
        direction_history[action.channel].append((action.position, float(bearing)))
        if action.channel not in safe_second_station_attempted:
            safe_second_station_attempted.add(action.channel)
            second_station = _safe_second_station(action.position, float(bearing))
            second_response = robot.measure(second_station, action.channel)
            second_accepted = _field(second_response, "accepted", False) is True
            second_result = _field(second_response, "result", _field(second_response, "measure_result", None))
            evidence[action.channel].append(f"safe_second_{second_result}" if second_accepted else "safe_second_rejected")
            if second_accepted and second_result == "direction":
                second_bearing = _field(second_response, "svd_deg", None)
                if second_bearing is not None:
                    direction_history[action.channel].append((second_station, float(second_bearing)))
            elif second_accepted and second_result == "near":
                clear_response = robot.clear(second_station, action.channel)
                accepted_clear = _field(clear_response, "accepted", False) is True
                success = _field(clear_response, "success", _field(clear_response, "clear_result", None) == "success")
                tracker.record_clear(action.channel, second_station, accepted=accepted_clear, success=success)
                evidence[action.channel].append("fast_path_clear_success" if accepted_clear and success else "fast_path_clear_failed")
                continue
        if len(direction_history[action.channel]) < 2 or action.channel in fast_path_attempted:
            continue
        fast_path_attempted.add(action.channel)
        first_position, first_bearing = direction_history[action.channel][0]
        second_position, second_bearing = direction_history[action.channel][1]
        candidates = _fast_clear_candidates(first_position, first_bearing, second_position, second_bearing)
        if not candidates:
            evidence[action.channel].append("fast_path_degenerate")
            continue
        for candidate in candidates:
            clear_response = robot.clear(candidate, action.channel)
            accepted_clear = _field(clear_response, "accepted", False) is True
            success = _field(clear_response, "success", _field(clear_response, "clear_result", None) == "success")
            tracker.record_clear(action.channel, candidate, accepted=accepted_clear, success=success)
            if accepted_clear and success:
                evidence[action.channel].append("fast_path_clear_success")
                break
        else:
            evidence[action.channel].append("fast_path_clear_failed")

    for channel, observations in direction_history.items():
        if tracker.state_of(channel) in (ChannelState.CLEARED, ChannelState.ABSENT_CERTIFIED) or not observations:
            continue
        anchor, bearing = observations[0]
        fallback = build_anchor_clearance_plan(channel=channel, anchor=anchor, bearing_deg=bearing)
        resources = certify_clearance_resources(
            fallback,
            baseline_virtual_seconds=baseline,
            fallback_start=plan.route[-1],
        )
        evidence[channel].append(resources.status)
        if resources.status != "FEASIBLE_ESTIMATE":
            continue
        for clear in fallback.actions:
            clear_response = robot.clear(clear.position, clear.channel)
            accepted_clear = _field(clear_response, "accepted", False) is True
            success = _field(clear_response, "success", _field(clear_response, "clear_result", None) == "success")
            tracker.record_clear(channel, clear.position, accepted=accepted_clear, success=success)
            if accepted_clear and success:
                evidence[channel].append("cleared_by_anchor_wedge")
                break
    return StrategyExecutionResult(dict(tracker.states), {channel: tuple(items) for channel, items in evidence.items()}, tracker.is_complete())
