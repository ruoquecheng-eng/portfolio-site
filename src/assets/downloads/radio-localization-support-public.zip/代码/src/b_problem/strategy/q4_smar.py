"""Isolated SMAR candidates; CERT-D remains unchanged by default."""
from __future__ import annotations

from typing import Any, Iterable

from .q4_cert_d import CertDExecutionResult, execute_q4_cert_d_strategy
from .q4_extreme import _direct_cross_range_pursuit_all_bearing


def execute_q4_smar_0_strategy(robot: Any, public_state: Any, *, channels: Iterable[int] = range(1, 21)) -> CertDExecutionResult:
    """Run the zero-new-observation all-positive-bearing candidate offline."""
    return execute_q4_cert_d_strategy(
        robot, public_state, channels=channels, local_pursuit=_direct_cross_range_pursuit_all_bearing
    )
