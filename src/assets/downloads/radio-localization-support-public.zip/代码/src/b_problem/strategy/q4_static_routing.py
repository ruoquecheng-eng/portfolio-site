"""Future-only static Q4 route certificates and task-routing scaffolding.

Nothing in this module is called by the Q4 execution strategy.  It analyses
the already certified station set and provides auditable building blocks for a
future route integration.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import inf
from typing import Iterable

from .q4 import Point


def open_route_length(start: Point, route: Iterable[Point]) -> float:
    current = start
    total = 0.0
    for point in route:
        total += current.distance_to(point)
        current = point
    return total


def nearest_neighbor_route(start: Point, stations: Iterable[Point]) -> tuple[Point, ...]:
    remaining = list(stations)
    current = start
    route: list[Point] = []
    while remaining:
        index, point = min(
            enumerate(remaining), key=lambda item: (current.distance_to(item[1]), item[1].x, item[1].y)
        )
        route.append(point)
        current = point
        remaining.pop(index)
    return tuple(route)


def multi_start_nearest_neighbor_route(start: Point, stations: Iterable[Point]) -> tuple[Point, ...]:
    points = tuple(stations)
    if not points:
        return ()
    candidates = [nearest_neighbor_route(start, points)]
    for first in points:
        remaining = tuple(point for point in points if point != first)
        candidates.append((first, *nearest_neighbor_route(first, remaining)))
    return min(candidates, key=lambda route: (open_route_length(start, route), route))


def open_two_opt(start: Point, route: Iterable[Point]) -> tuple[Point, ...]:
    """Improve an anchored open path; deliberately never adds a return edge."""
    best = tuple(route)
    best_length = open_route_length(start, best)
    improved = True
    while improved:
        improved = False
        for first in range(len(best) - 1):
            for last in range(first + 1, len(best)):
                candidate = (*best[:first], *reversed(best[first:last + 1]), *best[last + 1:])
                candidate_length = open_route_length(start, candidate)
                if candidate_length + 1e-9 < best_length:
                    best, best_length, improved = candidate, candidate_length, True
                    break
            if improved:
                break
    return best


def mst_lower_bound(start: Point, stations: Iterable[Point]) -> float:
    """Prim MST weight on the anchored station graph: a lower bound for any open visit path."""
    nodes = (start, *stations)
    if len(nodes) < 2:
        return 0.0
    connected = {0}
    best = [inf] * len(nodes)
    for index in range(1, len(nodes)):
        best[index] = nodes[0].distance_to(nodes[index])
    total = 0.0
    while len(connected) < len(nodes):
        index = min((item for item in range(len(nodes)) if item not in connected), key=best.__getitem__)
        total += best[index]
        connected.add(index)
        for other in range(len(nodes)):
            if other not in connected:
                best[other] = min(best[other], nodes[index].distance_to(nodes[other]))
    return total


@dataclass(frozen=True)
class CertAOpenRouteCertificate:
    snake_route: tuple[Point, ...]
    nn_route: tuple[Point, ...]
    multi_start_nn_route: tuple[Point, ...]
    two_opt_route: tuple[Point, ...]
    snake_length_m: float
    nn_length_m: float
    multi_start_nn_length_m: float
    two_opt_length_m: float
    mst_lower_bound_m: float
    snake_to_mst_ratio: float
    two_opt_to_mst_ratio: float


def cert_a_open_route_certificate(
    start: Point, stations: Iterable[Point], snake_route: Iterable[Point]
) -> CertAOpenRouteCertificate:
    """Compare snake/NN/multi-start/2-opt over exactly the supplied station set."""
    points = tuple(stations)
    snake = tuple(snake_route)
    if set(snake) != set(points) or len(snake) != len(points):
        raise ValueError("snake_route must visit every certified station exactly once")
    nn = nearest_neighbor_route(start, points)
    multi_start = multi_start_nearest_neighbor_route(start, points)
    refined = open_two_opt(start, multi_start)
    lower_bound = mst_lower_bound(start, points)
    ratio = lambda length: length / lower_bound if lower_bound else 1.0
    return CertAOpenRouteCertificate(
        snake_route=snake,
        nn_route=nn,
        multi_start_nn_route=multi_start,
        two_opt_route=refined,
        snake_length_m=open_route_length(start, snake),
        nn_length_m=open_route_length(start, nn),
        multi_start_nn_length_m=open_route_length(start, multi_start),
        two_opt_length_m=open_route_length(start, refined),
        mst_lower_bound_m=lower_bound,
        snake_to_mst_ratio=ratio(open_route_length(start, snake)),
        two_opt_to_mst_ratio=ratio(open_route_length(start, refined)),
    )


@dataclass(frozen=True)
class StaticRouteTask:
    task_type: str
    point: Point
    reason: str
    channel: int | None
    state: str


def open_task_route(start: Point, tasks: Iterable[StaticRouteTask]) -> tuple[StaticRouteTask, ...]:
    """Future-only nearest-neighbor ordering that preserves task identity."""
    remaining = list(tasks)
    current = start
    route: list[StaticRouteTask] = []
    while remaining:
        index, task = min(
            enumerate(remaining),
            key=lambda item: (
                current.distance_to(item[1].point), item[1].task_type,
                item[1].channel if item[1].channel is not None else -1,
            ),
        )
        route.append(task)
        current = task.point
        remaining.pop(index)
    return tuple(route)


@dataclass(frozen=True)
class FutureRouteTrace:
    from_point: Point
    to_point: Point
    reason: str
    channel: int | None
    task_type: str
    state: str

    @property
    def distance_m(self) -> float:
        return self.from_point.distance_to(self.to_point)

    def as_dict(self) -> dict[str, object]:
        return {
            "from": {"x": self.from_point.x, "y": self.from_point.y},
            "to": {"x": self.to_point.x, "y": self.to_point.y},
            "distance": self.distance_m,
            "reason": self.reason,
            "channel": self.channel,
            "task_type": self.task_type,
            "state": self.state,
        }
