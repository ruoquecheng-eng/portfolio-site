"""Models and offline tools for CUMCM problem B."""
