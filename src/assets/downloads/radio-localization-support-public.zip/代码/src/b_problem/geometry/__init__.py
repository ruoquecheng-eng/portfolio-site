"""Robust planar geometry primitives for bearing localization."""

from .core import (
    Circle,
    CurvilinearMetricCertification,
    CurvilinearRegion,
    DiameterResult,
    HalfPlane,
    IntersectionKind,
    MetricCertificationStatus,
    MetricInterval,
    Point,
    bearing_wedge,
    certify_curvilinear_metrics,
    clip_to_target_disk,
    intersect_halfplanes,
    minimum_enclosing_circle,
    polygon_diameter_bruteforce,
    polygon_diameter_calipers,
    regular_polygon_inner_error,
)

__all__ = [
    "Circle", "CurvilinearMetricCertification", "CurvilinearRegion", "DiameterResult", "HalfPlane",
    "IntersectionKind", "MetricCertificationStatus", "MetricInterval", "Point", "bearing_wedge",
    "certify_curvilinear_metrics", "clip_to_target_disk", "intersect_halfplanes", "minimum_enclosing_circle",
    "polygon_diameter_bruteforce", "polygon_diameter_calipers",
    "regular_polygon_inner_error",
]
