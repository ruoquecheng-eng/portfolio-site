"""Small, dependency-free primitives for closed planar half-planes."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from itertools import combinations

from scipy.optimize import linprog


@dataclass(frozen=True)
class Point:
    x: float
    y: float

    def __sub__(self, other: "Point") -> "Point":
        return Point(self.x - other.x, self.y - other.y)


def _cross(a: Point, b: Point) -> float:
    return a.x * b.y - a.y * b.x


@dataclass(frozen=True)
class HalfPlane:
    """The closed left side of a directed line through ``origin``."""

    origin: Point
    direction: Point
    keep_left: bool = True

    def __post_init__(self) -> None:
        if not math.isfinite(self.direction.x) or not math.isfinite(self.direction.y) or math.hypot(self.direction.x, self.direction.y) == 0.0:
            raise ValueError("half-plane direction must be finite and non-zero")

    def contains(self, point: Point, tolerance: float = 1e-10) -> bool:
        signed = _cross(self.direction, point - self.origin)
        scaled_tolerance = tolerance * math.hypot(self.direction.x, self.direction.y)
        return signed >= -scaled_tolerance if self.keep_left else signed <= scaled_tolerance

    def normal_and_offset(self) -> tuple[Point, float]:
        """Return ``n, b`` for the equivalent constraint ``n dot x >= b``."""
        normal = Point(-self.direction.y, self.direction.x)
        if not self.keep_left:
            normal = Point(-normal.x, -normal.y)
        return normal, normal.x * self.origin.x + normal.y * self.origin.y


@dataclass(frozen=True)
class BearingWedge:
    left_boundary: HalfPlane
    right_boundary: HalfPlane

    def contains(self, point: Point, tolerance: float = 1e-10) -> bool:
        return self.left_boundary.contains(point, tolerance) and self.right_boundary.contains(point, tolerance)


def bearing_wedge(station: Point, bearing_rad: float, error_rad: float = math.radians(1.0)) -> BearingWedge:
    """Return the closed angular wedge centered at a bearing.

    Unit vectors avoid any special branch at 0/360 degrees.  The construction
    is convex exactly for the supported small-error case ``2*error_rad <= pi``.
    """
    if not 0.0 <= error_rad <= math.pi / 2:
        raise ValueError("bearing wedge requires an error angle in [0, pi/2]")
    left_angle = bearing_rad - error_rad
    right_angle = bearing_rad + error_rad
    left = Point(math.cos(left_angle), math.sin(left_angle))
    right = Point(math.cos(right_angle), math.sin(right_angle))
    return BearingWedge(HalfPlane(station, left, True), HalfPlane(station, right, False))


class IntersectionKind(str, Enum):
    EMPTY = "empty"
    UNBOUNDED = "unbounded"
    POINT = "point"
    SEGMENT = "segment"
    POLYGON = "polygon"


@dataclass(frozen=True)
class HalfPlaneIntersection:
    kind: IntersectionKind
    vertices: tuple[Point, ...] = ()


def _line_intersection(first: HalfPlane, second: HalfPlane, tolerance: float) -> Point | None:
    a, b = first.normal_and_offset()
    c, d = second.normal_and_offset()
    determinant = a.x * c.y - a.y * c.x
    scale = math.hypot(a.x, a.y) * math.hypot(c.x, c.y)
    if abs(determinant) <= tolerance * scale:
        return None
    return Point((b * c.y - a.y * d) / determinant, (a.x * d - b * c.x) / determinant)


def _deduplicate(points: list[Point], tolerance: float) -> list[Point]:
    unique: list[Point] = []
    for point in points:
        if not any(math.hypot(point.x - known.x, point.y - known.y) <= tolerance for known in unique):
            unique.append(point)
    return unique


def _ordered_hull(points: list[Point], tolerance: float) -> tuple[IntersectionKind, tuple[Point, ...]]:
    if len(points) == 1:
        return IntersectionKind.POINT, (points[0],)
    if len(points) == 2:
        return IntersectionKind.SEGMENT, tuple(points)

    center = Point(sum(p.x for p in points) / len(points), sum(p.y for p in points) / len(points))
    ordered = sorted(points, key=lambda p: math.atan2(p.y - center.y, p.x - center.x))
    twice_area = abs(sum(
        ordered[i].x * ordered[(i + 1) % len(ordered)].y
        - ordered[i].y * ordered[(i + 1) % len(ordered)].x
        for i in range(len(ordered))
    ))
    if twice_area <= tolerance:
        first, second = max(combinations(points, 2), key=lambda pair: math.hypot(pair[0].x - pair[1].x, pair[0].y - pair[1].y))
        return IntersectionKind.SEGMENT, (first, second)
    return IntersectionKind.POLYGON, tuple(ordered)


def intersect_halfplanes(halfplanes: list[HalfPlane], tolerance: float = 1e-10) -> HalfPlaneIntersection:
    """Classify the intersection of closed half-planes in the full plane.

    Feasibility and unboundedness are delegated to HiGHS through frozen SciPy;
    finite vertices are reconstructed only from non-parallel boundary pairs.
    """
    if not halfplanes:
        return HalfPlaneIntersection(IntersectionKind.UNBOUNDED)
    if tolerance <= 0.0:
        raise ValueError("tolerance must be positive")
    # HiGHS applies feasibility tolerances to the submitted coefficients.
    # Normalize each line first, otherwise an equivalent rescaling changes
    # whether a narrow contradiction is reported feasible.
    constraints = []
    for plane in halfplanes:
        normal, offset = plane.normal_and_offset()
        scale = math.hypot(normal.x, normal.y)
        constraints.append((Point(normal.x / scale, normal.y / scale), offset / scale))
    a_ub = [[-normal.x, -normal.y] for normal, _ in constraints]
    b_ub = [-offset for _, offset in constraints]
    solver_options = {
        "primal_feasibility_tolerance": max(tolerance, 1e-10),
        "dual_feasibility_tolerance": max(tolerance, 1e-10),
    }
    feasibility = linprog(
        [0.0, 0.0], A_ub=a_ub, b_ub=b_ub, bounds=[(None, None), (None, None)],
        method="highs", options=solver_options,
    )
    if feasibility.status == 2:
        return HalfPlaneIntersection(IntersectionKind.EMPTY)
    if not feasibility.success:
        raise RuntimeError(f"half-plane feasibility failed: {feasibility.message}")

    for objective in ([1.0, 0.0], [-1.0, 0.0], [0.0, 1.0], [0.0, -1.0]):
        bound = linprog(
            objective, A_ub=a_ub, b_ub=b_ub, bounds=[(None, None), (None, None)],
            method="highs", options=solver_options,
        )
        if bound.status == 3:
            return HalfPlaneIntersection(IntersectionKind.UNBOUNDED)
        if not bound.success:
            raise RuntimeError(f"half-plane bound failed: {bound.message}")

    candidates = []
    for first, second in combinations(halfplanes, 2):
        point = _line_intersection(first, second, tolerance)
        if point is not None and all(plane.contains(point, tolerance) for plane in halfplanes):
            candidates.append(point)
    unique = _deduplicate(candidates, tolerance)
    if not unique:
        point = Point(float(feasibility.x[0]), float(feasibility.x[1]))
        return HalfPlaneIntersection(IntersectionKind.POINT, (point,))
    kind, vertices = _ordered_hull(unique, tolerance)
    return HalfPlaneIntersection(kind, vertices)


@dataclass(frozen=True)
class DiameterResult:
    distance: float
    first: Point
    second: Point


def _distance(first: Point, second: Point) -> float:
    return math.hypot(first.x - second.x, first.y - second.y)


def polygon_diameter_bruteforce(vertices: tuple[Point, ...]) -> DiameterResult:
    """Return a convex polygon's diameter by exhaustive vertex-pair search."""
    if not vertices:
        raise ValueError("diameter is undefined for an empty polygon")
    if len(vertices) == 1:
        return DiameterResult(0.0, vertices[0], vertices[0])
    first, second = max(combinations(vertices, 2), key=lambda pair: _distance(*pair))
    return DiameterResult(_distance(first, second), first, second)


def _triangle_area2(first: Point, second: Point, third: Point) -> float:
    return abs(_cross(second - first, third - first))


def _validate_ccw_convex_polygon(vertices: tuple[Point, ...], tolerance: float) -> None:
    """Reject sequences for which antipodal-pair traversal has no proof."""
    if len(vertices) <= 2:
        return
    if len({(point.x, point.y) for point in vertices}) != len(vertices):
        raise ValueError("calipers requires distinct polygon vertices")
    turns = [_cross(vertices[(index + 1) % len(vertices)] - vertices[index], vertices[(index + 2) % len(vertices)] - vertices[(index + 1) % len(vertices)]) for index in range(len(vertices))]
    if any(turn < -tolerance for turn in turns) or not any(turn > tolerance for turn in turns):
        raise ValueError("calipers requires a non-degenerate CCW convex polygon")

    points = sorted(vertices, key=lambda point: (point.x, point.y))

    def build_half(sequence: list[Point]) -> list[Point]:
        hull: list[Point] = []
        for point in sequence:
            while len(hull) >= 2 and _cross(hull[-1] - hull[-2], point - hull[-1]) <= tolerance:
                hull.pop()
            hull.append(point)
        return hull

    hull = tuple(build_half(points)[:-1] + build_half(list(reversed(points)))[:-1])
    if len(hull) < 3 or abs(_polygon_area2(vertices) - _polygon_area2(hull)) > tolerance * len(vertices):
        raise ValueError("calipers requires vertices ordered once around their CCW convex hull")


def polygon_diameter_calipers(vertices: tuple[Point, ...], tolerance: float = 1e-10) -> DiameterResult:
    """Return the diameter of a CCW convex polygon via antipodal pairs."""
    count = len(vertices)
    if count <= 2:
        return polygon_diameter_bruteforce(vertices)
    _validate_ccw_convex_polygon(vertices, tolerance)
    best = polygon_diameter_bruteforce(vertices[:2])
    opposite = 1
    for index in range(count):
        following = (index + 1) % count
        while _triangle_area2(vertices[index], vertices[following], vertices[(opposite + 1) % count]) > (
            _triangle_area2(vertices[index], vertices[following], vertices[opposite]) + tolerance
        ):
            opposite = (opposite + 1) % count
        for pair in ((vertices[index], vertices[opposite]), (vertices[following], vertices[opposite])):
            candidate = DiameterResult(_distance(*pair), *pair)
            if candidate.distance > best.distance:
                best = candidate
        next_area = _triangle_area2(vertices[index], vertices[following], vertices[(opposite + 1) % count])
        current_area = _triangle_area2(vertices[index], vertices[following], vertices[opposite])
        if abs(next_area - current_area) <= tolerance:
            pair = (vertices[index], vertices[(opposite + 1) % count])
            candidate = DiameterResult(_distance(*pair), *pair)
            if candidate.distance > best.distance:
                best = candidate
    return best


@dataclass(frozen=True)
class Circle:
    center: Point
    radius: float

    def contains(self, point: Point, tolerance: float = 1e-10) -> bool:
        return _distance(self.center, point) <= self.radius + tolerance


@dataclass(frozen=True)
class CurvilinearRegion:
    """An exact disk-and-half-plane region; its circular constraint is retained."""

    disk: Circle
    halfplanes: tuple[HalfPlane, ...]

    @property
    def has_circular_boundary(self) -> bool:
        return True

    @property
    def is_polygon(self) -> bool:
        return False

    def contains(self, point: Point, tolerance: float = 1e-10) -> bool:
        return self.disk.contains(point, tolerance) and all(plane.contains(point, tolerance) for plane in self.halfplanes)


def clip_to_target_disk(halfplanes: list[HalfPlane], radius: float = 1800.0, center: Point = Point(0.0, 0.0)) -> CurvilinearRegion:
    """Keep the target circle exact while intersecting it with closed half-planes."""
    if radius <= 0.0:
        raise ValueError("target disk radius must be positive")
    return CurvilinearRegion(Circle(center, radius), tuple(halfplanes))


def regular_polygon_inner_error(radius: float, sides: int) -> float:
    """Return the maximum radial gap to an inscribed regular polygon.

    The bound is the sagitta ``R * (1 - cos(pi / sides))``.  It certifies
    only the disk approximation; any clipped-region use must propagate it.
    """
    if radius <= 0.0:
        raise ValueError("radius must be positive")
    if sides < 3:
        raise ValueError("an inscribed polygon needs at least three sides")
    return radius * (1.0 - math.cos(math.pi / sides))


def _circle_from_pair(first: Point, second: Point) -> Circle:
    center = Point((first.x + second.x) / 2.0, (first.y + second.y) / 2.0)
    return Circle(center, _distance(first, second) / 2.0)


def _circle_from_triple(first: Point, second: Point, third: Point, tolerance: float) -> Circle | None:
    determinant = 2.0 * _cross(second - first, third - first)
    if abs(determinant) <= tolerance:
        return None
    first_norm = first.x * first.x + first.y * first.y
    second_norm = second.x * second.x + second.y * second.y
    third_norm = third.x * third.x + third.y * third.y
    center = Point(
        (first_norm * (second.y - third.y) + second_norm * (third.y - first.y) + third_norm * (first.y - second.y)) / determinant,
        (first_norm * (third.x - second.x) + second_norm * (first.x - third.x) + third_norm * (second.x - first.x)) / determinant,
    )
    return Circle(center, _distance(center, first))


def minimum_enclosing_circle(points: tuple[Point, ...], tolerance: float = 1e-10) -> Circle:
    """Return the exact MEC by incremental one-, two-, and three-point supports."""
    if not points:
        raise ValueError("minimum enclosing circle is undefined for no points")
    circle = Circle(points[0], 0.0)
    for first_index, first in enumerate(points):
        if circle.contains(first, tolerance):
            continue
        circle = Circle(first, 0.0)
        for second_index in range(first_index):
            second = points[second_index]
            if circle.contains(second, tolerance):
                continue
            circle = _circle_from_pair(first, second)
            for third_index in range(second_index):
                third = points[third_index]
                if circle.contains(third, tolerance):
                    continue
                triple = _circle_from_triple(first, second, third, tolerance)
                if triple is None:
                    pairs = (
                        _circle_from_pair(first, second), _circle_from_pair(first, third), _circle_from_pair(second, third),
                    )
                    circle = min(
                        (candidate for candidate in pairs if all(candidate.contains(point, tolerance) for point in (first, second, third))),
                        key=lambda candidate: candidate.radius,
                    )
                else:
                    circle = triple
    return circle


class MetricCertificationStatus(str, Enum):
    """Whether polygonal bounds prove metrics for a full-dimensional region."""

    PROVED = "PROVED"
    UNRESOLVED = "UNRESOLVED"


@dataclass(frozen=True)
class MetricInterval:
    """Monotone lower/upper bound for one compact-set metric."""

    lower: float
    upper: float

    @property
    def error(self) -> float:
        return self.upper - self.lower


@dataclass(frozen=True)
class CurvilinearMetricCertification:
    """Certified metric intervals from inner/outer disk polygon approximations."""

    status: MetricCertificationStatus
    diameter: MetricInterval | None
    mec_radius: MetricInterval | None
    sides: int
    reason: str


def _polygon_area2(vertices: tuple[Point, ...]) -> float:
    return sum(
        vertices[index].x * vertices[(index + 1) % len(vertices)].y
        - vertices[index].y * vertices[(index + 1) % len(vertices)].x
        for index in range(len(vertices))
    )


def _deduplicate_cycle(points: list[Point], tolerance: float) -> tuple[Point, ...]:
    unique: list[Point] = []
    for point in points:
        if not unique or _distance(point, unique[-1]) > tolerance:
            unique.append(point)
    if len(unique) > 1 and _distance(unique[0], unique[-1]) <= tolerance:
        unique.pop()
    return tuple(unique)


def _clip_convex_polygon(
    vertices: tuple[Point, ...], plane: HalfPlane, tolerance: float, *, inward: bool
) -> tuple[Point, ...]:
    """Clip a CCW convex polygon to one closed half-plane."""
    if not vertices:
        return ()

    def margin(point: Point) -> float:
        signed = _cross(plane.direction, point - plane.origin)
        return signed if plane.keep_left else -signed

    # Inner bounds use a slightly shrunken half-plane; outer bounds use the
    # matching expansion.  This keeps finite arithmetic from reversing the
    # required subset/superset relation.
    threshold = (1.0 if inward else -1.0) * tolerance * math.hypot(plane.direction.x, plane.direction.y)
    clipped: list[Point] = []
    previous = vertices[-1]
    previous_margin = margin(previous)
    previous_inside = previous_margin >= threshold
    for current in vertices:
        current_margin = margin(current)
        current_inside = current_margin >= threshold
        if current_inside != previous_inside:
            fraction = (previous_margin - threshold) / (previous_margin - current_margin)
            clipped.append(Point(
                previous.x + fraction * (current.x - previous.x),
                previous.y + fraction * (current.y - previous.y),
            ))
        if current_inside:
            clipped.append(current)
        previous, previous_margin, previous_inside = current, current_margin, current_inside
    return _deduplicate_cycle(clipped, tolerance)


def _clip_disk_polygon(
    vertices: tuple[Point, ...], halfplanes: tuple[HalfPlane, ...], tolerance: float, *, inward: bool
) -> tuple[Point, ...]:
    clipped = vertices
    for plane in halfplanes:
        clipped = _clip_convex_polygon(clipped, plane, tolerance, inward=inward)
        if not clipped:
            break
    return clipped


def _regular_disk_polygon(circle: Circle, sides: int, *, outer: bool) -> tuple[Point, ...]:
    """Return an inscribed polygon or a circumscribed polygon containing a disk."""
    radial = circle.radius / math.cos(math.pi / sides) if outer else circle.radius
    phase = math.pi / sides if outer else 0.0
    return tuple(
        Point(circle.center.x + radial * math.cos(phase + 2.0 * math.pi * index / sides),
              circle.center.y + radial * math.sin(phase + 2.0 * math.pi * index / sides))
        for index in range(sides)
    )


def certify_curvilinear_metrics(
    region: CurvilinearRegion, *, sides: int = 256, tolerance: float = 1e-10
) -> CurvilinearMetricCertification:
    """Bound diameter and MEC radius of a disk-and-half-plane region.

    The inscribed disk polygon clipped by the half-planes is a subset of the
    true region; clipping a circumscribed disk polygon yields a superset.
    Diameter and MEC radius are monotone under set inclusion, so their two
    polygon metrics are rigorous lower/upper bounds.  A non-positive-area
    inner polygon cannot certify a full-dimensional region and is returned as
    ``UNRESOLVED`` rather than assigned metrics for a point or segment.
    """
    if sides < 8:
        raise ValueError("at least eight polygon sides are required")
    if tolerance <= 0.0:
        raise ValueError("tolerance must be positive")

    inner = _clip_disk_polygon(
        _regular_disk_polygon(region.disk, sides, outer=False), region.halfplanes, tolerance, inward=True,
    )
    outer = _clip_disk_polygon(
        _regular_disk_polygon(region.disk, sides, outer=True), region.halfplanes, tolerance, inward=False,
    )
    if len(inner) < 3 or abs(_polygon_area2(inner)) <= tolerance:
        return CurvilinearMetricCertification(
            MetricCertificationStatus.UNRESOLVED, None, None, sides,
            "The inner approximation has no certified positive area; the exact region may be empty or lower-dimensional.",
        )
    if len(outer) < 3 or abs(_polygon_area2(outer)) <= tolerance:
        return CurvilinearMetricCertification(
            MetricCertificationStatus.UNRESOLVED, None, None, sides,
            "The outer approximation is lower-dimensional; no finite full-dimensional metric bracket is certified.",
        )

    inner_diameter = polygon_diameter_calipers(inner, tolerance).distance
    outer_diameter = polygon_diameter_calipers(outer, tolerance).distance
    inner_mec = minimum_enclosing_circle(inner, tolerance).radius
    outer_mec = minimum_enclosing_circle(outer, tolerance).radius
    return CurvilinearMetricCertification(
        MetricCertificationStatus.PROVED,
        MetricInterval(inner_diameter, outer_diameter),
        MetricInterval(inner_mec, outer_mec),
        sides,
        "Inner and outer convex polygon bounds certify the displayed metric intervals.",
    )
