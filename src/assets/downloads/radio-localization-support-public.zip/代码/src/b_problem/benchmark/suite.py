"""Frozen full-factor offline suite and auditable single-case runner."""
from __future__ import annotations

from dataclasses import asdict
from itertools import product

from b_problem.strategy import q3, q4

from .generator import build_case
from .metrics import score_trace
from .runner import run_strategy
from .types import Case, ScenarioSpec


COUNTS = (10, 13, 16)
SPATIAL_FAMILIES = ("uniform", "boundary", "cluster", "separated", "grid_boundary")
RADIUS_MODES = ("r1000", "r1500", "mixed")
ERROR_MODES = ("zero", "plus1", "minus1", "fixed_hash")
EXTENDED_COUNTS = tuple(range(10, 17))
_EXTENDED_VARIANTS = (
    ("boundary", "r1000", "plus1"),
    ("cluster", "r1500", "minus1"),
    ("separated", "mixed", "fixed_hash"),
)


def build_full_suite(seed_base: int = 202_609_100) -> tuple[Case, ...]:
    """Return one immutable holdout case for every declared factor tuple."""
    cases: list[Case] = []
    seed = seed_base
    for question, orientations in (("Q3", ("none",)), ("Q4", ("random", "adversarial", "boundary"))):
        for count, spatial, radius, error, orientation in product(
            COUNTS, SPATIAL_FAMILIES, RADIUS_MODES, ERROR_MODES, orientations
        ):
            cases.append(build_case(ScenarioSpec(
                question, count, spatial, radius, error, orientation, seed, "holdout"
            )))
            seed += 1
    return tuple(cases)


def build_extended_holdout_suite(seed_base: int = 202_610_100) -> tuple[Case, ...]:
    """Return a bounded 42-case holdout spanning untested source counts and channel IDs."""
    cases: list[Case] = []
    seed = seed_base
    for count in EXTENDED_COUNTS:
        for question, orientations in (("Q3", ("none",) * 3), ("Q4", ("adversarial",) * 3)):
            for variant, (spatial, radius, error) in enumerate(_EXTENDED_VARIANTS):
                cases.append(build_case(ScenarioSpec(
                    question, count, spatial, radius, error, orientations[variant], seed,
                    "holdout", _extended_channels(count, variant),
                )))
                seed += 1
    return tuple(cases)


def _extended_channels(count: int, variant: int) -> tuple[int, ...]:
    if variant == 0:
        return tuple(range(1, count + 1))
    if variant == 1:
        return tuple(range(21 - count, 21))
    if count == 10:
        return tuple(range(1, 21, 2))
    pool = (1, 20, 3, 18, 5, 16, 7, 14, 9, 12, 2, 19, 4, 17, 6, 15, 8, 13, 10, 11)
    return pool[:count]


def extended_coverage_certificate(cases: tuple[Case, ...]) -> dict:
    """Audit the compact extended matrix without changing frozen-suite coverage rules."""
    counts = {case.spec.target_count for case in cases}
    questions = {case.spec.question for case in cases}
    channel_shapes = {_channel_shape(case.spec.channel_ids or ()) for case in cases}
    q4_orientations = {case.spec.orientation_mode for case in cases if case.spec.question == "Q4"}
    spatial = {case.spec.spatial for case in cases}
    radius_modes = {case.spec.radius_mode for case in cases}
    error_modes = {case.spec.error_mode for case in cases}
    required_shapes = {"low", "high", "sparse", "mixed_non_contiguous"}
    unique_cases = len({case.truth_digest for case in cases}) == len(cases)
    ids_match = all(tuple(target.channel for target in case.targets) == case.spec.channel_ids for case in cases)
    missing_counts = sorted(set(EXTENDED_COUNTS) - counts)
    missing_channel_shapes = sorted(required_shapes - channel_shapes)
    missing_questions = sorted({"Q3", "Q4"} - questions)
    required_q4_orientations = {"adversarial"}
    passed = (
        len(cases) == 42 and not missing_counts and not missing_questions and not missing_channel_shapes
        and required_q4_orientations <= q4_orientations
        and {"boundary", "cluster", "separated"} <= spatial
        and {"r1000", "r1500", "mixed"} <= radius_modes
        and {"plus1", "minus1"} <= error_modes
        and all(case.spec.split == "holdout" for case in cases) and unique_cases and ids_match
    )
    return {
        "case_count": len(cases), "counts": sorted(counts), "questions": sorted(questions),
        "channel_shapes": sorted(channel_shapes), "missing_counts": missing_counts,
        "missing_questions": missing_questions, "missing_channel_shapes": missing_channel_shapes,
        "spatial": sorted(spatial), "radius_modes": sorted(radius_modes),
        "error_modes": sorted(error_modes), "q4_orientations": sorted(q4_orientations),
        "threshold_contract_m": [5.0, 20.0], "all_holdout": all(case.spec.split == "holdout" for case in cases),
        "unique_cases": unique_cases, "channel_ids_match_targets": ids_match, "pass": passed,
    }


def _channel_shape(channels: tuple[int, ...]) -> str:
    count = len(channels)
    if channels == tuple(range(1, count + 1)):
        return "low"
    if channels == tuple(range(21 - count, 21)):
        return "high"
    if channels == tuple(range(1, 21, 2)):
        return "sparse"
    return "mixed_non_contiguous"


def run_case(case: Case) -> dict:
    """Execute the matching strategy and return metrics plus time components."""
    result_box = []
    execute = q3.execute_q3_strategy if case.spec.question == "Q3" else q4.execute_q4_strategy

    def strategy(arena) -> None:
        result_box.append(execute(arena, arena.public_state))

    trace = run_strategy(strategy, case)
    metrics = score_trace(case, trace)
    components = {
        "movement": metrics.movement_distance_m / 5.0,
        "switching": float(metrics.switch_count),
        "measurement": 5.0 * metrics.measure_count,
        "successful_clear": 5.0 * metrics.successful_clear_count,
        "failed_clear": 3.0 * metrics.failed_clear_count,
    }
    return {
        "case_id": case.truth_digest,
        "spec": asdict(case.spec),
        "complete": bool(result_box and result_box[0].complete),
        "metrics": asdict(metrics),
        "action_count": len(trace),
        "virtual_time_components_s": components,
    }


def run_extended_case(case: Case) -> dict:
    """Run one extended holdout case and retain a non-sensitive failure record if needed."""
    try:
        result = run_case(case)
    except Exception as exc:
        return {
            "case_id": case.truth_digest,
            "spec": asdict(case.spec),
            "strategy_execution_status": "failed",
            "execution_error_type": type(exc).__name__,
        }
    return {**result, "strategy_execution_status": "completed"}
