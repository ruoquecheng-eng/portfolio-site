from __future__ import annotations

from .types import Case


def coverage_certificate(cases: tuple[Case, ...], *, holdout_seeds: set[int], tuning_seeds: set[int]) -> dict:
    observed = {
        "counts": sorted({case.spec.target_count for case in cases}),
        "questions": sorted({case.spec.question for case in cases}),
        "spatial": sorted({case.spec.spatial for case in cases}),
        "radius": sorted({case.spec.radius_mode for case in cases}),
        "errors": sorted({case.spec.error_mode for case in cases}),
        "orientation": sorted({case.spec.orientation_mode for case in cases}),
    }
    required = {
        "questions": {"Q3", "Q4"}, "counts": {10, 13, 16},
        "spatial": {"uniform", "boundary", "cluster", "separated", "grid_boundary"},
        "radius": {"r1000", "r1500", "mixed"},
        "errors": {"zero", "plus1", "minus1", "fixed_hash"},
        "orientation": {"none", "random", "adversarial", "boundary"},
    }
    missing = {key: sorted(values - set(observed[key])) for key, values in required.items()}
    complete = all(not values for values in missing.values())
    disjoint = holdout_seeds.isdisjoint(tuning_seeds)
    expected_combinations = {
        (question, count, spatial, radius, error, orientation)
        for question, orientations in (("Q3", ("none",)), ("Q4", ("random", "adversarial", "boundary")))
        for count in required["counts"]
        for spatial in required["spatial"]
        for radius in required["radius"]
        for error in required["errors"]
        for orientation in orientations
    }
    observed_combinations = {
        (case.spec.question, case.spec.target_count, case.spec.spatial, case.spec.radius_mode,
         case.spec.error_mode, case.spec.orientation_mode)
        for case in cases
    }
    missing_combinations = sorted(expected_combinations - observed_combinations)
    split_bound = all(
        (case.spec.split == "holdout" and case.spec.seed in holdout_seeds)
        or (case.spec.split == "tuning" and case.spec.seed in tuning_seeds)
        for case in cases
    )
    unique_cases = len({case.truth_digest for case in cases}) == len(cases)
    return {"case_ids": [case.truth_digest for case in cases], "observed": observed,
            "missing": missing, "holdout_disjoint": disjoint,
            "observed_combinations": sorted(observed_combinations),
            "missing_combinations": missing_combinations,
            "split_bound": split_bound, "unique_cases": unique_cases,
            "pass": bool(cases) and disjoint and split_bound and unique_cases and complete and not missing_combinations}
