from __future__ import annotations

import math

from .types import Case, MeasurementObservation, Metrics, Point, Trace


def _distance(first: Point, second: Point) -> float:
    return math.hypot(first.x - second.x, first.y - second.y)


def _validate_trace_identity(case: Case, trace: tuple[Trace, ...]) -> None:
    position = Point(0.0, 0.0)
    measure_channel = 1
    cleared: set[int] = set()
    targets = {target.channel: target for target in case.targets}
    for event in trace:
        movement = _distance(position, event.action.position)
        if not math.isclose(event.movement_m, movement, rel_tol=0.0, abs_tol=1e-9):
            raise ValueError("trace movement does not match action positions")
        if event.action.kind == "measure":
            if not isinstance(event.result, MeasurementObservation):
                raise ValueError("measure trace has no observation")
            switched = event.action.channel != measure_channel
            expected = movement / 5.0 + (1.0 if switched else 0.0) + 5.0
            if event.switched is not switched:
                raise ValueError("trace switch flag does not match channel state")
            measure_channel = event.action.channel
        else:
            if event.switched:
                raise ValueError("clear action cannot switch measurement channel")
            if event.result == "success":
                target = targets.get(event.action.channel)
                if target is None or event.action.channel in cleared or _distance(event.action.position, target.position) > 20.0:
                    raise ValueError("trace claims an impossible clear success")
                cleared.add(event.action.channel)
                expected = movement / 5.0 + 5.0
            else:
                expected = movement / 5.0 + 3.0
        if not math.isclose(event.delta_s, expected, rel_tol=0.0, abs_tol=1e-9):
            raise ValueError("trace duration does not match action mechanics")
        position = event.action.position


def score_trace(case: Case, trace: tuple[Trace, ...]) -> Metrics:
    _validate_trace_identity(case, trace)
    measures = [event for event in trace if event.action.kind == "measure"]
    clears = [event for event in trace if event.action.kind == "clear"]
    successes = [event for event in clears if event.result == "success"]
    failed = [event for event in clears if event.result != "success"]
    movement = sum(event.movement_m for event in trace)
    switches = sum(event.switched for event in measures)
    total = sum(event.delta_s for event in trace)
    return Metrics(len(successes) / len(case.targets), total,
                   total / len(successes) if successes else None, movement, len(measures),
                   switches, len(clears), len(failed), len(successes))


def aggregate(items: tuple[Metrics, ...]) -> dict:
    def summary(values: list[float], lower_is_worse: bool = False) -> dict:
        if not values:
            return {"p50": None, "p90": None, "worst": None}
        ordered = sorted(values)
        percentile = lambda p: ordered[math.ceil(p * len(ordered)) - 1]
        return {"p50": percentile(.5), "p90": percentile(.9),
                "worst": min(values) if lower_is_worse else max(values)}
    return {
        "clear_rate": summary([item.clear_rate for item in items], True),
        "total_virtual_time_s": summary([item.total_virtual_time_s for item in items]),
        "mean_clear_time_s": summary([item.mean_clear_time_s for item in items if item.mean_clear_time_s is not None]),
        "movement_distance_m": summary([item.movement_distance_m for item in items]),
    }
