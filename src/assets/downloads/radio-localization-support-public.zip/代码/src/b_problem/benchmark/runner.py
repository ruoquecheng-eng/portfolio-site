from __future__ import annotations

from dataclasses import dataclass
import inspect
from typing import Callable

from .offline_arena import OfflineArena
from .types import Case, Point, PublicStateView, Trace


class PublicArena:
    """Narrow cooperative-strategy facade; Python reflection remains unresolved."""

    def __init__(self, arena: OfflineArena) -> None:
        self.__arena = arena

    @property
    def public_state(self) -> PublicStateView:
        return self.__arena.public_state

    def measure(self, position: Point, channel: int) -> str:
        return self.__arena.measure(position, channel)

    def clear(self, position: Point, channel: int) -> str:
        return self.__arena.clear(position, channel)


@dataclass(frozen=True)
class IsolationAssessment:
    status: str
    reason: str


def cooperative_strategy_assessment(strategy: Callable[[PublicArena], None]) -> IsolationAssessment:
    """Reject common direct truth imports; this is not process isolation."""
    if not callable(strategy):
        raise ValueError("strategy must be callable")
    prohibited = {"_PublicArena__arena", "_case", "OfflineArena", "Case", "Target"}
    pending = [strategy.__code__] if hasattr(strategy, "__code__") else []
    names: set[str] = set()
    while pending:
        code = pending.pop()
        names.update(code.co_names)
        pending.extend(item for item in code.co_consts if inspect.iscode(item))
    if names & prohibited:
        raise RuntimeError("cooperative strategy may not access benchmark truth")
    closure = inspect.getclosurevars(strategy)
    if any(isinstance(value, (Case, OfflineArena)) for value in (*closure.globals.values(), *closure.nonlocals.values())):
        raise RuntimeError("cooperative strategy may not capture benchmark truth")
    return IsolationAssessment(
        "UNRESOLVED",
        "Static checks reject common direct truth access; same-process reflection is not strong isolation.",
    )


def run_strategy(strategy: Callable[[PublicArena], None], case: Case) -> tuple[Trace, ...]:
    cooperative_strategy_assessment(strategy)
    arena = OfflineArena(case)
    strategy(PublicArena(arena))
    return arena.trace
