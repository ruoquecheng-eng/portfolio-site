from __future__ import annotations

import math
from dataclasses import replace
import time
from typing import Callable, Protocol

from .types import Action, Case, MeasurementObservation, Point, PublicStateView, Trace


class Strategy(Protocol):
    def run(self, arena: "OfflineArena") -> None: ...


class OfflineArena:
    """Deterministic arena for cooperative strategies, not a security boundary."""

    def __init__(self, case: Case, *, max_virtual_duration_s: float = 360_000.0,
                 max_real_duration_s: float = 1_200.0, max_actions: int = 100_000,
                 clock: Callable[[], float] = time.monotonic) -> None:
        if not isinstance(case, Case):
            raise ValueError("case must be a Case")
        if not all(isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0.0
                   for value in (max_virtual_duration_s, max_real_duration_s)):
            raise ValueError("time budgets must be finite and non-negative")
        if isinstance(max_actions, bool) or not isinstance(max_actions, int) or max_actions < 1:
            raise ValueError("max_actions must be a positive integer")
        self._case = case
        self._cleared: set[int] = set()
        self._state = PublicStateView(Point(0.0, 0.0), 1, 0.0)
        self._trace: list[Trace] = []
        self._max_virtual_duration_s = float(max_virtual_duration_s)
        self._max_real_duration_s = float(max_real_duration_s)
        self._max_actions = max_actions
        self._clock = clock
        self._started_at = clock()

    @property
    def public_state(self) -> PublicStateView:
        return self._state

    @property
    def virtual_time_s(self) -> float:
        return self._state.virtual_time_s

    @property
    def trace(self) -> tuple[Trace, ...]:
        return tuple(self._trace)

    def measure(self, position: Point, channel: int) -> MeasurementObservation:
        self._validate(channel)
        position = self._coerce_point(position)
        movement = self._distance(self._state.position, position)
        switched = channel != self._state.measure_channel
        delta = movement / 5 + (1 if switched else 0) + 5
        self._reserve(delta)
        target = next((target for target in self._case.targets if target.channel == channel), None)
        if target is None or target.channel in self._cleared or not self._covered(target, position):
            observation = MeasurementObservation("no_signal", None)
        elif self._distance(position, target.position) <= 5:
            observation = MeasurementObservation("near", None)
        else:
            bearing = math.degrees(math.atan2(target.position.y - position.y, target.position.x - position.x)) % 360.0
            observation = MeasurementObservation("direction", (bearing + self._case.error_deg(channel, position)) % 360.0)
        self._advance(position, channel, delta)
        self._trace.append(Trace(Action("measure", position, channel), observation, movement, switched, delta))
        return observation

    def clear(self, position: Point, channel: int) -> str:
        self._validate(channel)
        position = self._coerce_point(position)
        movement = self._distance(self._state.position, position)
        target = next((target for target in self._case.targets if target.channel == channel), None)
        success = target is not None and channel not in self._cleared and self._distance(position, target.position) <= 20
        delta = movement / 5 + (5 if success else 3)
        self._reserve(delta)
        if success:
            self._cleared.add(channel)
        self._state = replace(self._state, position=position, virtual_time_s=self.virtual_time_s + delta)
        result = "success" if success else "no_target_in_range"
        self._trace.append(Trace(Action("clear", position, channel), result, movement, False, delta))
        return result

    def _advance(self, position: Point, channel: int, delta: float) -> None:
        self._state = PublicStateView(position, channel, self.virtual_time_s + delta)

    def _reserve(self, delta: float) -> None:
        if len(self._trace) >= self._max_actions:
            raise RuntimeError("action budget exhausted")
        if self._clock() - self._started_at > self._max_real_duration_s:
            raise RuntimeError("real-time budget exhausted")
        if self.virtual_time_s + delta > self._max_virtual_duration_s:
            raise RuntimeError("virtual-time budget exhausted")

    def _covered(self, target, point: Point) -> bool:
        if self._distance(point, target.position) > target.receive_radius:
            return False
        if target.kind == "omni":
            return True
        angle = math.degrees(math.atan2(point.y - target.position.y, point.x - target.position.x)) % 360
        difference = abs((angle - target.bearing_deg + 180) % 360 - 180)
        return difference <= 90

    @staticmethod
    def _distance(a: Point, b: Point) -> float:
        return math.hypot(a.x - b.x, a.y - b.y)

    @staticmethod
    def _validate(channel: int) -> None:
        if isinstance(channel, bool) or not isinstance(channel, int) or not 1 <= channel <= 20:
            raise ValueError("channel must be in 1..20")

    @staticmethod
    def _coerce_point(point: Point) -> Point:
        """Accept a typed public point or a strategy point with finite x/y."""
        if isinstance(point, Point):
            return point
        try:
            return Point(point.x, point.y)
        except (AttributeError, TypeError, ValueError) as exc:
            raise ValueError("position must expose valid finite x/y coordinates") from exc
