from __future__ import annotations

import hashlib
import math
import random

from .types import Case, Point, ScenarioSpec, Target


def build_case(spec: ScenarioSpec, targets: tuple[Target, ...] | None = None) -> Case:
    if not isinstance(spec, ScenarioSpec):
        raise ValueError("spec must be a ScenarioSpec")
    generated = tuple(targets) if targets is not None else _generate_targets(spec)
    digest_source = _digest_repr(spec, generated).encode("utf-8")
    return Case(spec, generated, hashlib.sha256(digest_source).hexdigest())


def _digest_repr(spec: ScenarioSpec, targets: tuple[Target, ...]) -> str:
    """Keep pre-extension frozen case IDs stable while binding explicit channel IDs."""
    if spec.channel_ids is None:
        spec_repr = (
            f"ScenarioSpec(question={spec.question!r}, target_count={spec.target_count!r}, "
            f"spatial={spec.spatial!r}, radius_mode={spec.radius_mode!r}, "
            f"error_mode={spec.error_mode!r}, orientation_mode={spec.orientation_mode!r}, "
            f"seed={spec.seed!r}, split={spec.split!r})"
        )
        return f"({spec_repr}, {targets!r})"
    return repr((spec, targets))


def _generate_targets(spec: ScenarioSpec) -> tuple[Target, ...]:
    rng = random.Random(spec.seed)
    result = []
    channels = spec.channel_ids or tuple(range(1, spec.target_count + 1))
    for index, channel in enumerate(channels):
        point = _point(spec.spatial, index, spec.target_count, rng)
        radius = {"r1000": 1000.0, "r1500": 1500.0, "mixed": 1000.0 if index % 2 == 0 else 1500.0}[spec.radius_mode]
        directional = spec.question == "Q4" and index % 2 == 0
        kind = "directional" if directional else "omni"
        bearing = None if kind == "omni" else _bearing(spec.orientation_mode, index, rng)
        result.append(Target(channel, point, radius, kind, bearing))
    return tuple(result)


def _point(family: str, index: int, count: int, rng: random.Random) -> Point:
    angle = 2 * math.pi * index / count
    if family == "boundary":
        # Keep floating point radial reconstruction safely inside the closed disk.
        radius = 1800.0 - 1e-9
    elif family == "cluster":
        radius = 80.0 + 20.0 * (index % 3)
    elif family == "separated":
        radius = 1500.0
    elif family == "grid_boundary":
        x = min(1800.0, max(-1800.0, -1800.0 + 3600.0 * index / max(count - 1, 1)))
        return Point(x, 0.0)
    else:  # uniform disk
        angle = rng.random() * 2 * math.pi
        radius = 1800.0 * math.sqrt(rng.random())
    return Point(radius * math.cos(angle), radius * math.sin(angle))


def _bearing(mode: str, index: int, rng: random.Random) -> float:
    if mode == "boundary":
        return 90.0 if index % 2 == 0 else 270.0
    if mode == "adversarial":
        return 180.0
    if mode == "random":
        return rng.random() * 360.0
    raise ValueError("directional targets need an explicit orientation mode")
