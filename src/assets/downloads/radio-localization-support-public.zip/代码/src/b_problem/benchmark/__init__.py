"""Pure offline hidden-truth benchmark for problem B."""
