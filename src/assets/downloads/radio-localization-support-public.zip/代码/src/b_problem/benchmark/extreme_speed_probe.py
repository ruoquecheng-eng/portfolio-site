"""Offline-only parameter probes; they never modify or invoke production strategies."""
from __future__ import annotations

from ..strategy import q3


def evenly_spaced_indices(population_size: int, sample_size: int) -> tuple[int, ...]:
    """Choose deterministic coverage across an immutable offline-suite ordering."""
    if not 1 <= sample_size <= population_size:
        raise ValueError("sample_size must be in 1..population_size")
    if sample_size == 1:
        return (0,)
    return tuple(round(index * (population_size - 1) / (sample_size - 1)) for index in range(sample_size))


def rank_q3_ring_variants(ring_radii_m: tuple[float, ...]) -> list[dict[str, float | bool]]:
    """Return certified Q3 survey variants ordered by their analytic survey cost."""
    ranked: list[dict[str, float | bool]] = []
    for ring_radius_m in ring_radii_m:
        plan = q3.build_center_ring_plan(ring_radius=ring_radius_m)
        coverage_proved = plan.coverage_certificate.worst_nearest_distance <= plan.coverage_certificate.receive_lower_bound
        if not coverage_proved:
            continue
        actions = q3.snake_scan_plan(plan)
        cost = q3.survey_cost(plan, actions)
        ranked.append({
            "ring_radius_m": ring_radius_m,
            "coverage_proved": coverage_proved,
            "survey_virtual_seconds": cost.virtual_seconds,
            "worst_nearest_distance_m": plan.coverage_certificate.worst_nearest_distance,
        })
    return sorted(ranked, key=lambda item: (float(item["survey_virtual_seconds"]), float(item["ring_radius_m"])))
