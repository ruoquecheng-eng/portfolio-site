from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from typing import Literal


MAX_POSITION_M = 2_000_000.0
_QUESTIONS = {"Q3", "Q4"}
_COUNTS = set(range(10, 17))
_SPATIAL = {"uniform", "boundary", "cluster", "separated", "grid_boundary"}
_RADIUS_MODES = {"r1000", "r1500", "mixed"}
_ERROR_MODES = {"zero", "plus1", "minus1", "fixed_hash"}
_Q4_ORIENTATIONS = {"random", "adversarial", "boundary"}


@dataclass(frozen=True)
class Point:
    x: float
    y: float

    def __post_init__(self) -> None:
        if not all(isinstance(value, (int, float)) and not isinstance(value, bool)
                   and math.isfinite(value) and abs(value) <= MAX_POSITION_M for value in (self.x, self.y)):
            raise ValueError("point coordinates must be finite and within 2,000,000 m")


@dataclass(frozen=True)
class Target:
    channel: int
    position: Point
    receive_radius: float
    kind: Literal["omni", "directional"]
    bearing_deg: float | None

    def __post_init__(self) -> None:
        if isinstance(self.channel, bool) or not isinstance(self.channel, int) or not 1 <= self.channel <= 20:
            raise ValueError("target channel must be an integer in 1..20")
        if not isinstance(self.position, Point):
            raise ValueError("target position must be a Point")
        if self.position.x * self.position.x + self.position.y * self.position.y > 1800.0 ** 2 + 1e-8:
            raise ValueError("target position must be inside the 1800 m target disk")
        if isinstance(self.receive_radius, bool) or not isinstance(self.receive_radius, (int, float)) or not math.isfinite(self.receive_radius) or not 1000.0 <= self.receive_radius <= 1500.0:
            raise ValueError("target receive radius must be finite and in [1000, 1500]")
        if self.kind not in {"omni", "directional"}:
            raise ValueError("target kind must be omni or directional")
        if self.kind == "omni" and self.bearing_deg is not None:
            raise ValueError("omnidirectional targets must not have a bearing")
        if self.kind == "directional":
            if isinstance(self.bearing_deg, bool) or not isinstance(self.bearing_deg, (int, float)) or not math.isfinite(self.bearing_deg) or not 0.0 <= self.bearing_deg < 360.0:
                raise ValueError("directional targets need a normalized finite bearing")


@dataclass(frozen=True)
class ScenarioSpec:
    question: Literal["Q3", "Q4"]
    target_count: int
    spatial: str
    radius_mode: str
    error_mode: str
    orientation_mode: str
    seed: int
    split: Literal["tuning", "holdout"] = "holdout"
    channel_ids: tuple[int, ...] | None = None

    def __post_init__(self) -> None:
        if self.question not in _QUESTIONS or self.target_count not in _COUNTS:
            raise ValueError("supported suites use Q3/Q4 and 10 through 16 targets")
        if self.spatial not in _SPATIAL or self.radius_mode not in _RADIUS_MODES or self.error_mode not in _ERROR_MODES:
            raise ValueError("unsupported scenario mode")
        if not isinstance(self.seed, int) or isinstance(self.seed, bool):
            raise ValueError("seed must be an integer")
        if self.split not in {"tuning", "holdout"}:
            raise ValueError("split must be tuning or holdout")
        if self.channel_ids is not None:
            if (not isinstance(self.channel_ids, tuple)
                    or len(self.channel_ids) != self.target_count
                    or any(isinstance(channel, bool) or not isinstance(channel, int)
                           or not 1 <= channel <= 20 for channel in self.channel_ids)
                    or len(set(self.channel_ids)) != len(self.channel_ids)):
                raise ValueError("channel_ids must be unique integer channels in 1..20 matching target_count")
        if self.question == "Q3" and self.orientation_mode != "none":
            raise ValueError("Q3 uses orientation_mode none")
        if self.question == "Q4" and self.orientation_mode not in _Q4_ORIENTATIONS:
            raise ValueError("Q4 needs an explicit directional orientation mode")


@dataclass(frozen=True)
class Action:
    kind: Literal["measure", "clear"]
    position: Point
    channel: int

    def __post_init__(self) -> None:
        if self.kind not in {"measure", "clear"} or not isinstance(self.position, Point):
            raise ValueError("invalid action")
        if isinstance(self.channel, bool) or not isinstance(self.channel, int) or not 1 <= self.channel <= 20:
            raise ValueError("action channel must be an integer in 1..20")


@dataclass(frozen=True)
class MeasurementObservation:
    result: Literal["no_signal", "near", "direction"]
    svd_deg: float | None

    def __post_init__(self) -> None:
        if self.result not in {"no_signal", "near", "direction"}:
            raise ValueError("invalid measurement result")
        if self.result == "direction":
            if isinstance(self.svd_deg, bool) or not isinstance(self.svd_deg, (int, float)) or not math.isfinite(self.svd_deg) or not 0.0 <= self.svd_deg < 360.0:
                raise ValueError("direction observation needs normalized svd_deg")
        elif self.svd_deg is not None:
            raise ValueError("non-direction observation must not have svd_deg")


@dataclass(frozen=True)
class Trace:
    action: Action
    result: MeasurementObservation | Literal["success", "no_target_in_range"]
    movement_m: float
    switched: bool
    delta_s: float

    def __post_init__(self) -> None:
        if not isinstance(self.action, Action) or isinstance(self.switched, bool) is False:
            raise ValueError("invalid trace")
        if self.action.kind == "measure" and not isinstance(self.result, MeasurementObservation):
            raise ValueError("measure trace needs a measurement observation")
        if self.action.kind == "clear" and self.result not in {"success", "no_target_in_range"}:
            raise ValueError("clear trace needs a clear result")
        if not all(isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0.0
                   for value in (self.movement_m, self.delta_s)):
            raise ValueError("trace movement and duration must be finite and non-negative")


@dataclass(frozen=True)
class PublicStateView:
    position: Point
    measure_channel: int
    virtual_time_s: float

    def __post_init__(self) -> None:
        if not isinstance(self.position, Point):
            raise ValueError("state position must be a Point")
        if isinstance(self.measure_channel, bool) or not isinstance(self.measure_channel, int) or not 1 <= self.measure_channel <= 20:
            raise ValueError("state channel must be an integer in 1..20")
        if isinstance(self.virtual_time_s, bool) or not isinstance(self.virtual_time_s, (int, float)) or not math.isfinite(self.virtual_time_s) or self.virtual_time_s < 0.0:
            raise ValueError("state virtual time must be finite and non-negative")


@dataclass(frozen=True)
class Metrics:
    clear_rate: float
    total_virtual_time_s: float
    mean_clear_time_s: float | None
    movement_distance_m: float
    measure_count: int
    switch_count: int
    clear_count: int
    failed_clear_count: int
    successful_clear_count: int


@dataclass(frozen=True)
class Case:
    spec: ScenarioSpec
    targets: tuple[Target, ...]
    truth_digest: str

    def __post_init__(self) -> None:
        if not isinstance(self.spec, ScenarioSpec) or len(self.targets) != self.spec.target_count:
            raise ValueError("case targets must match the declared target count")
        if not all(isinstance(target, Target) for target in self.targets):
            raise ValueError("case targets must be Target values")
        if len({target.channel for target in self.targets}) != len(self.targets):
            raise ValueError("case channels must be unique")
        if self.spec.channel_ids is not None and tuple(target.channel for target in self.targets) != self.spec.channel_ids:
            raise ValueError("case channels must preserve the declared channel_ids order")
        if self.spec.question == "Q3" and any(target.kind != "omni" for target in self.targets):
            raise ValueError("Q3 cases contain only omnidirectional targets")
        if self.spec.question == "Q4" and not any(target.kind == "directional" for target in self.targets):
            raise ValueError("Q4 cases need at least one directional target")
        radii = {target.receive_radius for target in self.targets}
        if self.spec.radius_mode == "r1000" and radii != {1000.0}:
            raise ValueError("r1000 cases require only 1000 m targets")
        if self.spec.radius_mode == "r1500" and radii != {1500.0}:
            raise ValueError("r1500 cases require only 1500 m targets")
        if self.spec.radius_mode == "mixed" and not radii <= {1000.0, 1500.0}:
            raise ValueError("mixed cases require 1000 m or 1500 m targets")

    def error_deg(self, channel: int, point: Point) -> float:
        mode = self.spec.error_mode
        if mode == "zero":
            return 0.0
        if mode == "plus1":
            return 1.0
        if mode == "minus1":
            return -1.0
        key = f"{self.spec.seed}:{channel}:{point.x:.9f}:{point.y:.9f}".encode()
        return (int.from_bytes(hashlib.sha256(key).digest()[:8], "big") / 2**64) * 2 - 1

    @property
    def manifest(self) -> dict:
        return {"spec": self.spec.__dict__, "truth_digest": self.truth_digest}
