"""Deterministic geometry ranking for one shared second-bearing location ``B``.

This is intentionally a small 2-D proxy, not a Fisher-information model.  A
candidate ``B`` is useful for anchor ``A`` when the displacement ``B-A`` has a
large component perpendicular to A's first bearing.  The score uses
``|sin(delta)|`` and its metre lever ``|B-A| |sin(delta)|``; both are zero for
a parallel second observation and improve before any target-dependent second
bearing is available.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import atan2, cos, degrees, hypot, radians, sin
from typing import Iterable


_OFFSETS_DEG = (-90.0, -60.0, -45.0, 45.0, 60.0, 90.0)


@dataclass(frozen=True, order=True)
class BatchAnchor:
    channel: int
    bearing_deg: float
    x: float
    y: float


@dataclass(frozen=True)
class BearingCluster:
    anchors: tuple[BatchAnchor, ...]
    mean_bearing_deg: float
    mean_x: float
    mean_y: float


@dataclass(frozen=True)
class CandidateBScore:
    x: float
    y: float
    heading_deg: float
    nominal_distance_m: float
    cluster_channels: tuple[int, ...]
    served_channels: tuple[int, ...]
    nonparallel_pair_count: int
    minimum_cross_range_sine: float
    mean_cross_range_sine: float
    minimum_cross_range_lever_m: float
    mean_cross_range_lever_m: float


def _normalize(angle_deg: float) -> float:
    return angle_deg % 360.0


def _circular_gap(first_deg: float, second_deg: float) -> float:
    return abs((second_deg - first_deg + 180.0) % 360.0 - 180.0)


def _circular_mean(anchors: Iterable[BatchAnchor]) -> float:
    values = tuple(anchors)
    if not values:
        raise ValueError("a circular mean needs at least one anchor")
    sine = sum(sin(radians(anchor.bearing_deg)) for anchor in values)
    cosine = sum(cos(radians(anchor.bearing_deg)) for anchor in values)
    return _normalize(degrees(atan2(sine, cosine)))


def cluster_circular_bearings(anchors: Iterable[BatchAnchor], *, max_gap_deg: float = 20.0) -> tuple[BearingCluster, ...]:
    """Cluster circular bearings, explicitly merging the 360°/0° boundary."""
    if not 0.0 < max_gap_deg < 180.0:
        raise ValueError("max_gap_deg must be in (0, 180)")
    ordered = sorted(tuple(anchors), key=lambda anchor: (_normalize(anchor.bearing_deg), anchor.channel, anchor.x, anchor.y))
    if not ordered:
        return ()
    groups: list[list[BatchAnchor]] = [[ordered[0]]]
    for previous, anchor in zip(ordered, ordered[1:]):
        if _circular_gap(previous.bearing_deg, anchor.bearing_deg) <= max_gap_deg:
            groups[-1].append(anchor)
        else:
            groups.append([anchor])
    if len(groups) > 1 and _circular_gap(ordered[-1].bearing_deg, ordered[0].bearing_deg) <= max_gap_deg:
        groups[0] = groups[-1] + groups[0]
        groups.pop()
    clusters = []
    for group in groups:
        members = tuple(sorted(group, key=lambda anchor: (anchor.channel, anchor.x, anchor.y, anchor.bearing_deg)))
        clusters.append(BearingCluster(
            members, _circular_mean(members),
            sum(anchor.x for anchor in members) / len(members),
            sum(anchor.y for anchor in members) / len(members),
        ))
    return tuple(sorted(clusters, key=lambda cluster: tuple(anchor.channel for anchor in cluster.anchors)))


def second_bearing_condition_proxy(anchor: BatchAnchor, *, x: float, y: float) -> tuple[float, float]:
    """Return (angular separation sine, cross-range lever metres) for ``A→B``."""
    dx, dy = x - anchor.x, y - anchor.y
    baseline = hypot(dx, dy)
    if baseline <= 1e-9:
        return 0.0, 0.0
    heading = degrees(atan2(dy, dx))
    separation_sine = abs(sin(radians(_circular_gap(anchor.bearing_deg, heading))))
    return separation_sine, baseline * separation_sine


def forward_ray_intersection(
    anchor: BatchAnchor, *, second_x: float, second_y: float, second_bearing_deg: float
) -> tuple[float, float] | None:
    """Intersect two forward bearing rays, rejecting parallel or backward crossings.

    This is only a light, target-independent 2-D geometry helper for a future
    caller that has obtained the second bearing; it performs no optimisation.
    """
    first_x, first_y = cos(radians(anchor.bearing_deg)), sin(radians(anchor.bearing_deg))
    second_x_dir, second_y_dir = cos(radians(second_bearing_deg)), sin(radians(second_bearing_deg))
    determinant = first_x * second_y_dir - first_y * second_x_dir
    if abs(determinant) <= 1e-9:
        return None
    delta_x, delta_y = second_x - anchor.x, second_y - anchor.y
    first_distance = (delta_x * second_y_dir - delta_y * second_x_dir) / determinant
    second_distance = (delta_x * first_y - delta_y * first_x) / determinant
    if first_distance < -1e-9 or second_distance < -1e-9:
        return None
    return anchor.x + first_distance * first_x, anchor.y + first_distance * first_y


def _nonparallel_pair_count(anchors: tuple[BatchAnchor, ...], threshold_deg: float) -> int:
    return sum(
        _circular_gap(first.bearing_deg, second.bearing_deg) >= threshold_deg
        for index, first in enumerate(anchors)
        for second in anchors[index + 1:]
    )


def _score_candidate(
    cluster: BearingCluster,
    anchors: tuple[BatchAnchor, ...],
    *,
    heading_deg: float,
    distance_m: float,
    minimum_cross_range_sine: float,
    nonparallel_deg: float,
) -> CandidateBScore:
    x = cluster.mean_x + distance_m * cos(radians(heading_deg))
    y = cluster.mean_y + distance_m * sin(radians(heading_deg))
    served: list[BatchAnchor] = []
    sines: list[float] = []
    levers: list[float] = []
    for anchor in anchors:
        separation_sine, lever = second_bearing_condition_proxy(anchor, x=x, y=y)
        if separation_sine >= minimum_cross_range_sine:
            served.append(anchor)
            sines.append(separation_sine)
            levers.append(lever)
    return CandidateBScore(
        x, y, _normalize(heading_deg), distance_m,
        tuple(anchor.channel for anchor in cluster.anchors), tuple(anchor.channel for anchor in served),
        _nonparallel_pair_count(tuple(served), nonparallel_deg),
        min(sines, default=0.0), sum(sines) / len(sines) if sines else 0.0,
        min(levers, default=0.0), sum(levers) / len(levers) if levers else 0.0,
    )


def score_batch_candidates(
    anchors: Iterable[BatchAnchor],
    *,
    route_directions_deg: Iterable[float] = (),
    distances_m: Iterable[float] = (100.0, 200.0, 300.0, 400.0, 500.0),
    max_gap_deg: float = 20.0,
    minimum_cross_range_sine: float = 0.25,
    nonparallel_deg: float = 5.0,
) -> tuple[CandidateBScore, ...]:
    """Score only the requested cross-range and route-aligned B candidates."""
    anchor_tuple = tuple(sorted(anchors, key=lambda anchor: (anchor.channel, anchor.x, anchor.y, anchor.bearing_deg)))
    if not anchor_tuple:
        return ()
    distances = tuple(float(distance) for distance in distances_m)
    if not distances or any(distance < 100.0 or distance > 500.0 for distance in distances):
        raise ValueError("B distances must stay in the requested [100, 500] m range")
    if not 0.0 < minimum_cross_range_sine <= 1.0 or not 0.0 < nonparallel_deg < 180.0:
        raise ValueError("invalid geometry thresholds")
    route_headings = tuple(_normalize(float(heading)) for heading in route_directions_deg)
    candidates: list[CandidateBScore] = []
    for cluster in cluster_circular_bearings(anchor_tuple, max_gap_deg=max_gap_deg):
        headings = {_normalize(cluster.mean_bearing_deg + offset) for offset in _OFFSETS_DEG}
        headings.update(route_headings)
        for heading in sorted(headings):
            for distance in sorted(set(distances)):
                candidates.append(_score_candidate(
                    cluster, anchor_tuple, heading_deg=heading, distance_m=distance,
                    minimum_cross_range_sine=minimum_cross_range_sine, nonparallel_deg=nonparallel_deg,
                ))
    return tuple(candidates)


def best_shared_second_bearing(anchors: Iterable[BatchAnchor], **kwargs: object) -> CandidateBScore:
    """Select the deterministic best B, prioritising shared nonparallel service."""
    candidates = score_batch_candidates(anchors, **kwargs)
    if not candidates:
        raise ValueError("at least one anchor is required")
    return max(
        candidates,
        key=lambda candidate: (
            len(candidate.served_channels), candidate.nonparallel_pair_count,
            candidate.minimum_cross_range_lever_m, candidate.mean_cross_range_lever_m,
            candidate.minimum_cross_range_sine, candidate.mean_cross_range_sine,
            -candidate.nominal_distance_m, -candidate.heading_deg, -candidate.x, -candidate.y,
        ),
    )
