"""Standalone geometry helpers for batched observations; not strategy code."""
