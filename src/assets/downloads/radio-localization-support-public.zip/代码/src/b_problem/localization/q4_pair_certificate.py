"""Truth-independent in-range predicates for Q4 paired-probe research."""
from __future__ import annotations
from dataclasses import dataclass, field
from .robust import Point

@dataclass(frozen=True)
class InRangeCertificate:
    passed:bool; method:str; margin:float


@dataclass
class PairBinding:
    """Identity-bound pair probes for an interruptible Q4 controller.

    This object is deliberately stateful: a response can be consumed once only
    by the exact generated pair, channel and designed coordinate.  It records
    evidence; it does not itself authorise a directional-shadow cut.
    """
    generation:int
    channel:int
    snapshot_version:int
    probes:tuple[Point,Point]
    vertices:tuple[Point,...]
    consumed_actions:set[str]=field(default_factory=set)
    consumed_probe_indices:set[int]=field(default_factory=set)


@dataclass(frozen=True)
class BoundPairObservation:
    accepted:bool
    reason:str
    generation:int
    probe_index:int|None=None


@dataclass(frozen=True)
class PairEvidence:
    first:BoundPairObservation
    second:BoundPairObservation

    @property
    def complete(self)->bool:
        return (self.first.accepted and self.second.accepted and
                self.first.generation == self.second.generation and
                self.first.probe_index != self.second.probe_index)


def bind_pair_observation(binding:PairBinding, channel:int, point:Point, result:str, *, action_id:str,
                          tolerance_m:float=1e-6)->BoundPairObservation:
    """Accept only one exact, designed ``no_signal`` response for a pair probe."""
    if channel != binding.channel:
        return BoundPairObservation(False,"channel_mismatch",binding.generation)
    if result != "no_signal":
        return BoundPairObservation(False,"result_not_no_signal",binding.generation)
    if action_id in binding.consumed_actions:
        return BoundPairObservation(False,"duplicate_action",binding.generation)
    matches=[index for index,probe in enumerate(binding.probes) if point.distance_to(probe)<=tolerance_m]
    if len(matches) != 1:
        return BoundPairObservation(False,"coordinate_mismatch",binding.generation)
    index=matches[0]
    if index in binding.consumed_probe_indices:
        return BoundPairObservation(False,"duplicate_probe",binding.generation,index)
    binding.consumed_actions.add(action_id)
    binding.consumed_probe_indices.add(index)
    return BoundPairObservation(True,"bound",binding.generation,index)

def certify_min_radius(q:Point,vertices:tuple[Point,...],*,radius:float=1000.,margin:float=.1)->InRangeCertificate:
    maximum=max(q.distance_to(v) for v in vertices)
    return InRangeCertificate(maximum<radius-margin,"minimum_receive_radius",radius-margin-maximum)

def certify_positive_dominance(q:Point,p:Point,vertices:tuple[Point,...],*,margin_sq:float=.001)->InRangeCertificate:
    values=((q.x*q.x+q.y*q.y-p.x*p.x-p.y*p.y)-2*(q.x-p.x)*g.x-2*(q.y-p.y)*g.y for g in vertices)
    maximum=max(values)
    return InRangeCertificate(maximum < -margin_sq,"positive_distance_dominance",-margin_sq-maximum)
