"""Conservative Q2 geometry that does not depend on the shared Q1 module.

The reported bearing has a bounded angular error.  This module keeps that
error as a closed angular wedge and treats the ``direction`` distance bound
as open.  Its reception certificate is deliberately conservative: it proves
membership in a universal safe subset that covers the whole 1500 m wedge;
it does not claim to solve the exact instance-specific robust domain.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import atan2, cos, degrees, hypot, pi, radians, sin
from typing import Iterable


DEFAULT_ERROR_DEG = 1.0
MIN_RECEIVE_RADIUS = 1000.0
MAX_RECEIVE_RADIUS = 1500.0
NEAR_DISTANCE = 5.0
ROBOT_SPEED_MPS = 5.0
NUMERIC_TOLERANCE = 1e-9


@dataclass(frozen=True)
class Point:
    """A two-dimensional Cartesian point in metres."""

    x: float
    y: float

    def distance_to(self, other: "Point") -> float:
        return hypot(self.x - other.x, self.y - other.y)

    def bearing_to(self, other: "Point") -> float:
        """Return the east-zero, counter-clockwise bearing in degrees."""
        return degrees(atan2(other.y - self.y, other.x - self.x)) % 360.0


def _signed_angle_deg(angle_deg: float) -> float:
    return (angle_deg + 180.0) % 360.0 - 180.0


@dataclass(frozen=True)
class FirstFeasibleRegion:
    """Closed geometric envelope and open ``direction`` subset after scan one."""

    station: Point
    bearing_deg: float
    target_radius: float = 1800.0
    error_deg: float = DEFAULT_ERROR_DEG
    max_receive_radius: float = MAX_RECEIVE_RADIUS
    direction_open_distance: float = NEAR_DISTANCE

    def __post_init__(self) -> None:
        if self.target_radius <= 0.0:
            raise ValueError("target_radius must be positive")
        if not 0.0 < self.error_deg < 90.0:
            raise ValueError("error_deg must be in (0, 90)")
        if self.max_receive_radius <= 0.0:
            raise ValueError("max_receive_radius must be positive")
        if self.direction_open_distance < 0.0:
            raise ValueError("direction_open_distance must be non-negative")

    def contains_closure(self, source: Point) -> bool:
        """Test the closed wedge/disk envelope used for stable numerics.

        The apex is retained as a closure point although a physical
        ``direction`` response cannot occur at distance zero.
        """
        distance = self.station.distance_to(source)
        if hypot(source.x, source.y) > self.target_radius + NUMERIC_TOLERANCE:
            return False
        if distance > self.max_receive_radius + NUMERIC_TOLERANCE:
            return False
        if distance <= NUMERIC_TOLERANCE:
            return True
        bearing_error = abs(_signed_angle_deg(self.station.bearing_to(source) - self.bearing_deg))
        return bearing_error <= self.error_deg + NUMERIC_TOLERANCE

    def contains_direction(self, source: Point) -> bool:
        """Test the physical result branch, with the 5 m threshold open.

        Values at the threshold are treated as ``near``.  A tolerance is kept
        on the conservative side, so a numerically ambiguous point is not
        promoted to a ``direction`` observation.
        """
        return self.contains_closure(source) and (
            self.station.distance_to(source) > self.direction_open_distance + NUMERIC_TOLERANCE
        )

    def minimum_consistent_radius(self, source: Point) -> float:
        """Smallest source radius consistent with the first successful scan."""
        if not self.contains_closure(source):
            raise ValueError("source is outside the first feasible closure")
        return max(MIN_RECEIVE_RADIUS, self.station.distance_to(source))


@dataclass(frozen=True)
class ReceptionCertificate:
    """A proof status for a second-station reception candidate."""

    candidate: Point
    side: int | None
    is_member: bool
    status: str
    worst_projection_m: float
    reason: str


def _minimum_wedge_projection(region: FirstFeasibleRegion, candidate: Point) -> float:
    """Compute min q·u(theta) over the entire first-bearing error wedge."""
    qx = candidate.x - region.station.x
    qy = candidate.y - region.station.y
    length = hypot(qx, qy)
    if length <= NUMERIC_TOLERANCE:
        return 0.0

    direction = atan2(qy, qx)
    centre = radians(region.bearing_deg)
    half_width = radians(region.error_deg)
    lo, hi = centre - half_width, centre + half_width
    angles = [lo, hi]
    # Dot products have extrema where theta equals q's direction or its
    # opposite.  Include all wrapped copies that can lie in this interval.
    for base in (direction, direction + pi):
        for turns in range(-2, 3):
            theta = base + 2.0 * pi * turns
            if lo <= theta <= hi:
                angles.append(theta)
    return min(qx * cos(theta) + qy * sin(theta) for theta in angles)


def universal_reception_certificate(
    region: FirstFeasibleRegion, candidate: Point, *, side: int | None = None
) -> ReceptionCertificate:
    """Certify a conservative, source-independent second-station safe subset.

    Let q be the candidate displacement from scan one.  Requiring

        ||q|| <= 1000,
        ||q||² <= 2000 min_{|theta-bearing|<=delta} q·u(theta)

    is equivalent to reception for every source in the full 0--1500 m first
    wedge, using its smallest radius consistent with scan one.  Since the
    actual first feasible set is a subset of that wedge, a successful result
    is a proof for the actual instance.  A failed result is intentionally
    ``UNRESOLVED`` rather than a proof of unsafety for the smaller exact set.
    """
    displacement = region.station.distance_to(candidate)
    minimum_projection = _minimum_wedge_projection(region, candidate)
    member = (
        displacement <= MIN_RECEIVE_RADIUS + NUMERIC_TOLERANCE
        and displacement * displacement
        <= 2.0 * MIN_RECEIVE_RADIUS * minimum_projection + NUMERIC_TOLERANCE
    )
    if member:
        reason = "Universal wedge certificate proves second-station reception."
        status = "PROVED"
    else:
        reason = "Not certified by the universal wedge subset; exact-domain checking is still possible."
        status = "UNRESOLVED"
    return ReceptionCertificate(
        candidate=candidate,
        side=side,
        is_member=member,
        status=status,
        worst_projection_m=minimum_projection,
        reason=reason,
    )


def safe_seed_certificates(region: FirstFeasibleRegion) -> tuple[ReceptionCertificate, ReceptionCertificate]:
    """Return the two proved 1000 m, ±(60°−delta) robust reception seeds."""
    beta_deg = 60.0 - region.error_deg
    if beta_deg <= 0.0:
        raise ValueError("error_deg must remain below 60 degrees for this seed construction")
    certificates: list[ReceptionCertificate] = []
    for side in (-1, 1):
        angle = radians(region.bearing_deg + side * beta_deg)
        candidate = Point(
            region.station.x + MIN_RECEIVE_RADIUS * cos(angle),
            region.station.y + MIN_RECEIVE_RADIUS * sin(angle),
        )
        certificates.append(universal_reception_certificate(region, candidate, side=side))
    return (certificates[0], certificates[1])


class DirectionResult(str, Enum):
    DIRECTION = "direction"
    NEAR = "near"


@dataclass(frozen=True)
class PosteriorScenario:
    """Externally computed posterior bounds for one possible second outcome."""

    result: DirectionResult
    mec_radius: float = 0.0
    diameter: float = 0.0

    @classmethod
    def direction(cls, *, mec_radius: float, diameter: float) -> "PosteriorScenario":
        if mec_radius < 0.0 or diameter < 0.0:
            raise ValueError("posterior metrics must be non-negative")
        return cls(DirectionResult.DIRECTION, mec_radius, diameter)

    @classmethod
    def near(cls) -> "PosteriorScenario":
        return cls(DirectionResult.NEAR, 0.0, 0.0)


@dataclass(frozen=True)
class CandidateEvaluation:
    """A lexicographic comparison result, not a global-optimality claim."""

    candidate: Point
    worst_mec_radius: float
    worst_diameter: float
    travel_time_s: float
    branch: DirectionResult
    optimization_status: str = "HEURISTIC"

    @property
    def ranking_key(self) -> tuple[float, float, float]:
        return (self.worst_mec_radius, self.worst_diameter, self.travel_time_s)


def evaluate_candidate(
    first_station: Point, candidate: Point, scenarios: Iterable[PosteriorScenario]
) -> CandidateEvaluation:
    """Rank supplied posterior scenarios by MEC radius, diameter, then travel.

    The geometric posterior/MEC computation belongs to the Q1 geometry module
    once that shared API is stable.  This function deliberately accepts its
    bounds as data so this module does not duplicate or modify Q1 geometry.
    """
    values = tuple(scenarios)
    if not values:
        raise ValueError("at least one possible second-station scenario is required")
    worst_mec = max(scenario.mec_radius for scenario in values)
    worst_diameter = max(scenario.diameter for scenario in values)
    branch = DirectionResult.NEAR if all(s.result is DirectionResult.NEAR for s in values) else DirectionResult.DIRECTION
    return CandidateEvaluation(
        candidate=candidate,
        worst_mec_radius=worst_mec,
        worst_diameter=worst_diameter,
        travel_time_s=first_station.distance_to(candidate) / ROBOT_SPEED_MPS,
        branch=branch,
    )


def evaluate_certified_candidate(
    first_station: Point,
    candidate: Point,
    posterior_regions: Iterable[object],
    *,
    sides: int = 256,
):
    """Evaluate direction posteriors using certified geometry upper bounds.

    Lower-dimensional or numerically unresolved regions are rejected instead
    of being assigned optimistic localization metrics.
    """
    from b_problem.geometry import MetricCertificationStatus, certify_curvilinear_metrics

    certificates = tuple(
        certify_curvilinear_metrics(region, sides=sides) for region in posterior_regions
    )
    if any(certificate.status is not MetricCertificationStatus.PROVED for certificate in certificates):
        raise ValueError("every posterior region must have a full-dimensional metric certification")
    scenarios = tuple(
        PosteriorScenario.direction(
            mec_radius=certificate.mec_radius.upper,
            diameter=certificate.diameter.upper,
        )
        for certificate in certificates
    )
    return evaluate_candidate(first_station, candidate, scenarios), certificates
