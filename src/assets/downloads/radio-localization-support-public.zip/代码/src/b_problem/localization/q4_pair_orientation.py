"""Exact 2-D orientation feasibility for bound Q4 paired negatives.

Only the inclusive directional half-plane is modeled here.  Distance is an
independent prerequisite supplied by the paired-probe in-range certificate.
"""
from __future__ import annotations
from math import atan2, pi
from .robust import Point

_EPS=1e-10

def _dot(a:Point,b:Point)->float:return a.x*b.x+a.y*b.y
def _vector(g:Point,p:Point)->Point:return Point(p.x-g.x,p.y-g.y)

def orientation_feasible(g:Point,positive:Point,negative_b:Point,negative_c:Point)->bool:
    """Whether an axis exists with P in its closed 180° lobe and B/C out.

    Boundaries are checked explicitly: P may sit on a lobe boundary, while a
    no-signal point cannot because the official receiver half-plane is closed.
    """
    vectors=(_vector(g,positive),_vector(g,negative_b),_vector(g,negative_c))
    if any(abs(v.x)+abs(v.y)<=_EPS for v in vectors):return False
    boundaries=[]
    for v in vectors:
        theta=atan2(v.y,v.x)
        boundaries.extend((theta-pi/2,theta+pi/2))
    values=[]
    ordered=sorted((value%(2*pi) for value in boundaries))
    values.extend(ordered)
    for i in range(len(ordered)):
        midpoint=(ordered[i]+((ordered[(i+1)%len(ordered)]-ordered[i])%(2*pi))/2)%(2*pi)
        values.append(midpoint)
    for angle in values:
        axis=Point(__import__('math').cos(angle),__import__('math').sin(angle))
        if _dot(axis,vectors[0])>=-_EPS and _dot(axis,vectors[1])<-_EPS and _dot(axis,vectors[2])<-_EPS:return True
    return False

def proposed_cut_excludes(g:Point,positive:Point,negative_b:Point,negative_c:Point)->bool:
    """Fail-closed production proposal: no positional exclusion until proof."""
    _=(g,positive,negative_b,negative_c)
    return False
