"""Diagnostic all-positive-bearing geometry for Q4 SMAR experiments.

This module deliberately separates a numeric fit from the conservative
measurement set.  ``all_positive_bearing_fit`` is a heuristic diagnostic only;
it never certifies a clear candidate.  ``point_satisfies_bearing_set`` checks
the public +/- angular-error wedges and receive-range bounds independently.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import atan2, cos, degrees, hypot, radians, sin
from typing import Iterable

from b_problem.strategy.q4 import Point


ANGLE_TOLERANCE_DEG = 1.0
RANK_EPSILON = 1e-9


@dataclass(frozen=True)
class BearingObservation:
    position: Point
    bearing_deg: float


@dataclass(frozen=True)
class AllBearingFit:
    estimate: Point | None
    observation_count: int
    condition_number: float | None
    max_perpendicular_residual_m: float | None
    degenerate: bool
    reason: str


def _unit(bearing_deg: float) -> tuple[float, float]:
    angle = radians(bearing_deg)
    return cos(angle), sin(angle)


def _wrapped_delta_deg(first: float, second: float) -> float:
    return (first - second + 180.0) % 360.0 - 180.0


def all_positive_bearing_fit(observations: Iterable[BearingObservation]) -> AllBearingFit:
    """Fit every positive bearing ray with 2-D perpendicular least squares.

    The normal matrix is also the geometry diagnostic: a nearly zero small
    eigenvalue represents collinear/parallel rays and produces no estimate.
    """
    rows = tuple(observations)
    if len(rows) < 2:
        return AllBearingFit(None, len(rows), None, None, True, "insufficient_observations")
    a00 = a01 = a11 = b0 = b1 = 0.0
    normals: list[tuple[float, float, float]] = []
    for observation in rows:
        dx, dy = _unit(observation.bearing_deg)
        nx, ny = -dy, dx
        rhs = nx * observation.position.x + ny * observation.position.y
        normals.append((nx, ny, rhs))
        a00 += nx * nx
        a01 += nx * ny
        a11 += ny * ny
        b0 += nx * rhs
        b1 += ny * rhs
    trace = a00 + a11
    discriminant = max(0.0, (a00 - a11) ** 2 + 4.0 * a01 * a01)
    root = discriminant ** 0.5
    largest, smallest = (trace + root) / 2.0, (trace - root) / 2.0
    if smallest <= RANK_EPSILON * max(1.0, largest):
        return AllBearingFit(None, len(rows), None, None, True, "rank_deficient")
    determinant = a00 * a11 - a01 * a01
    estimate = Point((a11 * b0 - a01 * b1) / determinant, (a00 * b1 - a01 * b0) / determinant)
    residuals = [abs(nx * estimate.x + ny * estimate.y - rhs) for nx, ny, rhs in normals]
    return AllBearingFit(
        estimate, len(rows), largest / smallest, max(residuals, default=0.0), False, "well_conditioned"
    )


def point_satisfies_bearing_set(
    point: Point,
    observations: Iterable[BearingObservation],
    *,
    max_range_m: float,
    angle_tolerance_deg: float = ANGLE_TOLERANCE_DEG,
) -> bool:
    """Conservative public feasibility check; intentionally unrelated to LS fit."""
    for observation in observations:
        dx, dy = point.x - observation.position.x, point.y - observation.position.y
        if hypot(dx, dy) > max_range_m + 1e-9:
            return False
        if hypot(dx, dy) <= 1e-12:
            continue
        bearing = degrees(atan2(dy, dx)) % 360.0
        if abs(_wrapped_delta_deg(bearing, observation.bearing_deg)) > angle_tolerance_deg + 1e-12:
            return False
    return True
