"""Q4 SandboxExact FULL / PAIR_BOUND rehearsal runner only."""
from __future__ import annotations
import argparse, json, sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from b_problem.experimental.sandbox_exact_port import execute_q4_sandbox_exact_official
from b_problem.simulator.config import PRACTICE_READY_TOKEN,SimulatorConfig,SimulatorMode
from b_problem.simulator.session import run_validated_session
def port(v:str)->int:
 p=urlparse(v)
 if p.scheme!='http' or p.hostname!='127.0.0.1' or p.path not in {'','/'} or p.port is None: raise argparse.ArgumentTypeError('base URL must be http://127.0.0.1:<port>')
 return p.port
def main():
 a=argparse.ArgumentParser();a.add_argument('--robot-id',required=True);a.add_argument('--base-url',type=port,default=2026);a.add_argument('--confirm-q4-rehearsal',action='store_true');a.add_argument('--run-index',type=int,choices=(1,2,3),default=1);x=a.parse_args()
 print('THIS RUNNER IS FOR Q4 REHEARSAL ONLY');print('STRATEGY = Q4_SANDBOX_EXACT_FULL');print('PAIR = BOUND');print('ROUTING = ROUTINGPLUS');print('NO REQUEST HAS BEEN SENT')
 if not x.confirm_q4_rehearsal:a.error('--confirm-q4-rehearsal is required before /enter')
 c=SimulatorConfig(mode=SimulatorMode.PRACTICE_Q4,robot_id=x.robot_id,port=x.base_url,ready_signal=PRACTICE_READY_TOKEN);d=ROOT/'outputs'/'q4_rehearsal_20260912';stamp=datetime.now().strftime('%Y%m%dT%H%M%S');log=d/f'q4_rehearsal_{x.run_index:02d}_{stamp}.jsonl';summary=d/f'q4_rehearsal_{x.run_index:02d}_{stamp}.json'
 r=run_validated_session(c,log_path=log,summary_path=summary,q4_strategy=lambda robot,_:execute_q4_sandbox_exact_official(robot));print(json.dumps(asdict(r),ensure_ascii=False));print(f'log_path = {log}');print(f'summary_path = {summary}')
if __name__=='__main__':main()
