"""Read-only privacy gate for the code submission directory."""
from __future__ import annotations
import argparse, re
from pathlib import Path

TEXT={".py",".json",".yaml",".yml",".toml",".ini",".cfg",".md",".txt",".bat",".cmd",".ps1",".sh",".ipynb"}
PATTERNS={"quoted 12-digit identifier":re.compile(r"[\"']\d{12}[\"']"),"robot identifier assignment":re.compile(r"robot[_-]?id\s*[=:].{0,8}\d",re.I),"Windows absolute path":re.compile(r"[A-Za-z]:\\(?:Users|WSN)\\"),"plaintext rehearsal log":re.compile(r"(?:rehearsal|practice).*\.(?:jsonl|log)$",re.I)}
def main():
 p=argparse.ArgumentParser();p.add_argument("directory",nargs="?",default=".");a=p.parse_args();root=Path(a.directory);issues=[]
 for f in root.rglob("*"):
  if not f.is_file():continue
  if f.suffix.lower()==".jlog":continue
  if f.name==".env" or f.suffix.lower()==".jsonl":issues.append((f,"forbidden runtime/log artifact"));continue
  if f.suffix.lower() not in TEXT:continue
  text=f.read_text(encoding="utf-8",errors="replace")
  for label,rx in PATTERNS.items():
   if rx.search(text):issues.append((f,label))
 if issues:
  for f,reason in issues:print(f"FAIL {f}: {reason}")
  raise SystemExit(1)
 print("PASS")
if __name__=="__main__":main()
