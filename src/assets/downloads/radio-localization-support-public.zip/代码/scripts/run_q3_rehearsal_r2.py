"""Run Q3_BREAKTHROUGH_R2 only after an explicit human rehearsal confirmation."""
from __future__ import annotations

import argparse
from dataclasses import asdict
from datetime import datetime
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from b_problem.experimental.q3_breakthrough_port import execute_q3_breakthrough_official
from b_problem.simulator.config import PRACTICE_READY_TOKEN, SimulatorConfig, SimulatorMode
from b_problem.simulator.session import run_validated_session

ALGORITHM = "Q3_BREAKTHROUGH_R2"


def _port(value: str) -> int:
    parsed = urlparse(value)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.path not in {"", "/"} or parsed.query or parsed.fragment or parsed.port is None:
        raise argparse.ArgumentTypeError("base URL must be exactly http://127.0.0.1:<port>")
    return parsed.port


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--robot-id", required=True)
    parser.add_argument("--base-url", type=_port, default=2026, help="loopback simulator URL")
    parser.add_argument("--confirm-q3-rehearsal", action="store_true")
    parser.add_argument("--run-index", type=int, choices=(1, 2, 3), default=1)
    args = parser.parse_args()
    sha = subprocess.check_output(["powershell", "-NoProfile", "-File", str(ROOT / "scripts" / "cumcm-git.ps1"), "rev-parse", "HEAD"], text=True).strip()
    print("THIS RUNNER IS FOR Q3 REHEARSAL ONLY")
    print(f"STRATEGY = {ALGORITHM}")
    print(f"git_sha = {sha}")
    print("NO REQUEST HAS BEEN SENT")
    if not args.confirm_q3_rehearsal:
        parser.error("--confirm-q3-rehearsal is required before /enter")
    config = SimulatorConfig(mode=SimulatorMode.PRACTICE_Q3, robot_id=args.robot_id, port=args.base_url, ready_signal=PRACTICE_READY_TOKEN)
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    out = ROOT / "outputs" / "q3_rehearsal_20260912"
    log = out / f"q3_rehearsal_{args.run_index:02d}_{stamp}.jsonl"
    summary = out / f"q3_rehearsal_{args.run_index:02d}_{stamp}.json"
    result = run_validated_session(config, log_path=log, summary_path=summary,
        q3_strategy=lambda robot, _: execute_q3_breakthrough_official(robot))
    print(json.dumps(asdict(result), ensure_ascii=False, default=str))
    print(f"log_path = {log}")
    print(f"summary_path = {summary}")


if __name__ == "__main__": main()
