import math, itertools, json
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
from shapely.geometry import Polygon, Point
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

# use CJK font if available
for fam in ['Noto Sans CJK SC','AR PL UMing CN','DejaVu Sans']:
    try:
        path=font_manager.findfont(fam, fallback_to_default=False)
        plt.rcParams['font.family']=fam
        break
    except Exception:
        pass
plt.rcParams['axes.unicode_minus']=False

ROOT=Path(__file__).resolve().parent; FIG=ROOT/'figures'; QA=ROOT/'qa'
FIG.mkdir(parents=True,exist_ok=True); QA.mkdir(parents=True,exist_ok=True)

def unit(t): return np.array([math.cos(t),math.sin(t)])
def wedge_polygon(S,theta,delta,L=5000):
    S=np.array(S,float); a=S+L*unit(theta-delta); b=S+L*unit(theta+delta)
    return Polygon([tuple(S),tuple(a),tuple(b)])
def sector_polygon(rmin=5,rmax=1500,delta=math.radians(1),n=240):
    outer=[(rmax*math.cos(a),rmax*math.sin(a)) for a in np.linspace(-delta,delta,n//2)]
    inner=[(rmin*math.cos(a),rmin*math.sin(a)) for a in np.linspace(delta,-delta,n//2)]
    return Polygon(outer+inner)
def poly_pts(g):
    if g.is_empty: return np.empty((0,2))
    h=g.convex_hull
    if h.geom_type == 'Polygon':
        return np.array(h.exterior.coords[:-1])
    if h.geom_type == 'LineString':
        return np.array(h.coords)
    if h.geom_type == 'Point':
        return np.array([h.coords[0]])
    return np.empty((0,2))
def diameter(P):
    if len(P)<2:return 0.0
    best=0
    for i,j in itertools.combinations(range(len(P)),2):
        best=max(best,float(np.linalg.norm(P[i]-P[j])))
    return best

def circle2(a,b): c=(a+b)/2; return c,float(np.linalg.norm(a-b))/2

def circle3(a,b,c):
    ax,ay=a;bx,by=b;cx,cy=c;d=2*(ax*(by-cy)+bx*(cy-ay)+cx*(ay-by))
    if abs(d)<1e-12:return None
    ux=((ax*ax+ay*ay)*(by-cy)+(bx*bx+by*by)*(cy-ay)+(cx*cx+cy*cy)*(ay-by))/d
    uy=((ax*ax+ay*ay)*(cx-bx)+(bx*bx+by*by)*(ax-cx)+(cx*cx+cy*cy)*(bx-ax))/d
    cc=np.array([ux,uy]); return cc,float(np.linalg.norm(cc-a))
def mec(P):
    P=np.array(P,float); n=len(P); best=(1e99,None)
    def cover(c,r):return np.max(np.linalg.norm(P-c,axis=1))<=r+1e-8
    for i,j in itertools.combinations(range(n),2):
        c,r=circle2(P[i],P[j])
        if r<best[0] and cover(c,r):best=(r,c)
    for i,j,k in itertools.combinations(range(n),3):
        q=circle3(P[i],P[j],P[k])
        if q:
            c,r=q
            if r<best[0] and cover(c,r):best=(r,c)
    if best[1] is None:
        return np.mean(P,axis=0),0
    return best[1],best[0]

# Regenerate existing figures with CJK font
# Q1 figure
true=np.array([820.,360.]); stations=[np.array([-500.,-200.]),np.array([1100.,-600.]),np.array([300.,1200.])]
errs=np.radians([0.7,-0.4,0.9]); delta=math.radians(1)
# intersect polygons using large box
box=Polygon([(-4000,-4000),(4000,-4000),(4000,4000),(-4000,4000)])
region=box
fig,ax=plt.subplots(figsize=(7.2,6.2))
for S,e,col in zip(stations,errs,['tab:blue','tab:orange','tab:green']):
    theta=math.atan2(true[1]-S[1],true[0]-S[0])+e
    W=wedge_polygon(S,theta,delta,5000)
    region=region.intersection(W)
    x,y=W.exterior.xy;ax.fill(x,y,alpha=.08,color=col);ax.plot(*S,'o',color=col)
P=poly_pts(region);D=diameter(P)
# farthest pair
bi=bj=0;bd=-1
for i,j in itertools.combinations(range(len(P)),2):
    d=np.linalg.norm(P[i]-P[j])
    if d>bd:bd=d;bi=i;bj=j
A,B=P[bi],P[bj]
pr=np.vstack([P,P[0]]);ax.fill(pr[:,0],pr[:,1],alpha=.35,color='crimson',label='可行定位区域 $P$');ax.plot([A[0],B[0]],[A[1],B[1]],'k-',lw=2,label=f'直径 $D={D:.1f}$ m');ax.plot(*true,'k*',ms=10,label='真实源（示意）')
ax.set_aspect('equal');ax.grid(alpha=.2);ax.legend(fontsize=9);ax.set_title('Q1：有界测向楔形的集合交会定位');ax.set_xlabel('x / m');ax.set_ylabel('y / m');fig.tight_layout();fig.savefig(FIG/'q1_wedge_intersection.png',dpi=200);plt.close(fig)

tri=np.array([[0.,0.],[1000.,0.],[500.,math.sqrt(3)/2*1000]])
Dtri=1000.;mid=(tri[0]+tri[1])/2;cm,rm=mec(tri)
fig,ax=plt.subplots(figsize=(7.2,5.6));tr=np.vstack([tri,tri[0]]);ax.fill(tr[:,0],tr[:,1],alpha=.12);ax.plot(tr[:,0],tr[:,1],'k-',lw=2)
t=np.linspace(0,2*math.pi,500);ax.plot(mid[0]+500*np.cos(t),mid[1]+500*np.sin(t),'--',lw=2,label='直径圆（半径 $D/2$）');ax.plot(cm[0]+rm*np.cos(t),cm[1]+rm*np.sin(t),'-',lw=2,label='最小包围圆 MEC');ax.set_aspect('equal');ax.grid(alpha=.2);ax.legend();ax.set_title('Q1：正三角形反例与最小包围圆');ax.set_xlabel('x / m');ax.set_ylabel('y / m');fig.tight_layout();fig.savefig(FIG/'q1_mec_counterexample.png',dpi=200);plt.close(fig)

# Q2 signal region lens
fig,ax=plt.subplots(figsize=(8,5.6));t=np.linspace(0,2*math.pi,700)
for c,col in [((5,0),'tab:blue'),((1500,0),'tab:blue'),((1000,0),'tab:orange')]:ax.plot(c[0]+1000*np.cos(t),c[1]+1000*np.sin(t),color=col,alpha=.65)
xx=np.linspace(-250,1800,520);yy=np.linspace(-1000,1000,420);X,Y=np.meshgrid(xx,yy)
mask1=((X-5)**2+Y**2<=1e6)&((X-1500)**2+Y**2<=1e6);mask2=((X-5)**2+Y**2<=1e6)&((X-1000)**2+Y**2<=1e6)
ax.contourf(X,Y,mask2.astype(int),levels=[.5,1.5],colors=['tab:orange'],alpha=.16);ax.contourf(X,Y,mask1.astype(int),levels=[.5,1.5],colors=['tab:blue'],alpha=.28)
ax.plot([5,1500],[0,0],'k-',lw=3,label='零角宽近似的第一次可行射线段');ax.text(260,810,'$C_{sig}^*$',color='tab:orange',fontsize=12);ax.text(690,210,'$C_{sig}$',color='tab:blue',fontsize=12)
ax.set_aspect('equal');ax.set_xlim(-200,1800);ax.set_ylim(-1000,1000);ax.grid(alpha=.18);ax.set_xlabel('沿第一次示向方向 / m');ax.set_ylabel('横向基线 / m');ax.set_title('Q2：第一次正观测扩大保证二次有信号的区域');fig.tight_layout();fig.savefig(FIG/'q2_signal_regions.png',dpi=200);plt.close(fig)

# Fast approximate heatmap
F1=sector_polygon(); delta=math.radians(1)
# only boundary + few interior true source samples
g=[]
for a in [-delta,0,delta]:
    for r in [100,300,600,900,1200,1500]:g.append(np.array([r*math.cos(a),r*math.sin(a)]))
for a in np.linspace(-delta,delta,7):
    for r in [450,1000,1450]:g.append(np.array([r*math.cos(a),r*math.sin(a)]))
evals=np.radians([-1,0,1])
cert=[]
for a in np.linspace(-delta,delta,15):
    for r in np.linspace(5,1500,25):cert.append(np.array([r*math.cos(a),r*math.sin(a)]))
def Japprox(xy):
    x=np.array(xy,float);worst=0
    for p in g:
        if np.linalg.norm(x-p)<=5:continue
        beta=math.atan2(p[1]-x[1],p[0]-x[0])
        for e in evals:
            q=F1.intersection(wedge_polygon(x,beta+e,delta,5000)).difference(Point(*x).buffer(5,resolution=12))
            worst=max(worst,diameter(poly_pts(q)))
    return worst
xs=np.arange(200,1001,100);ys=np.arange(0,801,100);J=np.full((len(ys),len(xs)),np.nan)
for iy,y in enumerate(ys):
    for ix,x in enumerate(xs):
        z=np.array([x,y],float)
        if all(np.linalg.norm(z-p)<=max(1000,np.linalg.norm(p))+1e-9 for p in cert):J[iy,ix]=Japprox(z)
best_idx=np.unravel_index(np.nanargmin(J),J.shape);best=(xs[best_idx[1]],ys[best_idx[0]],J[best_idx])
fig,ax=plt.subplots(figsize=(8,5.8));im=ax.imshow(np.ma.masked_invalid(J),origin='lower',extent=[150,1050,-50,850],aspect='auto');fig.colorbar(im,ax=ax,label='近似最坏定位直径 $J_D$ / m');ax.plot(best[0],best[1],'r*',ms=13,label=f'网格最优示意 ({best[0]}, {best[1]})');ax.set_xlabel('第二测站前向位移 x / m');ax.set_ylabel('横向位移 |y| / m');ax.set_title('Q2：保证信号域内的 min-max 目标示意（非官方数值）');ax.legend();fig.tight_layout();fig.savefig(FIG/'q2_minmax_heatmap.png',dpi=200);plt.close(fig)

# linearized tradeoff
phis=np.radians(np.linspace(5,175,400));dlt=delta
fig,ax=plt.subplots(figsize=(7.5,5.2))
for r1,r2 in [(1000,1000),(1200,800),(1500,600)]:
    val=2*dlt/np.abs(np.sin(phis))*np.sqrt(r1*r1+r2*r2+2*r1*r2*np.abs(np.cos(phis)))
    ax.plot(np.degrees(phis),val,label=f'$r_1={r1}$ m, $r_2={r2}$ m')
ax.set_yscale('log');ax.grid(alpha=.25);ax.legend(fontsize=9);ax.set_xlabel('两次真实 bearing 的交会角 $\\phi$ / deg');ax.set_ylabel('一阶近似直径 $D_{lin}$ / m（对数轴）');ax.set_title('Q2：交会角与测站距离的解析折中');fig.tight_layout();fig.savefig(FIG/'q2_linearized_tradeoff.png',dpi=200);plt.close(fig)

# Validation on random convex polygons
rng=np.random.default_rng(20260912);mismatch=0;jung=0;kvals=[]
for _ in range(200):
    pts=rng.normal(size=(12,2))*rng.uniform(50,1000);P=pts[ConvexHull(pts).vertices];D=diameter(P);cm,rm=mec(P);k=2*rm/D;kvals.append(k)
    if rm < D/2-1e-6 or rm > D/math.sqrt(3)+1e-5:jung+=1
# exact equilateral
summary={'random_convex_cases':200,'jung_violations':jung,'kappa_min':float(min(kvals)),'kappa_max':float(max(kvals)),'q2_grid_best':{'x_m':int(best[0]),'abs_y_m':int(best[1]),'approx_J_m':float(best[2])}}
(QA/'validation_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with open(QA/'q2_heatmap_values.csv','w',encoding='utf-8') as f:
    f.write('abs_y_m,'+','.join(map(str,xs))+'\n')
    for iy,y in enumerate(ys):f.write(str(y)+','+','.join('' if not np.isfinite(v) else f'{v:.3f}' for v in J[iy])+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
