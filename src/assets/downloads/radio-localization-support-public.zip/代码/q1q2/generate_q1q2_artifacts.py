import math, itertools, json
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
from scipy.optimize import linprog
from shapely.geometry import Polygon, Point
from shapely.ops import unary_union
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
FIG = ROOT/'figures'
QA = ROOT/'qa'
FIG.mkdir(exist_ok=True, parents=True); QA.mkdir(exist_ok=True, parents=True)

EPS=1e-9

def unit(theta):
    return np.array([math.cos(theta), math.sin(theta)], dtype=float)

def wedge_halfplanes(S, theta, delta):
    # halfplanes a*x+b*y <= c corresponding to cross(u-, p-S)>=0 and cross(u+, p-S)<=0
    S=np.asarray(S,float)
    um=unit(theta-delta); up=unit(theta+delta)
    # cross(um,p-S)>=0 => um_x(y-Sy)-um_y(x-Sx)>=0 => um_y x - um_x y <= um_y Sx - um_x Sy
    h1=(um[1], -um[0], um[1]*S[0]-um[0]*S[1])
    # cross(up,p-S)<=0 => up_x(y-Sy)-up_y(x-Sx)<=0 => -up_y x + up_x y <= -up_y Sx + up_x Sy
    h2=(-up[1], up[0], -up[1]*S[0]+up[0]*S[1])
    return [h1,h2]

def halfplane_vertices(H, tol=1e-8):
    H=np.asarray(H,float)
    pts=[]
    for i,j in itertools.combinations(range(len(H)),2):
        a1,b1,c1=H[i]; a2,b2,c2=H[j]
        det=a1*b2-a2*b1
        if abs(det)<1e-12: continue
        x=(c1*b2-c2*b1)/det; y=(a1*c2-a2*c1)/det
        p=np.array([x,y])
        if np.all(H[:,:2]@p <= H[:,2]+tol): pts.append(p)
    if len(pts)<3: return np.array(pts)
    # unique
    arr=np.array(pts)
    uniq=[]
    for p in arr:
        if not any(np.linalg.norm(p-q)<1e-7 for q in uniq): uniq.append(p)
    arr=np.array(uniq)
    if len(arr)<3: return arr
    hull=ConvexHull(arr)
    return arr[hull.vertices]

def is_unbounded(H):
    H=np.asarray(H,float)
    A=H[:,:2]; b=H[:,2]
    # Check feasibility first
    res=linprog([0,0], A_ub=A,b_ub=b,bounds=[(None,None),(None,None)],method='highs')
    if not res.success: return False
    for d in ([1,0],[-1,0],[0,1],[0,-1]):
        res=linprog([-d[0],-d[1]], A_ub=A,b_ub=b,bounds=[(None,None),(None,None)],method='highs')
        if res.status==3: return True
    return False

def polygon_diameter_brute(P):
    P=np.asarray(P,float); best=(-1,None,None)
    for i,j in itertools.combinations(range(len(P)),2):
        d2=float(np.dot(P[i]-P[j],P[i]-P[j]))
        if d2>best[0]: best=(d2,i,j)
    return math.sqrt(best[0]), best[1], best[2]

def polygon_diameter_calipers(P):
    # Standard rotating calipers for CCW convex polygon. Falls back for small/degenerate.
    P=np.asarray(P,float); n=len(P)
    if n<2: return 0.0,0,0
    if n==2: return float(np.linalg.norm(P[0]-P[1])),0,1
    def area2(a,b,c): return abs(np.cross(b-a,c-a))
    j=1; best_d2=0; best=(0,1)
    for i in range(n):
        ni=(i+1)%n
        # advance j while area increases
        while area2(P[i],P[ni],P[(j+1)%n]) > area2(P[i],P[ni],P[j]) + 1e-12:
            j=(j+1)%n
        for a,b in [(i,j),(ni,j)]:
            d2=float(np.dot(P[a]-P[b],P[a]-P[b]))
            if d2>best_d2:
                best_d2=d2; best=(a,b)
    return math.sqrt(best_d2), best[0], best[1]

def circle_from_2(a,b):
    c=(a+b)/2; r=float(np.linalg.norm(a-b))/2; return c,r

def circle_from_3(a,b,c):
    ax,ay=a; bx,by=b; cx,cy=c
    d=2*(ax*(by-cy)+bx*(cy-ay)+cx*(ay-by))
    if abs(d)<1e-12: return None
    ux=((ax*ax+ay*ay)*(by-cy)+(bx*bx+by*by)*(cy-ay)+(cx*cx+cy*cy)*(ay-by))/d
    uy=((ax*ax+ay*ay)*(cx-bx)+(bx*bx+by*by)*(ax-cx)+(cx*cx+cy*cy)*(bx-ax))/d
    center=np.array([ux,uy]); r=float(np.linalg.norm(center-a)); return center,r

def mec_deterministic(P,tol=1e-8):
    P=np.asarray(P,float); n=len(P)
    if n==0: return np.array([0.,0.]),0.0,()
    if n==1: return P[0].copy(),0.0,(0,)
    best=(float('inf'),None,None)
    def covers(c,r): return np.max(np.linalg.norm(P-c,axis=1)) <= r+tol
    for i,j in itertools.combinations(range(n),2):
        c,r=circle_from_2(P[i],P[j])
        if r<best[0] and covers(c,r): best=(r,c,(i,j))
    for i,j,k in itertools.combinations(range(n),3):
        cc=circle_from_3(P[i],P[j],P[k])
        if cc is None: continue
        c,r=cc
        if r<best[0] and covers(c,r): best=(r,c,(i,j,k))
    if best[1] is None:
        # degenerate collinear: farthest pair
        D,i,j=polygon_diameter_brute(P); c,r=circle_from_2(P[i],P[j]); return c,r,(i,j)
    return best[1],best[0],best[2]

def thales_ok(P,A,B,tol=1e-8):
    vals=[float(np.dot(v-A,v-B)) for v in P]
    return max(vals)<=tol, max(vals)

def wedge_polygon(S, theta, delta, L=5000):
    S=np.asarray(S,float)
    a=S + L*unit(theta-delta); b=S + L*unit(theta+delta)
    return Polygon([tuple(S),tuple(a),tuple(b)])

def sector_polygon(rmin=5,rmax=1500,amin=-math.radians(1),amax=math.radians(1),n=800):
    outer=[(rmax*math.cos(a),rmax*math.sin(a)) for a in np.linspace(amin,amax,n//2)]
    inner=[(rmin*math.cos(a),rmin*math.sin(a)) for a in np.linspace(amax,amin,n//2)]
    return Polygon(outer+inner)

def poly_coords(geom):
    if geom.is_empty: return np.empty((0,2))
    g=geom.convex_hull
    return np.array(g.exterior.coords[:-1])

def diameter_shapely(geom):
    P=poly_coords(geom)
    if len(P)<2: return 0.0
    return polygon_diameter_brute(P)[0]

def approximate_J(x, F1, g_samples, e_samples, delta=math.radians(1)):
    x=np.asarray(x,float); worst=0.0
    for g in g_samples:
        if np.linalg.norm(g-x)<=5:
            post=0.0
            worst=max(worst,post); continue
        beta=math.atan2(g[1]-x[1],g[0]-x[0])
        for e in e_samples:
            theta=beta+e
            W=wedge_polygon(x,theta,delta,L=5000)
            F2=F1.intersection(W)
            # normal direction implies >5m; removing disk may make nonconvex. Diameter equals diameter of convex hull of exact set.
            F2=F2.difference(Point(*x).buffer(5,resolution=32))
            post=diameter_shapely(F2)
            worst=max(worst,post)
    return worst

# ---------- Figure 1: Q1 wedge intersection ----------
true=np.array([820.,360.])
stations=[np.array([-500.,-200.]), np.array([1100.,-600.]), np.array([300.,1200.])]
errs=np.radians([0.7,-0.4,0.9]); delta=math.radians(1)
H=[]
for S,e in zip(stations,errs):
    theta=math.atan2(true[1]-S[1],true[0]-S[0])+e
    H += wedge_halfplanes(S,theta,delta)
P=halfplane_vertices(H)
D,ia,ib=polygon_diameter_calipers(P); A=P[ia]; B=P[ib]
cmec,rmec,supp=mec_deterministic(P)
ok,tmax=thales_ok(P,A,B)

fig,ax=plt.subplots(figsize=(7.2,6.3))
colors=['tab:blue','tab:orange','tab:green']
for S,e,col in zip(stations,errs,colors):
    theta=math.atan2(true[1]-S[1],true[0]-S[0])+e
    wp=wedge_polygon(S,theta,delta,L=2500)
    xs,ys=wp.exterior.xy
    ax.fill(xs,ys,alpha=.10,color=col)
    ax.plot(S[0],S[1],'o',color=col); ax.text(S[0]+25,S[1]+25,'$S$',color=col)
if len(P)>=3:
    pp=np.vstack([P,P[0]])
    ax.fill(pp[:,0],pp[:,1],alpha=.35,label='可行定位区域 $P$',color='crimson')
    ax.plot([A[0],B[0]],[A[1],B[1]],'k-',lw=2,label=f'直径 $D={D:.1f}$ m')
ax.plot(*true,'k*',ms=10,label='真实源（仅用于示意）')
ax.set_aspect('equal'); ax.grid(alpha=.2); ax.legend(loc='best',fontsize=9)
ax.set_xlabel('x / m'); ax.set_ylabel('y / m'); ax.set_title('Q1：有界测向楔形的集合交会定位')
fig.tight_layout(); fig.savefig(FIG/'q1_wedge_intersection.png',dpi=220); plt.close(fig)

# Figure 2: diameter circle vs MEC counterexample
tri=np.array([[0.,0.],[1000.,0.],[500.,math.sqrt(3)/2*1000]])
D2,i2,j2=polygon_diameter_brute(tri); A2=tri[i2]; B2=tri[j2]
mid=(A2+B2)/2; c2,r2,_=mec_deterministic(tri)
fig,ax=plt.subplots(figsize=(7.2,5.8))
tr=np.vstack([tri,tri[0]]); ax.plot(tr[:,0],tr[:,1],'k-',lw=2); ax.fill(tr[:,0],tr[:,1],alpha=.12)
for p,l in zip(tri,['A','B','C']): ax.plot(*p,'ko'); ax.text(p[0]+18,p[1]+18,l)
for c,r,ls,label in [(mid,D2/2,'--','某一直径对对应的直径圆'),(c2,r2,'-','最小包围圆 MEC')]:
    tt=np.linspace(0,2*math.pi,400); ax.plot(c[0]+r*np.cos(tt),c[1]+r*np.sin(tt),ls,lw=2,label=label)
ax.set_aspect('equal'); ax.grid(alpha=.2); ax.legend(fontsize=9); ax.set_title('Q1：正三角形说明直径圆并不总能覆盖')
ax.set_xlabel('x / m'); ax.set_ylabel('y / m'); fig.tight_layout(); fig.savefig(FIG/'q1_mec_counterexample.png',dpi=220); plt.close(fig)

# Figure 3: canonical Csig and Csig*
fig,ax=plt.subplots(figsize=(8,5.6))
t=np.linspace(0,2*math.pi,800)
# conservative: centers 5 and 1500, radius1000; enhanced: 5 and1000
for center,style in [((5,0),'tab:blue'),((1500,0),'tab:blue'),((1000,0),'tab:orange')]:
    ax.plot(center[0]+1000*np.cos(t),center[1]+1000*np.sin(t),color=style,alpha=.65)
# fill lenses through grid mask
xx=np.linspace(-300,1800,700); yy=np.linspace(-1000,1000,600); X,Y=np.meshgrid(xx,yy)
mask1=((X-5)**2+Y**2<=1000**2)&((X-1500)**2+Y**2<=1000**2)
mask2=((X-5)**2+Y**2<=1000**2)&((X-1000)**2+Y**2<=1000**2)
ax.contourf(X,Y,mask2.astype(int),levels=[.5,1.5],colors=['tab:orange'],alpha=.16)
ax.contourf(X,Y,mask1.astype(int),levels=[.5,1.5],colors=['tab:blue'],alpha=.25)
ax.plot([5,1500],[0,0],'k-',lw=3,label='零角宽近似的第一次可行射线段')
ax.text(260,800,'$C_{sig}^*$',color='tab:orange',fontsize=12)
ax.text(680,210,'$C_{sig}$',color='tab:blue',fontsize=12)
ax.set_aspect('equal'); ax.set_xlim(-200,1800); ax.set_ylim(-1000,1000); ax.grid(alpha=.18)
ax.set_xlabel('沿第一次示向方向 / m'); ax.set_ylabel('横向基线 / m'); ax.set_title('Q2：第一次正观测扩大了保证二次有信号的区域')
fig.tight_layout(); fig.savefig(FIG/'q2_signal_regions.png',dpi=220); plt.close(fig)

# Figure 4: approximate J heatmap for canonical +/-1deg sector
F1=sector_polygon()
# source samples: boundary rays + radial middle + outer arc
rs=np.concatenate([np.linspace(5,1500,30),np.array([1000])])
g_samples=[]
for a in [-delta,0,delta]:
    for r in rs: g_samples.append(np.array([r*math.cos(a),r*math.sin(a)]))
for a in np.linspace(-delta,delta,21):
    for r in [300,600,900,1200,1500]: g_samples.append(np.array([r*math.cos(a),r*math.sin(a)]))
e_samples=np.radians(np.linspace(-1,1,5))
xs=np.arange(200,1001,100); ys=np.arange(0,801,100)
J=np.full((len(ys),len(xs)),np.nan)
# guaranteed-signal check approximate on dense g samples: dist <= max(1000,dist to S1)
cert_samples=[]
for a in np.linspace(-delta,delta,61):
    for r in np.linspace(5,1500,80): cert_samples.append(np.array([r*math.cos(a),r*math.sin(a)]))
for iy,y in enumerate(ys):
    for ix,x in enumerate(xs):
        z=np.array([x,y])
        if all(np.linalg.norm(z-g) <= max(1000,np.linalg.norm(g)) + 1e-9 for g in cert_samples):
            J[iy,ix]=approximate_J(z,F1,g_samples,e_samples,delta)
finite=np.isfinite(J)
best_idx=np.unravel_index(np.nanargmin(J),J.shape); best=(xs[best_idx[1]],ys[best_idx[0]],J[best_idx])
fig,ax=plt.subplots(figsize=(8,5.8))
masked=np.ma.masked_invalid(J)
im=ax.imshow(masked,origin='lower',extent=[xs[0]-50,xs[-1]+50,ys[0]-50,ys[-1]+50],aspect='auto')
fig.colorbar(im,ax=ax,label='近似最坏定位直径 $J_D$ / m')
ax.plot(best[0],best[1],'r*',ms=13,label=f'网格最优示意 ({best[0]}, {best[1]})')
ax.set_xlabel('第二测站前向位移 x / m'); ax.set_ylabel('横向位移 |y| / m'); ax.set_title('Q2：保证信号域内的 min-max 目标示意（非官方数值）'); ax.legend()
fig.tight_layout(); fig.savefig(FIG/'q2_minmax_heatmap.png',dpi=220); plt.close(fig)

# Figure 5: linearized geometry tradeoff
phis=np.radians(np.linspace(5,175,400)); dlt=math.radians(1)
fig,ax=plt.subplots(figsize=(7.5,5.2))
for r1,r2 in [(1000,1000),(1200,800),(1500,600)]:
    val=2*dlt/np.abs(np.sin(phis))*np.sqrt(r1*r1+r2*r2+2*r1*r2*np.abs(np.cos(phis)))
    ax.plot(np.degrees(phis),val,label=f'$r_1={r1}$m, $r_2={r2}$m')
ax.set_yscale('log'); ax.grid(alpha=.25); ax.legend(fontsize=9); ax.set_xlabel('两次真实 bearing 的交会角 $\\phi$ / deg'); ax.set_ylabel('一阶近似直径 $D_{lin}$ / m (log)'); ax.set_title('Q2：交会角与测站距离的解析折中')
fig.tight_layout(); fig.savefig(FIG/'q2_linearized_tradeoff.png',dpi=220); plt.close(fig)

# Validation: calipers vs brute; Thales/MEC equivalence on random convex polygons
rng=np.random.default_rng(20260912)
max_d_err=0.0; mismatch=0; jung_viol=0; cases=1000
kappas=[]
for _ in range(cases):
    pts=rng.normal(size=(rng.integers(5,25),2))*rng.uniform(50,1000)
    hull=ConvexHull(pts); P0=pts[hull.vertices]
    Db,ib,jb=polygon_diameter_brute(P0); Dc,ic,jc=polygon_diameter_calipers(P0)
    max_d_err=max(max_d_err,abs(Db-Dc))
    A=P0[ic]; B=P0[jc]; th,_=thales_ok(P0,A,B,tol=1e-7)
    c,r,_=mec_deterministic(P0,tol=1e-7)
    mecok=(r <= Dc/2 + 1e-6)
    if th!=mecok: mismatch+=1
    if r < Dc/2-1e-6 or r > Dc/math.sqrt(3)+1e-5: jung_viol+=1
    kappas.append(2*r/Dc)

# Canonical support / signal region sanity: random samples from exact 1D case
# Csig* exact lens B((5,0),1000) intersect B((1000,0),1000)
def in_lens(z):
    z=np.asarray(z); return np.linalg.norm(z-np.array([5.,0.]))<=1000+1e-9 and np.linalg.norm(z-np.array([1000.,0.]))<=1000+1e-9
viol=0; checked=0
for _ in range(20000):
    z=np.array([rng.uniform(-500,1600),rng.uniform(-1000,1000)])
    if not in_lens(z): continue
    checked+=1
    for r in rng.uniform(5,1500,20):
        g=np.array([r,0.]); rho=max(1000,r)
        if np.linalg.norm(z-g)>rho+1e-8: viol+=1; break

summary={
    'q1_random_convex_cases':cases,
    'max_abs_diameter_error_calipers_vs_brute_m':max_d_err,
    'thales_vs_mec_mismatch_count':mismatch,
    'jung_violation_count':jung_viol,
    'kappa_min':float(np.min(kappas)),
    'kappa_max':float(np.max(kappas)),
    'canonical_csigstar_random_points_checked':checked,
    'canonical_csigstar_guarantee_violations':viol,
    'illustrative_q1_D_m':D,
    'illustrative_q1_Rmec_m':rmec,
    'illustrative_q1_kappa':2*rmec/D,
    'illustrative_q1_thales_cover':ok,
    'q2_heatmap_best_grid_point':{'x':int(best[0]),'abs_y':int(best[1]),'approx_J_m':float(best[2])}
}
(QA/'validation_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')

# small CSV heatmap
with open(QA/'q2_heatmap_values.csv','w',encoding='utf-8') as f:
    f.write('abs_y_m,'+','.join(map(str,xs))+'\n')
    for iy,y in enumerate(ys):
        vals=[('' if not np.isfinite(v) else f'{v:.6f}') for v in J[iy]]
        f.write(str(y)+','+','.join(vals)+'\n')

print(json.dumps(summary,ensure_ascii=False,indent=2))
