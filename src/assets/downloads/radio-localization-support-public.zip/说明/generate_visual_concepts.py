"""Generate the phase-1 visual redesign concepts for Figures 3, 7 and 11.

The geometry panels are deterministic explanatory constructions.  Figure 11
reads the frozen offline, rehearsal and formal summaries without modifying
their source files.  Every generated quantitative value is also written to a
CSV snapshot and a SHA-256 provenance manifest.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from matplotlib.patches import Circle, Polygon
from PIL import Image


PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parent
ASSETS = PAPER / "publication_assets"
OUT = PAPER / "visual_redesign" / "concepts"
QA = PAPER / "visual_redesign" / "qa"
OUT.mkdir(parents=True, exist_ok=True)
QA.mkdir(parents=True, exist_ok=True)

# Register a bundled system CJK font explicitly so Linux rebuilds remain legible.
_CJK_FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
_CJK_FONT_BOLD = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
for _font_path in (_CJK_FONT, _CJK_FONT_BOLD):
    try:
        font_manager.fontManager.addfont(_font_path)
    except Exception:
        pass
_CJK_FAMILY = font_manager.FontProperties(fname=_CJK_FONT).get_name()

FORMAL_CANDIDATES = (
    ASSETS / "formal_results_20260912.json",
    PROJECT / ".worktrees" / "q3-q4-speed-final" / "outputs" / "formal_20260912" / "FORMAL_RESULTS.json",
)

# Color roles are shared by all redesigned figures.
INK = "#202428"
NAVY = "#24557A"
TEAL = "#2A7F9E"
ORANGE = "#C65D21"
GREEN = "#2F7D62"
FORMAL = "#173B57"
REHEARSAL = "#5B84B1"
OFFLINE = "#7A7A7A"
HISTORY = "#AEB8C1"
GRID = "#D9DDE1"
PALE_BLUE = "#DDE8F0"
PALE_ORANGE = "#F4E3D8"

mpl.rcParams.update(
    {
        "font.family": _CJK_FAMILY,
        "mathtext.fontset": "stix",
        "axes.unicode_minus": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "font.size": 8.2,
        "axes.labelsize": 8.2,
        "xtick.labelsize": 7.3,
        "ytick.labelsize": 7.3,
        "axes.linewidth": 0.8,
        "lines.linewidth": 1.3,
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    }
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def formal_path() -> Path:
    for path in FORMAL_CANDIDATES:
        if path.exists():
            return path
    raise FileNotFoundError("Frozen FORMAL_RESULTS.json was not found")


def export(fig: plt.Figure, stem: str) -> None:
    for suffix in ("pdf", "svg"):
        fig.savefig(OUT / f"{stem}.{suffix}", facecolor="white", bbox_inches=None)
    fig.savefig(OUT / f"{stem}.png", dpi=600, facecolor="white", bbox_inches=None)
    plt.close(fig)

    source = Image.open(OUT / f"{stem}.png").convert("RGB")
    source.convert("L").save(QA / f"{stem}_gray.png", dpi=(300, 300))
    target_width = 915 if source.width / source.height > 2.1 else 786
    target_height = max(1, round(source.height * target_width / source.width))
    source.resize((target_width, target_height), Image.Resampling.LANCZOS).save(
        QA / f"{stem}_print_size.png", dpi=(150, 150)
    )


def panel_label(ax: plt.Axes, label: str, title: str) -> None:
    ax.text(0.0, 1.035, label, transform=ax.transAxes, ha="left", va="bottom", weight="bold", fontsize=9)
    ax.text(0.105, 1.035, title, transform=ax.transAxes, ha="left", va="bottom", fontsize=8.2, color=INK)


def figure_03() -> None:
    """Exact equilateral-triangle counterexample, shown before and after MEC."""
    h = math.sqrt(3) / 2
    tri = np.array([[-0.5, 0.0], [0.5, 0.0], [0.0, h]])
    diameter_center = np.array([0.0, 0.0])
    mec_center = np.array([0.0, h / 3])
    mec_radius = 1 / math.sqrt(3)

    fig, axes = plt.subplots(1, 2, figsize=(7.15, 2.96), layout="constrained")
    for ax in axes:
        ax.add_patch(Polygon(tri, closed=True, facecolor=PALE_BLUE, edgecolor=NAVY, lw=1.55, zorder=2))
        ax.plot(tri[[0, 1], 0], tri[[0, 1], 1], color=INK, lw=1.65, zorder=3)
        ax.scatter(tri[:, 0], tri[:, 1], s=18, facecolor="white", edgecolor=NAVY, lw=1.0, zorder=5)
        ax.text(0.0, -0.105, r"直径 $D$", ha="center", va="top", color=INK)
        ax.set(xlim=(-0.78, 0.78), ylim=(-0.43, 1.13))
        ax.set_aspect("equal")
        ax.axis("off")

    ax = axes[0]
    panel_label(ax, "(a)", "直径圆：不能保证覆盖")
    ax.add_patch(Circle(diameter_center, 0.5, fill=False, edgecolor=ORANGE, lw=1.55, ls=(0, (4, 2)), zorder=1))
    ax.scatter(*diameter_center, s=16, color=ORANGE, marker="x", lw=1.2, zorder=5)
    ax.plot([0, 0], [0, 0.5], color=ORANGE, lw=1.05, ls=(0, (4, 2)))
    ax.text(0.035, 0.26, r"$D/2$", color=ORANGE, va="center")
    ax.annotate(
        "顶点落在圆外",
        xy=(0, h),
        xytext=(0.43, 0.98),
        ha="center",
        color=ORANGE,
        fontsize=7.5,
        arrowprops=dict(arrowstyle="-|>", color=ORANGE, lw=0.8, mutation_scale=8),
    )
    ax.plot([-0.055, 0.055], [0.53, 0.53], color=ORANGE, lw=1.2)
    ax.text(0.08, 0.54, "未覆盖", color=ORANGE, va="center", fontsize=7.2)

    ax = axes[1]
    panel_label(ax, "(b)", "最小包围圆：完整覆盖")
    ax.add_patch(Circle(mec_center, mec_radius, fill=False, edgecolor=GREEN, lw=1.7, zorder=1))
    ax.scatter(*mec_center, s=20, facecolor="white", edgecolor=GREEN, lw=1.1, zorder=5)
    radial_end = mec_center + np.array([0.0, mec_radius])
    ax.plot([mec_center[0], radial_end[0]], [mec_center[1], radial_end[1]], color=GREEN, lw=1.2)
    ax.text(0.035, 0.61, r"$R_{\mathrm{MEC}}=D/\sqrt{3}$", color=GREEN, va="center")
    ax.text(
        0.50,
        0.015,
        r"$\kappa=\dfrac{2R_{\mathrm{MEC}}}{D}=\dfrac{2}{\sqrt{3}}\approx1.155>1$",
        transform=ax.transAxes,
        ha="center",
        va="bottom",
        color=FORMAL,
        fontsize=8.2,
    )
    export(fig, "fig03_q1_diameter_circle_counterexample")


def _poly(ax: plt.Axes, points: np.ndarray, *, current: bool = True) -> None:
    ax.add_patch(
        Polygon(
            points,
            closed=True,
            facecolor=PALE_BLUE if current else "none",
            edgecolor=NAVY if current else HISTORY,
            lw=1.45 if current else 0.85,
            ls="-" if current else (0, (3, 2)),
            zorder=2,
        )
    )


def figure_07() -> None:
    """Same-coordinate small multiples for the Q3 feasible-set evolution."""
    p0 = np.array([[-0.88, -0.72], [-0.47, 0.88], [0.82, 0.20]])
    p1 = np.array([[-0.43, -0.28], [-0.20, 0.55], [0.55, 0.18], [0.32, -0.34]])
    p2 = np.array([[-0.24, -0.18], [-0.11, 0.36], [0.42, 0.18], [0.27, -0.25]])
    p3 = np.array([[-0.18, -0.11], [-0.10, 0.20], [0.34, 0.12], [0.27, -0.18]])

    fig, axes = plt.subplots(1, 4, figsize=(7.15, 2.24), sharex=True, sharey=True)
    headings = [
        ("$t_0$", "首次正观测"),
        ("$t_1$", "第二次正观测"),
        ("$t_2$", "负观测仿射切割"),
        ("$t_3$", "转入带状覆盖"),
    ]
    for ax, (label, title) in zip(axes, headings):
        panel_label(ax, label, title)
        ax.set(xlim=(-1.0, 1.0), ylim=(-0.92, 0.98))
        ax.set_aspect("equal")
        ax.set_xticks([-1, 0, 1])
        ax.set_yticks([-0.8, 0, 0.8])
        ax.tick_params(length=2.3, width=0.6, colors="#6D747A", labelsize=6.4)
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color(GRID)
        ax.spines[["left", "bottom"]].set_linewidth(0.7)

    _poly(axes[0], p0)
    axes[0].scatter(-0.88, -0.72, s=24, marker="o", facecolor=TEAL, edgecolor="white", lw=0.6, zorder=4)
    axes[0].plot([-0.88, -0.47], [-0.72, 0.88], color=TEAL, lw=0.8, ls=(0, (3, 2)))
    axes[0].plot([-0.88, 0.82], [-0.72, 0.20], color=TEAL, lw=0.8, ls=(0, (3, 2)))
    axes[0].text(-0.80, -0.83, "测站 1", color=TEAL, fontsize=6.8)

    _poly(axes[1], p0, current=False)
    _poly(axes[1], p1)
    axes[1].scatter(0.75, -0.62, s=25, marker="o", facecolor=TEAL, edgecolor="white", lw=0.6, zorder=4)
    axes[1].plot([0.75, -0.20], [-0.62, 0.55], color=TEAL, lw=0.8, ls=(0, (3, 2)))
    axes[1].plot([0.75, 0.32], [-0.62, -0.34], color=TEAL, lw=0.8, ls=(0, (3, 2)))
    axes[1].text(0.43, -0.80, "测站 2", color=TEAL, fontsize=6.8)

    _poly(axes[2], p1, current=False)
    _poly(axes[2], p2)
    axes[2].plot([-0.94, 0.92], [-0.36, 0.52], color=ORANGE, lw=1.05, ls="-.", zorder=3)
    axes[2].fill_between([-0.94, 0.92], [-0.36, 0.52], [0.98, 0.98], color=PALE_ORANGE, alpha=0.45, zorder=0)
    axes[2].scatter(-0.72, 0.70, s=27, marker="v", facecolor=ORANGE, edgecolor="white", lw=0.6, zorder=4)
    axes[2].text(-0.93, 0.80, "no_signal", color=ORANGE, fontsize=6.7)
    axes[2].text(0.33, 0.53, "安全半平面", color=ORANGE, fontsize=6.5, rotation=25)

    _poly(axes[3], p2, current=False)
    _poly(axes[3], p3)
    a = np.array([-0.12, -0.06])
    b = np.array([0.29, 0.08])
    axes[3].plot([a[0], b[0]], [a[1], b[1]], color=GREEN, lw=1.2, zorder=4)
    for t in np.linspace(0, 1, 6):
        q = a * (1 - t) + b * t
        axes[3].add_patch(Circle(q, 0.105, fill=False, edgecolor=GREEN, lw=0.95, zorder=4))
    axes[3].text(0.02, -0.49, "20 m 确定性覆盖", color=GREEN, fontsize=6.8, ha="center")

    fig.subplots_adjust(left=0.05, right=0.995, top=0.84, bottom=0.19, wspace=0.10)
    fig.text(0.5, 0.035, "统一坐标尺度；浅灰虚线为上一步可行域（机制示意，不是 benchmark 场景）", ha="center", fontsize=6.8, color=OFFLINE)
    export(fig, "fig07_q3_feasible_region_evolution")


def _q4_rehearsal_rows() -> list[dict]:
    rows = []
    for index in range(1, 4):
        payload = read_json(ASSETS / f"q4_rehearsal_run0{index}.json")
        count = len(payload["strategy_state"]["cleared"])
        rows.append(
            {
                "run": index,
                "sources": count,
                "s_source": payload["virtual_time_s"] / count,
            }
        )
    return rows


def _evidence_data() -> tuple[dict, list[Path]]:
    q3_offline_path = ASSETS / "q3_breakthrough_r2_120.json"
    q4_offline_path = ASSETS / "sandbox_exact_q4_100.json"
    q3_rehearsal_path = ASSETS / "q3_rehearsal_summary.json"
    q4_rehearsal_paths = [ASSETS / f"q4_rehearsal_run0{i}.json" for i in range(1, 4)]
    frozen_formal_path = formal_path()

    q3_offline = read_json(q3_offline_path)
    q4_offline = read_json(q4_offline_path)["Q4"]
    q3_rehearsal = read_json(q3_rehearsal_path)
    formal = read_json(frozen_formal_path)

    data = {
        "Q3": {
            "offline": [float(row["s_source"]) for row in q3_offline["rows"]["r2"]],
            "offline_mean": float(q3_offline["summary"]["r2"]["aggregate_s_source"]),
            "rehearsal": [
                {"run": int(row["index"]), "sources": int(row["cleared"]), "s_source": float(row["s_per_cleared"])}
                for row in q3_rehearsal["runs"]
            ],
            "rehearsal_weighted": float(q3_rehearsal["aggregate"]["aggregate_s_per_cleared"]),
            "formal": [
                {
                    "run": int(row["test_number"]),
                    "sources": int(row["cleared_sources"]),
                    "s_source": float(row["average_localization_clear_time_s"]),
                }
                for row in formal["Q3"]["runs"]
            ],
            "formal_weighted": float(formal["Q3"]["aggregate"]["aggregate_s_per_source"]),
        },
        "Q4": {
            "offline": [float(row["s_source"]) for row in q4_offline["rows"]["FULL"]],
            "offline_mean": float(q4_offline["summary"]["FULL"]["aggregate_s_source"]),
            "rehearsal": _q4_rehearsal_rows(),
            "rehearsal_weighted": 452.756995,
            "formal": [
                {
                    "run": int(row["test_number"]),
                    "sources": int(row["cleared_sources"]),
                    "s_source": float(row["average_localization_clear_time_s"]),
                }
                for row in formal["Q4"]["runs"]
            ],
            "formal_weighted": float(formal["Q4"]["aggregate"]["aggregate_s_per_source"]),
        },
    }
    sources = [q3_offline_path, q4_offline_path, q3_rehearsal_path, *q4_rehearsal_paths, frozen_formal_path]
    return data, sources


def _write_figure11_evidence(data: dict, sources: list[Path]) -> None:
    csv_path = OUT / "fig11_evidence_values.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["question", "layer", "run", "sources", "s_per_source", "aggregation"])
        writer.writeheader()
        for question in ("Q3", "Q4"):
            for index, value in enumerate(data[question]["offline"], 1):
                writer.writerow(
                    {"question": question, "layer": "offline", "run": index, "sources": "", "s_per_source": f"{value:.12f}", "aggregation": "case"}
                )
            for layer in ("rehearsal", "formal"):
                for row in data[question][layer]:
                    writer.writerow(
                        {
                            "question": question,
                            "layer": layer,
                            "run": row["run"],
                            "sources": row["sources"],
                            "s_per_source": f"{row['s_source']:.12f}",
                            "aggregation": "individual run",
                        }
                    )
            for layer in ("offline", "rehearsal", "formal"):
                writer.writerow(
                    {
                        "question": question,
                        "layer": layer,
                        "run": "weighted_mean",
                        "sources": "",
                        "s_per_source": f"{data[question][layer + '_mean' if layer == 'offline' else layer + '_weighted']:.12f}",
                        "aggregation": "aggregate total time / aggregate cleared sources",
                    }
                )

    manifest = {
        "figure": "fig11_offline_rehearsal_formal_validation",
        "metric": "virtual seconds per cleared source",
        "uncertainty": "none; deterministic cases/runs are shown without inferential intervals",
        "sources": [
            {"path": str(path.relative_to(PROJECT) if path.is_relative_to(PROJECT) else path), "bytes": path.stat().st_size, "sha256": sha256(path)}
            for path in sources
        ],
        "derived_csv": {"path": str(csv_path.relative_to(PROJECT)), "bytes": csv_path.stat().st_size, "sha256": sha256(csv_path)},
        "transformations": [
            "offline: use each saved case s_source; aggregate mean is total virtual time divided by total cleared sources",
            "rehearsal/formal: plot every individual run; label each official formal point by cleared-source count",
            "formal weighted mean: saved aggregate total virtual time divided by aggregate cleared-source count",
            "no confidence interval, smoothing, filtering, or case exclusion",
        ],
    }
    (OUT / "fig11_evidence_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def _plot_evidence_panel(ax: plt.Axes, question: str, payload: dict) -> None:
    rng = np.random.default_rng(20260913 if question == "Q3" else 20260914)
    offline = np.asarray(payload["offline"], dtype=float)
    jitter = rng.uniform(-0.19, 0.19, size=len(offline))
    ax.scatter(jitter, offline, s=9, facecolors="none", edgecolors=OFFLINE, alpha=0.38, lw=0.55, zorder=1)
    ax.hlines(payload["offline_mean"], -0.28, 0.28, color=OFFLINE, lw=2.0, zorder=3)
    ax.text(0.31, payload["offline_mean"], f"加权 {payload['offline_mean']:.1f}", va="center", color=OFFLINE, fontsize=7.0)

    offsets = np.array([-0.14, 0.0, 0.14])
    for x0, layer, color, marker, fill in (
        (1.0, "rehearsal", REHEARSAL, "o", "white"),
        (2.0, "formal", FORMAL, "D", FORMAL),
    ):
        rows = payload[layer]
        for item_index, (dx, row) in enumerate(zip(offsets, rows)):
            ax.scatter(x0 + dx, row["s_source"], s=37 if layer == "formal" else 32, marker=marker, facecolor=fill, edgecolor=color, lw=1.15, zorder=4)
            if layer == "formal":
                formal_offsets = [(0, 8), (-15, -13), (16, -17)] if question == "Q3" else [(0, 8), (-10, -14), (10, 8)]
                x_text, y_text = formal_offsets[item_index]
                ax.annotate(
                    f"{row['sources']}源 · {row['s_source']:.1f}",
                    (x0 + dx, row["s_source"]),
                    xytext=(x_text, y_text),
                    textcoords="offset points",
                    ha="center",
                    va="bottom" if y_text > 0 else "top",
                    color=FORMAL,
                    fontsize=6.5,
                )
            # Rehearsal points remain individually visible, but only formal
            # points carry source-count labels to keep the evidence panel quiet.
        weighted = payload[layer + "_weighted"]
        ax.hlines(weighted, x0 - 0.29, x0 + 0.29, color=color, lw=2.2 if layer == "formal" else 1.6, zorder=3)
        label_y = weighted
        if layer == "rehearsal" and question == "Q3":
            label_y += 7.0
        if layer == "formal" and question == "Q3":
            label_y += 11.0
        ax.text(x0 + 0.32, label_y, f"加权 {weighted:.1f}", va="center", color=color, fontsize=7.0, weight="bold" if layer == "formal" else "normal")

    all_values = np.concatenate(
        [offline, np.array([r["s_source"] for r in payload["rehearsal"]]), np.array([r["s_source"] for r in payload["formal"]])]
    )
    margin = max(18.0, 0.12 * (all_values.max() - all_values.min()))
    ax.set_ylim(all_values.min() - margin, all_values.max() + margin)
    ax.set_xlim(-0.45, 2.82)
    ax.set_xticks([0, 1, 2], ["离线模拟", "官方演练", "官方正式"])
    ax.set_ylabel("虚拟时间 / (s·源$^{-1}$)")
    ax.text(-0.02, 1.105, question, transform=ax.transAxes, ha="left", va="bottom", fontsize=10, weight="bold")
    ax.grid(axis="y", color=GRID, lw=0.5, zorder=0)
    ax.axvline(0.5, color=GRID, lw=0.7, ls=(0, (2, 3)))
    ax.axvline(1.5, color=GRID, lw=0.7, ls=(0, (2, 3)))
    ax.spines[["top", "right"]].set_visible(False)
    ax.text(0.0, 1.035, f"离线：{len(offline)} 个固定场景", transform=ax.transAxes, color=OFFLINE, fontsize=6.7, va="bottom")
    ax.text(1.0, 1.035, "◇ 正式测试（全部展示）", transform=ax.transAxes, color=FORMAL, fontsize=6.7, va="bottom", ha="right")


def figure_11(stem: str = "fig11_offline_rehearsal_formal_validation") -> None:
    data, sources = _evidence_data()
    _write_figure11_evidence(data, sources)
    fig, axes = plt.subplots(1, 2, figsize=(7.15, 3.34))
    for ax, question in zip(axes, ("Q3", "Q4")):
        _plot_evidence_panel(ax, question, data[question])
    fig.subplots_adjust(left=0.08, right=0.99, top=0.83, bottom=0.20, wspace=0.28)
    fig.text(
        0.5,
        0.035,
        "浅灰空心点为离线模拟场景；蓝色空心圆为官方演练；深色菱形为三次官方正式测试。横线均为按清除源数加权的汇总值。",
        ha="center",
        fontsize=6.7,
        color=INK,
    )
    export(fig, stem)


def concept_review() -> None:
    entries = [
        ("fig03_q1_diameter_circle_counterexample", "Fig.3  理论反例：同一对象上的失败与修正"),
        ("fig07_q3_feasible_region_evolution", "Fig.7  机制演化：共同尺度 small multiples"),
        ("fig11_offline_rehearsal_formal_validation", "Fig.11  证据分层：离线—演练—正式"),
    ]
    fig, axes = plt.subplots(3, 1, figsize=(8.27, 11.69))
    for ax, (stem, title) in zip(axes, entries):
        ax.imshow(Image.open(OUT / f"{stem}.png").convert("RGB"))
        ax.set_title(title, loc="left", fontsize=10, weight="bold", pad=7, color=INK)
        ax.axis("off")
    fig.suptitle("CUMCM 2026 B 题 · 视觉重构第一阶段概念审查", fontsize=13, weight="bold", y=0.985, color=INK)
    fig.subplots_adjust(left=0.02, right=0.98, top=0.94, bottom=0.025, hspace=0.26)
    fig.savefig(PAPER / "visual_redesign" / "VISUAL_CONCEPT_REVIEW.pdf", facecolor="white", bbox_inches=None)
    fig.savefig(PAPER / "visual_redesign" / "VISUAL_CONCEPT_REVIEW.png", dpi=180, facecolor="white", bbox_inches=None)
    plt.close(fig)


def main() -> None:
    figure_03()
    figure_07()
    figure_11()
    concept_review()
    print(f"Generated phase-1 concepts in {OUT}")


if __name__ == "__main__":
    main()
