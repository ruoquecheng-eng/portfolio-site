# Table Evidence Ledger

本版没有改变任何冻结结果值，只对“哪些对照进入正文”进行了编辑筛选。正文只保留能解释最终模型正确性或性能来源的对照；研发中间版本和官方演练仍保存在源数据与 supporting evidence 中。

| Table / cell group | Source | Main-text transformation |
|---|---|---|
| Q1 几何交叉验证 | `publication_assets/q1_validation.json` | 直接提取；中文化表头 |
| Q3 离线消融 | `sandbox_exact_q3_120.json` + `q3_breakthrough_r2_120.json` | 正文仅保留基线与最终模型；中间“直接迁移”保留在 supporting evidence |
| Q4 离线消融 | `sandbox_exact_q4_100.json` | 正文保留基线、混合滚动调度（FULL_NN）和最终模型（FULL）；PAIR_BOUND 移出正文性能链 |
| Q3 正式测试 | `publication_assets/formal_results_20260912.json` | 三局逐局值全部展示；汇总 = 总虚拟时间 / 42 个清除源 |
| Q4 正式测试 | `publication_assets/formal_results_20260912.json` | 三局逐局值全部展示；汇总 = 总虚拟时间 / 35 个清除源 |
| 时间构成 | Q3 Final R2、Q4 FULL 离线汇总 | 按官方计时规则拆分移动、检测、切换、成功清除和未命中清除时间 |
| Fig.8 | `generated_tables/figure_q3_performance.csv` | 只绘基线与最终模型；中间版本不进入正文图 |
| Fig.11 | Q3/Q4 offline JSON + formal JSON | 只绘离线与正式两层；所有正式测试全部展示 |

术语：`failed clear` 在正文统一表述为“未命中清除尝试”，它表示某次 clear 指令未命中候选源，不表示最终存在未清除源。
