"""Generate the complete publication-grade visual system for the B paper."""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Circle, Polygon as MplPolygon, Rectangle, Wedge
from scipy.interpolate import griddata
from shapely.geometry import Point, Polygon

import generate_visual_concepts as core


PAPER = Path(__file__).resolve().parents[1]
ASSETS = PAPER / "publication_assets"
TABLES = PAPER / "generated_tables"
OUT = PAPER / "visual_redesign" / "figures_final"
QA = PAPER / "visual_redesign" / "qa_final"
OUT.mkdir(parents=True, exist_ok=True)
QA.mkdir(parents=True, exist_ok=True)
core.OUT = OUT
core.QA = QA

INK = core.INK
NAVY = core.NAVY
TEAL = core.TEAL
ORANGE = core.ORANGE
GREEN = core.GREEN
FORMAL = core.FORMAL
REHEARSAL = core.REHEARSAL
OFFLINE = core.OFFLINE
HISTORY = core.HISTORY
GRID = core.GRID
PALE_BLUE = core.PALE_BLUE
PALE_ORANGE = core.PALE_ORANGE


def export(fig: plt.Figure, stem: str) -> None:
    core.export(fig, stem)


def arrow(ax: plt.Axes, start, end, *, color=INK, lw=0.85) -> None:
    ax.annotate(
        "",
        xy=end,
        xytext=start,
        arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, mutation_scale=8, shrinkA=2, shrinkB=2),
    )


def figure_01() -> None:
    fig, ax = plt.subplots(figsize=(7.15, 2.62))
    ax.set(xlim=(0, 1), ylim=(0, 1))
    ax.axis("off")
    xs = np.linspace(0.10, 0.90, 4)
    titles = ["单源几何定位", "鲁棒主动选点", "多源主动清除", "定向源联合调度"]
    complexity = ["几何不确定性", "接收半径未知", "多频道搜索", "方向盲区 + 调度"]
    rows = [
        ("观测", ["±1° 测向", "测向 + 有信号", "逐频道响应", "定向/全向响应"]),
        ("状态", ["凸可行域", "半径—位置集合", "频道可行域", "实时混合任务池"]),
        ("决策", ["直径与 MEC", "min–max 选点", "无线/光学择优", "原子动作重规划"]),
        ("输出", ["定位区域", "第二测站", "逐源清除", "全部源清除"]),
    ]
    ax.plot([0.06, 0.94], [0.83, 0.83], color=GRID, lw=0.9)
    for i, (x, title, comp) in enumerate(zip(xs, titles, complexity), 1):
        ax.scatter(x, 0.83, s=42, facecolor="white", edgecolor=NAVY, lw=1.4, zorder=3)
        ax.text(x, 0.91, f"Q{i}", ha="center", color=NAVY, fontsize=9.5, weight="bold")
        ax.text(x, 0.745, title, ha="center", fontsize=8.1, weight="bold", color=INK)
        ax.text(x, 0.12, comp, ha="center", fontsize=7.0, color=ORANGE if i > 1 else OFFLINE)
        if i < 4:
            arrow(ax, (x + 0.045, 0.83), (xs[i] - 0.045, 0.83), color=ORANGE, lw=1.0)
    y_positions = [0.62, 0.49, 0.36, 0.23]
    for (role, values), y in zip(rows, y_positions):
        ax.text(0.012, y, role, ha="left", va="center", fontsize=7.1, color=OFFLINE)
        for x, value in zip(xs, values):
            ax.text(x, y, value, ha="center", va="center", fontsize=7.2, color=INK)
    for x in (0.235, 0.50, 0.765):
        ax.plot([x, x], [0.20, 0.74], color=GRID, lw=0.65)
    ax.text(0.50, 0.025, "复杂度逐级增加；同一主线始终以保守可行集合维持一致性", ha="center", color=FORMAL, fontsize=7.3)
    fig.subplots_adjust(left=0.02, right=0.99, top=0.97, bottom=0.03)
    export(fig, "fig01_unified_framework")


def unit(angle: float) -> np.ndarray:
    return np.array([math.cos(angle), math.sin(angle)], dtype=float)


def wedge(station, theta, delta, length=5000) -> Polygon:
    station = np.asarray(station, dtype=float)
    return Polygon([station, station + length * unit(theta - delta), station + length * unit(theta + delta)])


def fill_geom(ax: plt.Axes, geom, **kwargs) -> None:
    if geom.is_empty:
        return
    geoms = [geom] if geom.geom_type == "Polygon" else list(geom.geoms)
    for item in geoms:
        x, y = item.exterior.xy
        ax.fill(x, y, **kwargs)


def figure_02() -> None:
    fig, (ax, zoom) = plt.subplots(1, 2, figsize=(7.15, 3.35), layout="constrained")
    target = Point(0, 0).buffer(1800, resolution=256)
    true = np.array([360.0, 260.0])
    stations = [np.array([-1180.0, -500.0]), np.array([1280.0, -760.0]), np.array([-120.0, 1450.0])]
    errors = np.radians([0.55, -0.45, 0.70])
    delta = math.radians(1)
    current = target
    for i, (station, error) in enumerate(zip(stations, errors), 1):
        theta = math.atan2(true[1] - station[1], true[0] - station[0]) + error
        sector = wedge(station, theta, delta, 4300).intersection(target)
        current = current.intersection(sector)
        fill_geom(ax, sector, color=TEAL, alpha=0.055, zorder=1)
        for angle, width, style in ((theta - delta, 0.72, (0, (3, 2))), (theta, 1.0, "-"), (theta + delta, 0.72, (0, (3, 2)))):
            end = station + 3300 * unit(angle)
            ax.plot([station[0], end[0]], [station[1], end[1]], color=TEAL, lw=width, ls=style, alpha=0.74, zorder=2)
        marker = ["o", "s", "^"][i - 1]
        ax.scatter(*station, s=30, marker=marker, facecolor="white", edgecolor=INK, lw=1.0, zorder=5)
        ax.text(station[0] + 55, station[1] + 55, f"$S_{i}$", color=INK, weight="bold")
    t = np.linspace(0, 2 * np.pi, 500)
    ax.plot(1800 * np.cos(t), 1800 * np.sin(t), color=GRID, lw=0.8, zorder=0)
    fill_geom(ax, current, color=PALE_BLUE, alpha=0.96, zorder=3)
    xy = np.asarray(current.exterior.coords)
    ax.plot(xy[:, 0], xy[:, 1], color=NAVY, lw=1.75, zorder=4)
    centroid = np.array([current.centroid.x, current.centroid.y])
    ax.annotate("硬可行域 $P$", centroid, xytext=(28, 20), textcoords="offset points", color=NAVY, weight="bold", arrowprops=dict(arrowstyle="-", color=NAVY, lw=0.75))
    vertices = xy[:-1]
    distances = np.linalg.norm(vertices[:, None, :] - vertices[None, :, :], axis=2)
    ia, ib = np.unravel_index(np.argmax(distances), distances.shape)
    a, b = vertices[ia], vertices[ib]
    fill_geom(zoom, current, color=PALE_BLUE)
    zoom.plot(xy[:, 0], xy[:, 1], color=NAVY, lw=1.6)
    zoom.plot([a[0], b[0]], [a[1], b[1]], color=ORANGE, lw=1.4)
    zoom.scatter([a[0], b[0]], [a[1], b[1]], s=28, facecolor="white", edgecolor=ORANGE, zorder=5)
    for label, p, offset in [("$A$", a, (-12, -14)), ("$B$", b, (7, 8))]:
        zoom.annotate(label, p, xytext=offset, textcoords="offset points", color=ORANGE)
    zoom.annotate("$D(P)$", (a+b)/2, xytext=(12, -16), textcoords="offset points", color=ORANGE)
    lo, hi = vertices.min(axis=0), vertices.max(axis=0)
    pad = max(hi-lo)*0.30
    zoom.set(xlim=(lo[0]-pad, hi[0]+pad), ylim=(lo[1]-pad, hi[1]+pad), xlabel="$x$ / m", ylabel="$y$ / m")
    zoom.set_aspect("equal")
    zoom.spines[["top", "right"]].set_visible(False)
    ax.set_title("(a) 测站与有界测向", loc="left", fontsize=9)
    zoom.set_title("(b) 同一可行域的局部放大", loc="left", fontsize=9)
    ax.annotate(r"边界：$\theta_i\pm1^\circ$", xy=(1010, -455), xytext=(1190, -180), color=TEAL, arrowprops=dict(arrowstyle="-", color=TEAL, lw=0.75))
    ax.set(xlim=(-1900, 1900), ylim=(-1900, 1900), xlabel="$x$ / m", ylabel="$y$ / m")
    ax.set_aspect("equal")
    ax.spines[["top", "right"]].set_visible(False)
    export(fig, "fig02_q1_wedge_intersection")


def figure_04() -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.15, 2.34), sharex=True, sharey=True)
    titles = [("(a)", "源位置可行域 $F_1$"), ("(b)", "保守站位域 $C_{\mathrm{sig}}$"), ("(c)", "最大站位域 $C_{\mathrm{sig}}^*$")]
    source_region = np.array([[0.0, 0.0], [1.46, 0.23], [1.42, -0.23]])
    conservative = Point(0.74, 0.0).buffer(0.62, resolution=128).intersection(Point(1.24, 0.0).buffer(0.62, resolution=128))
    maximal = Point(0.58, 0.0).buffer(0.86, resolution=128).intersection(Point(1.10, 0.0).buffer(0.86, resolution=128))
    for ax, (label, title) in zip(axes, titles):
        core.panel_label(ax, label, title)
        ax.set(xlim=(-0.15, 1.72), ylim=(-0.92, 0.92))
        ax.set_aspect("equal")
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color(GRID)
        ax.set_xticks([0, 0.8, 1.6])
        ax.set_yticks([-0.8, 0, 0.8])
        ax.tick_params(labelsize=6.2, colors=OFFLINE, length=2)
    axes[0].add_patch(MplPolygon(source_region, closed=True, facecolor=PALE_BLUE, edgecolor=NAVY, lw=1.45))
    axes[0].scatter(0, 0, marker="s", s=27, facecolor=INK, edgecolor="white", lw=0.5)
    axes[0].text(0.06, -0.15, "$S_1$", color=INK)
    axes[0].text(0.88, 0.34, "误差相容的源位置", color=NAVY, fontsize=6.8, ha="center")
    for ax in axes[1:]:
        ax.plot(source_region[:, 0], source_region[:, 1], color=HISTORY, lw=0.85, ls=(0, (3, 2)))
        ax.text(1.26, 0.31, "$F_1$（参照）", color=HISTORY, fontsize=6.3, ha="center")
    fill_geom(axes[1], conservative, color=PALE_ORANGE, alpha=0.95, zorder=2)
    x, y = conservative.exterior.xy
    axes[1].plot(x, y, color=ORANGE, lw=1.45)
    axes[1].text(0.86, 0, "$C_{\mathrm{sig}}$", color=ORANGE, weight="bold", ha="center")
    fill_geom(axes[2], maximal, color=PALE_BLUE, alpha=0.95, zorder=1)
    x, y = maximal.exterior.xy
    axes[2].plot(x, y, color=NAVY, lw=1.45)
    fill_geom(axes[2], conservative, facecolor="none", edgecolor=ORANGE, hatch="////", linewidth=1.0, zorder=2)
    axes[2].text(0.83, 0.04, "$C_{\mathrm{sig}}^*$", color=NAVY, weight="bold", ha="center")
    fig.text(0.5, 0.035, r"源域与机器狗站位域是不同对象；保守构造满足 $C_{\mathrm{sig}}\subset C_{\mathrm{sig}}^*$。", ha="center", fontsize=7.0, color=INK)
    fig.subplots_adjust(left=0.055, right=0.99, top=0.82, bottom=0.21, wspace=0.12)
    export(fig, "fig04_q2_guaranteed_signal_regions")


def load_heatmap() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    raw = np.genfromtxt(ASSETS / "q2_heatmap_values.csv", delimiter=",", names=True, filling_values=np.nan)
    names = raw.dtype.names
    xs = np.array([float(name.replace("f", "")) if name.startswith("f") else float(name) for name in names[1:]])
    ys = raw[names[0]].astype(float)
    z = np.column_stack([raw[name] for name in names[1:]]).astype(float)
    return xs, ys, z


def figure_05() -> None:
    xs, ys, z = load_heatmap()
    points, values = [], []
    for iy, y in enumerate(ys):
        for ix, x in enumerate(xs):
            if np.isfinite(z[iy, ix]):
                for sign in ({0} if y == 0 else {-1, 1}):
                    points.append((x, sign * y))
                    values.append(z[iy, ix])
    points, values = np.asarray(points), np.asarray(values)
    gx, gy = np.linspace(180, 1020, 280), np.linspace(-820, 820, 360)
    X, Y = np.meshgrid(gx, gy)
    Z = griddata(points, values, (X, Y), method="linear")
    finite = Z[np.isfinite(Z)]
    zmin = float(finite.min())
    levels = [zmin * 1.01, zmin * 1.05]
    index = np.nanargmin(Z)
    iy, ix = np.unravel_index(index, Z.shape)
    optimum = (X[iy, ix], Y[iy, ix])
    masked = np.ma.masked_invalid(Z)
    norm = mpl.colors.Normalize(vmin=float(finite.min()), vmax=float(finite.max()))
    fig, (ax, zoom) = plt.subplots(
        1, 2, figsize=(7.15, 3.35),
        gridspec_kw={"width_ratios": [1.58, 1.0]},
        layout="constrained",
    )
    image = ax.pcolormesh(
        X, Y, masked, shading="auto", cmap=mpl.colormaps["cividis"], norm=norm,
        rasterized=False, edgecolors="face", linewidth=0.08, antialiased=False,
    )
    contour_style = dict(
        levels=levels, colors=[GREEN, ORANGE],
        linestyles=["-", (0, (4, 2))], linewidths=[1.35, 1.35],
    )
    ax.contour(X, Y, Z, **contour_style)
    ax.scatter(*optimum, marker="*", s=88, facecolor=ORANGE, edgecolor="white", lw=0.7, zorder=5)
    ax.annotate(
        "$x^*$", optimum, xytext=(-24, 11), textcoords="offset points",
        color=ORANGE, weight="bold",
    )
    zoom_dx, zoom_dy = 105, 125
    ax.add_patch(Rectangle(
        (optimum[0] - zoom_dx, optimum[1] - zoom_dy),
        2 * zoom_dx, 2 * zoom_dy,
        fill=False, edgecolor=INK, lw=0.8, ls=(0, (2, 2)),
    ))

    zoom.contourf(
        X, Y, masked, levels=np.linspace(float(finite.min()), float(finite.max()), 64),
        cmap=mpl.colormaps["cividis"], norm=norm, antialiased=False,
    )
    zoom.contour(X, Y, Z, **contour_style)
    zoom.scatter(*optimum, marker="*", s=76, facecolor=ORANGE, edgecolor="white", lw=0.7, zorder=5)
    zoom.annotate(
        "$x^*$", optimum, xytext=(-16, -17), textcoords="offset points",
        color=ORANGE, weight="bold", ha="right",
    )
    zoom.set(
        xlim=(optimum[0] - zoom_dx, optimum[0] + zoom_dx),
        ylim=(optimum[1] - zoom_dy, optimum[1] + zoom_dy),
        xlabel="中心线偏移 / m",
    )

    ax.set(
        xlabel="第二测站沿中心测向线偏移 / m",
        ylabel="横向偏移 / m",
    )
    ax.set_title("(a) 全部保证接收候选域", loc="left", fontsize=8.5, weight="bold")
    zoom.set_title("(b) 稳定低谷的局部放大", loc="left", fontsize=8.5, weight="bold")
    zoom.annotate(
        "1% 近优边界", xy=(790, -585), xytext=(830, -610),
        color=GREEN, fontsize=6.8,
        arrowprops=dict(arrowstyle="-", color=GREEN, lw=0.7),
    )
    zoom.annotate(
        "5% 近优边界", xy=(748, -625), xytext=(805, -675),
        color=ORANGE, fontsize=6.8,
        arrowprops=dict(arrowstyle="-", color=ORANGE, lw=0.7),
    )
    for current_ax in (ax, zoom):
        current_ax.spines[["top", "right"]].set_visible(False)
    colorbar = fig.colorbar(image, ax=[ax, zoom], pad=0.02, shrink=0.94)
    colorbar.set_label("最坏定位直径 $J_D(x)$ / m")
    fig.suptitle("代表性数值算例", x=0.08, ha="left", fontsize=9.0)
    export(fig, "fig05_q2_minmax_heatmap")


def figure_06() -> None:
    fig, ax = plt.subplots(figsize=(7.15, 2.48))
    ax.set(xlim=(0, 1), ylim=(0, 1))
    ax.axis("off")
    nodes = [
        (0.07, "实际观测", "direction / no_signal"),
        (0.24, "更新硬可行域", "$F_c \leftarrow F_c\cap H$"),
        (0.43, "估计剩余成本", "真实时间单位"),
        (0.62, "动作评分", "有限视野预测"),
        (0.82, "执行一个动作", "测向或覆盖"),
        (0.95, "清除/继续", "结果回写"),
    ]
    ax.plot([nodes[0][0], nodes[-1][0]], [0.60, 0.60], color=GRID, lw=1.0)
    for i, (x, title, subtitle) in enumerate(nodes):
        color = NAVY if i < 2 or i == 5 else ORANGE
        ax.scatter(x, 0.60, s=43, facecolor="white", edgecolor=color, lw=1.5, zorder=3)
        ax.text(x, 0.76, title, ha="center", fontsize=8.3, weight="bold", color=color)
        ax.text(x, 0.43, subtitle, ha="center", fontsize=7.2, color=INK)
        if i < len(nodes) - 1:
            arrow(ax, (x + 0.025, 0.60), (nodes[i + 1][0] - 0.025, 0.60), color=INK, lw=0.75)
    ax.plot([0.60, 0.60], [0.12, 0.31], color=GRID, lw=0.8)
    ax.plot([0.49, 0.71], [0.31, 0.31], color=GRID, lw=0.8)
    ax.text(0.49, 0.20, "继续无线测向", ha="center", color=TEAL, fontsize=7.1)
    ax.text(0.71, 0.20, "带状光学覆盖", ha="center", color=GREEN, fontsize=7.1)
    ax.text(0.60, 0.055, "比较下一步之后的预计剩余虚拟时间，选择较小者", ha="center", color=FORMAL, fontsize=7.2)
    fig.subplots_adjust(left=0.02, right=0.99, top=0.98, bottom=0.02)
    export(fig, "fig06_q3_state_machine")


def figure_08() -> None:
    """Q3 main-text ablation: keep only the benchmark and the final model."""
    with (TABLES / "figure_q3_performance.csv").open(encoding="utf-8-sig", newline="") as fh:
        all_rows = list(csv.DictReader(fh))
    rows = [row for row in all_rows if row["variant"] in {"Production", "Final R2"}]
    order = {"Production": 0, "Final R2": 1}
    rows.sort(key=lambda row: order[row["variant"]])
    labels = {"Production": "基线策略", "Final R2": "本文最终模型"}
    metrics = [
        ("aggregate_s_source", "加权平均定位清除时间 / (s·源$^{-1}$)", "{:.1f}"),
        ("movement_m_case", "平均移动距离 / (m·局$^{-1}$)", "{:.0f}"),
        ("measure_case", "平均检测次数 / 局", "{:.1f}"),
        ("failed_clear_case", "未命中清除尝试 / 局", "{:.1f}"),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(7.15, 4.05))
    for ax, (key, title, fmt), letter in zip(axes.flat, metrics, "abcd"):
        baseline = float(rows[0][key])
        final = float(rows[1][key])
        values = [baseline, final]
        lo, hi = min(values), max(values)
        span = max(hi - lo, abs(baseline) * 0.04, 1.0)
        margin = span * 0.28
        ax.plot(values, [0, 1], color=GRID, lw=1.2, zorder=1)
        ax.scatter(baseline, 0, s=42, marker="o", facecolor="white", edgecolor=OFFLINE, lw=1.3, zorder=3)
        ax.scatter(final, 1, s=46, marker="D", facecolor=NAVY, edgecolor=NAVY, lw=1.1, zorder=4)
        ax.text(baseline + 0.025 * span, 0, fmt.format(baseline), va="center", fontsize=7.0, color=OFFLINE)
        ax.text(final + 0.025 * span, 1, fmt.format(final), va="center", fontsize=7.1, color=NAVY, weight="bold")
        change = (final / baseline - 1.0) * 100.0
        ax.text(
            0.98,
            0.92,
            f"相对基线 {change:+.1f}%",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=6.7,
            color=ORANGE if change < 0 else INK,
            weight="bold",
        )
        ax.set_yticks([0, 1], [labels[rows[0]["variant"]], labels[rows[1]["variant"]]])
        ax.set_xlim(lo - margin, hi + margin * 1.75)
        ax.set_title(f"({letter})  {title}", loc="left", fontsize=8.0, weight="bold")
        ax.grid(axis="x", color=GRID, lw=0.5, zorder=0)
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.tick_params(axis="y", length=0)
    fig.text(
        0.5,
        0.018,
        "相同 120 个离线场景；仅比较基线策略与本文最终模型，中间研发版本不进入正文性能链。",
        ha="center",
        fontsize=6.8,
        color=OFFLINE,
    )
    fig.subplots_adjust(left=0.19, right=0.99, top=0.92, bottom=0.13, hspace=0.46, wspace=0.34)
    export(fig, "fig08_q3_performance_comparison")

def figure_09() -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.15, 2.62))
    titles = [("(a)", "频道无活动源"), ("(b)", "超出接收半径"), ("(c)", "位于定向盲区")]
    for ax, (label, title) in zip(axes, titles):
        core.panel_label(ax, label, title)
        ax.set(xlim=(-1.08, 1.08), ylim=(-1.0, 1.0))
        ax.set_aspect("equal")
        ax.axis("off")
        ax.scatter(0.72, -0.48, s=34, marker="s", facecolor="white", edgecolor=NAVY, lw=1.2)
        ax.text(0.72, -0.72, "机器狗", ha="center", fontsize=6.7, color=NAVY)
    axes[0].plot([-0.72, 0.50], [0.35, 0.35], color=GRID, lw=1.0)
    axes[0].text(-0.12, 0.47, "无发射源", ha="center", color=OFFLINE, fontsize=7.0)
    axes[1].scatter(-0.42, 0.18, s=32, marker="x", color=ORANGE, lw=1.4)
    axes[1].add_patch(Circle((-0.42, 0.18), 0.58, fill=False, edgecolor=GREEN, lw=1.1))
    axes[1].plot([-0.42, 0.72], [0.18, -0.48], color=OFFLINE, lw=0.85, ls=(0, (3, 2)))
    axes[1].text(0.12, -0.05, r"$d>\rho$", color=INK, fontsize=7.2)
    axes[2].scatter(-0.42, 0.18, s=32, marker="x", color=ORANGE, lw=1.4)
    axes[2].add_patch(Circle((-0.42, 0.18), 0.95, fill=False, edgecolor=GREEN, lw=0.75, ls=(0, (3, 2))))
    axes[2].add_patch(Wedge((-0.42, 0.18), 0.95, 25, 205, facecolor=PALE_ORANGE, edgecolor=ORANGE, lw=1.0))
    axes[2].plot([-0.42, 0.72], [0.18, -0.48], color=OFFLINE, lw=0.85, ls=(0, (3, 2)))
    axes[2].text(0.08, -0.08, r"$d\leq\rho$", color=INK, fontsize=7.2)
    for ax in axes:
        ax.text(0.0, -0.92, "返回 no_signal", ha="center", color=ORANGE, fontsize=7.2, weight="bold")
    fig.text(0.5, 0.018, r"同一响应对应三种物理机制：$\mathtt{no\_signal}\ \not\Rightarrow\ $源位置距离排除。", ha="center", color=FORMAL, fontsize=8.0, weight="bold")
    fig.subplots_adjust(left=0.02, right=0.99, top=0.82, bottom=0.19, wspace=0.05)
    export(fig, "fig09_q4_nosignal_ambiguity")


def route(ax: plt.Axes, points, *, color, style="-", alpha=1.0) -> None:
    for start, end in zip(points[:-1], points[1:]):
        ax.plot([start[0], end[0]], [start[1], end[1]], color=color, ls=style, lw=1.1, alpha=alpha)
        if style == "-":
            arrow(ax, start, end, color=color, lw=0.75)


def _task_map(ax: plt.Axes, title: str, robot, scans, sources, path, old_path=None) -> None:
    ax.set(xlim=(0, 5), ylim=(0, 4.2))
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.spines[:].set_visible(False)
    ax.set_title(title, loc="left", fontsize=8.1, weight="bold")
    if old_path:
        route(ax, old_path, color=HISTORY, style=(0, (3, 2)), alpha=0.8)
    route(ax, path, color=FORMAL)
    for index, point in enumerate(scans, 1):
        ax.scatter(*point, s=30, marker="o", facecolor="white", edgecolor=NAVY, lw=1.1)
        ax.text(point[0], point[1] + 0.24, f"扫描{index}", ha="center", fontsize=6.2, color=NAVY)
    for channel, point in sources:
        ax.scatter(*point, s=34, marker="^", facecolor=ORANGE, edgecolor="white", lw=0.5)
        ax.text(point[0], point[1] - 0.30, f"源任务 {channel}", ha="center", fontsize=6.2, color=ORANGE)
    ax.scatter(*robot, s=36, marker="s", facecolor=INK, edgecolor="white", lw=0.5)
    ax.text(robot[0] + 0.15, robot[1] - 0.25, "当前位置", fontsize=6.2, color=INK)


def figure_10() -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.15, 2.65), gridspec_kw={"width_ratios": [1, 0.22, 1]})
    robot = (0.55, 0.55)
    scans = [(0.75, 3.40), (2.55, 3.75), (4.25, 3.12)]
    sources = [("c_4", (1.72, 1.48)), ("c_{11}", (3.95, 0.78))]
    old = [robot, sources[0][1], scans[0], scans[1], sources[1][1], scans[2]]
    _task_map(axes[0], "$t$：扫描与源任务共存", robot, scans, sources, old)
    axes[1].axis("off")
    arrow(axes[1], (0.08, 0.55), (0.92, 0.55), color=ORANGE, lw=1.15)
    axes[1].text(0.50, 0.66, "只执行\n首个原子动作", ha="center", va="bottom", color=ORANGE, fontsize=7.0, weight="bold")
    axes[1].text(0.50, 0.34, "观测→更新\n→全局重规划", ha="center", va="top", color=INK, fontsize=6.5)
    new_robot = sources[0][1]
    new_sources = [("c_{11}", sources[1][1])]
    new = [new_robot, scans[0], scans[1], sources[1][1], scans[2]]
    _task_map(axes[2], "$t+1$：新路线替代旧路线", new_robot, scans, new_sources, new, old_path=old)
    fig.text(0.5, 0.018, r"$\mathcal{J}_t=\mathcal{J}_{\mathrm{scan},t}\cup\mathcal{J}_{\mathrm{source},t}$；多初值局部路径改进只负责排序，不改变保守状态。", ha="center", fontsize=6.8, color=INK)
    fig.subplots_adjust(left=0.02, right=0.99, top=0.88, bottom=0.17, wspace=0.04)
    export(fig, "fig10_q4_mixed_rolling_schedule")


def figure_11() -> None:
    """Two-layer evidence figure: offline benchmark + official formal tests only."""
    q3_off = json.loads((ASSETS / "q3_breakthrough_r2_120.json").read_text(encoding="utf-8"))
    q4_off = json.loads((ASSETS / "sandbox_exact_q4_100.json").read_text(encoding="utf-8"))["Q4"]
    formal = json.loads((ASSETS / "formal_results_20260912.json").read_text(encoding="utf-8"))
    data = {
        "Q3": {
            "offline": np.asarray([float(r["s_source"]) for r in q3_off["rows"]["r2"]], dtype=float),
            "offline_mean": float(q3_off["summary"]["r2"]["aggregate_s_source"]),
            "formal": [
                (int(r["cleared_sources"]), float(r["average_localization_clear_time_s"]))
                for r in formal["Q3"]["runs"]
            ],
            "formal_mean": float(formal["Q3"]["aggregate"]["aggregate_s_per_source"]),
        },
        "Q4": {
            "offline": np.asarray([float(r["s_source"]) for r in q4_off["rows"]["FULL"]], dtype=float),
            "offline_mean": float(q4_off["summary"]["FULL"]["aggregate_s_source"]),
            "formal": [
                (int(r["cleared_sources"]), float(r["average_localization_clear_time_s"]))
                for r in formal["Q4"]["runs"]
            ],
            "formal_mean": float(formal["Q4"]["aggregate"]["aggregate_s_per_source"]),
        },
    }
    fig, axes = plt.subplots(1, 2, figsize=(7.15, 3.15))
    for ax, question in zip(axes, ("Q3", "Q4")):
        payload = data[question]
        rng = np.random.default_rng(20260920 if question == "Q3" else 20260921)
        offline = payload["offline"]
        jitter = rng.uniform(-0.18, 0.18, size=len(offline))
        ax.scatter(jitter, offline, s=10, facecolors="none", edgecolors=OFFLINE, alpha=0.36, lw=0.55, zorder=1)
        ax.hlines(payload["offline_mean"], -0.27, 0.27, color=OFFLINE, lw=2.0, zorder=3)
        ax.text(0.30, payload["offline_mean"], f"加权 {payload['offline_mean']:.1f}", va="center", color=OFFLINE, fontsize=7.0)

        offsets = [-0.14, 0.0, 0.14]
        annotation_offsets = [(0, 9), (-12, -15), (14, -15)] if question == "Q3" else [(0, 9), (-11, -15), (11, 9)]
        for idx, ((sources, value), dx) in enumerate(zip(payload["formal"], offsets)):
            x = 1.0 + dx
            ax.scatter(x, value, s=45, marker="D", facecolor=NAVY, edgecolor=NAVY, lw=1.0, zorder=4)
            ox, oy = annotation_offsets[idx]
            ax.annotate(
                f"{sources}源 · {value:.1f}",
                (x, value),
                xytext=(ox, oy),
                textcoords="offset points",
                ha="center",
                va="bottom" if oy > 0 else "top",
                fontsize=6.6,
                color=NAVY,
            )
        ax.hlines(payload["formal_mean"], 0.70, 1.30, color=NAVY, lw=2.5, zorder=3)
        ax.text(1.33, payload["formal_mean"], f"加权 {payload['formal_mean']:.1f}", va="center", color=NAVY, fontsize=7.1, weight="bold")

        vals = np.concatenate([offline, np.asarray([v for _, v in payload["formal"]])])
        margin = max(18.0, 0.12 * (vals.max() - vals.min()))
        ax.set_ylim(vals.min() - margin, vals.max() + margin)
        ax.set_xlim(-0.42, 1.62)
        ax.set_xticks([0, 1], ["离线验证", "官方正式"])
        ax.set_ylabel("虚拟时间 / (s·源$^{-1}$)")
        ax.text(-0.01, 1.09, question, transform=ax.transAxes, ha="left", va="bottom", fontsize=10, weight="bold", color=NAVY)
        ax.text(0.0, 1.025, f"离线：{len(offline)} 个固定场景", transform=ax.transAxes, color=OFFLINE, fontsize=6.7, va="bottom")
        ax.text(1.0, 1.025, "3/3 正式测试完整清除", transform=ax.transAxes, color=NAVY, fontsize=6.7, va="bottom", ha="right", weight="bold")
        ax.grid(axis="y", color=GRID, lw=0.5, zorder=0)
        ax.axvline(0.5, color=GRID, lw=0.7, ls=(0, (2, 3)))
        ax.spines[["top", "right"]].set_visible(False)
    fig.subplots_adjust(left=0.08, right=0.99, top=0.82, bottom=0.20, wspace=0.30)
    fig.text(
        0.5,
        0.035,
        "浅灰空心点为离线固定场景；深蓝菱形为三次官方正式测试。横线均为按清除源数加权的汇总值，正式测试全部展示。",
        ha="center",
        fontsize=6.7,
        color=INK,
    )
    export(fig, "fig11_offline_formal_validation")

    evidence = {
        "figure": "fig11_offline_formal_validation",
        "metric": "virtual seconds per cleared source",
        "layers": ["offline", "formal"],
        "notes": "Official rehearsal is retained only in supporting evidence and is intentionally excluded from the main-text performance comparison.",
        "formal_complete": {"Q3": True, "Q4": True},
    }
    (OUT / "fig11_evidence_manifest.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")

def write_evidence_manifest() -> None:
    source_paths = {
        "fig05": ASSETS / "q2_heatmap_values.csv",
        "fig08": TABLES / "figure_q3_performance.csv",
        "fig11": OUT / "fig11_evidence_manifest.json",
    }
    payload = {
        "figures": {
            key: {"source": str(path.relative_to(PAPER.parent)), "bytes": path.stat().st_size, "sha256": core.sha256(path)}
            for key, path in source_paths.items()
        },
        "notes": {
            "fig05": "representative numerical example; not an official fixed case",
            "fig08": "same-seed 120-case offline ablation only",
            "fig11": "main text shows offline and formal layers only; rehearsal is retained in support files; no formal run excluded",
        },
    }
    (OUT / "figure_data_manifest.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def contact_sheet() -> None:
    stems = [
        "fig01_unified_framework",
        "fig02_q1_wedge_intersection",
        "fig03_q1_diameter_circle_counterexample",
        "fig04_q2_guaranteed_signal_regions",
        "fig05_q2_minmax_heatmap",
        "fig06_q3_state_machine",
        "fig07_q3_feasible_region_evolution",
        "fig08_q3_performance_comparison",
        "fig09_q4_nosignal_ambiguity",
        "fig10_q4_mixed_rolling_schedule",
        "fig11_offline_formal_validation",
    ]
    fig, axes = plt.subplots(4, 3, figsize=(11.69, 14.8))
    for index, ax in enumerate(axes.flat):
        if index >= len(stems):
            ax.axis("off")
            continue
        stem = stems[index]
        ax.imshow(plt.imread(OUT / f"{stem}.png"))
        ax.set_title(f"Fig.{index + 1}", loc="left", fontsize=8.5, weight="bold")
        ax.axis("off")
    fig.suptitle("CUMCM 2026 B 题 · 最终视觉系统总览", fontsize=13, weight="bold", y=0.993)
    fig.subplots_adjust(left=0.015, right=0.985, top=0.965, bottom=0.015, hspace=0.20, wspace=0.05)
    fig.savefig(PAPER / "visual_redesign" / "ALL_FIGURES_CONTACT_SHEET.pdf", facecolor="white")
    fig.savefig(PAPER / "visual_redesign" / "ALL_FIGURES_CONTACT_SHEET.png", dpi=180, facecolor="white")
    plt.close(fig)


def main() -> None:
    figure_01()
    figure_02()
    core.figure_03()
    figure_04()
    figure_05()
    figure_06()
    core.figure_07()
    figure_08()
    figure_09()
    figure_10()
    figure_11()
    write_evidence_manifest()
    contact_sheet()
    print(f"Generated 11 redesigned figures in {OUT}")


if __name__ == "__main__":
    main()
