# Figure Evidence Ledger

| Figure | Purpose | Data or mathematical input | Generator | Evidence class | Exports |
|---|---|---|---|---|---|
| 1 | Four-question graphical abstract | Frozen Q1-Q4 method chain | Image 2.5 concept render, manually screened; original vector retained | Conceptual synthesis, no numerical evidence | PNG + original PDF/SVG/PNG |
| 2 | Q1 wedge intersection | Deterministic ±1° bearing wedges and 1800 m domain | `generate_all_figures.py` | Mathematical construction | PDF/SVG/PNG |
| 3 | Diameter-circle counterexample | Equilateral triangle, diameter D, MEC radius D/√3 | `generate_visual_concepts.py` | Exact counterexample | PDF/SVG/PNG |
| 4 | Q2 guaranteed-signal set | First positive observation and state-dependent radius lower bound | `generate_all_figures.py` | Mathematical construction | PDF/SVG/PNG |
| 5 | Q2 min-max field | `publication_assets/q2_heatmap_values.csv` | `generate_all_figures.py` | Representative numerical example | PDF/SVG/PNG |
| 6 | Q3 controller | Q3 hard-state update / heuristic action-score separation | Image 2.5 concept render, manually screened; original vector retained | Algorithm schematic, no numerical evidence | PNG + original PDF/SVG/PNG |
| 7 | Q3 feasible-set evolution | One synthetic source used consistently from t0 to t3 | `generate_visual_concepts.py` | Mechanism illustration | PDF/SVG/PNG |
| 8 | Q3 benchmark-vs-final ablation | `generated_tables/figure_q3_performance.csv`; main text filters to Production + Final R2 | `generate_all_figures.py` | Offline benchmark | PDF/SVG/PNG |
| 9 | Q4 `no_signal` ambiguity | Three response mechanisms | Image 2.5 concept render, manually screened; original vector retained | Semantic counterexample, no numerical evidence | PNG + original PDF/SVG/PNG |
| 10 | Mixed rolling scheduling | SCAN/SOURCE live pool and one-action replanning | Image 2.5 concept render, manually screened; original vector retained | Algorithm schematic, no numerical evidence | PNG + original PDF/SVG/PNG |
| 11 | Offline-to-formal evidence | Q3 120-case JSON, Q4 100-case JSON, frozen formal results | `generate_all_figures.py` | Offline + formal | PDF/SVG/PNG |

Fig.11 intentionally excludes rehearsal from the main-text comparison; rehearsal remains in supporting evidence. All three formal runs for Q3 and Q4 are shown.


Image 2.5 was deliberately not used for Figures 2, 4, 5, 8, or 11 because they encode exact geometry or measured numerical evidence. Trial renders for Figures 3 and 7 were also rejected from the paper after review because they introduced invented terrain/scale/context not present in the model; the exact vector versions remain authoritative.
