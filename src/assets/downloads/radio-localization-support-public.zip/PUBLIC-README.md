# Public supporting materials / 公开版支撑材料

2026 CUMCM Problem B: radio-interference localization and clearance.
2026 年高教社杯全国大学生数学建模竞赛 B 题：无线电干扰源定位与清除。

This public copy retains the supplied code, result tables, offline summaries,
figure/table evidence ledgers, and AI-use statement byte-for-byte.
Six encrypted .jlog files are omitted because their headers contain the team identifier.
References to those logs in the original documentation describe the private submission archive.
The original archive and original logs have not been modified.

公开版逐字节保留原有代码、结果表、离线汇总、图表证据索引及 AI 工具使用说明。
六份加密 .jlog 文件因文件头包含参赛队号而未纳入公开版。
原说明中提到的这些日志属于私有提交归档；原始压缩包与日志未作修改。

Results are retained submission outputs, not new runs. Offline benchmarks and
official simulator tests are separate evidence. No simulator is included here.
Some original figure scripts refer to publication_assets or generated_tables
paths from the author's working tree; map those inputs to 数据与结果 before use.
Official runners require the separate simulator and a runtime identifier;
downloading or extracting this package does not start them.

结果为提交时留存输出，本次发布未重新运行算法或官方测试。
离线基准与官方模拟器测试分别展示。此包不包含官方模拟器。
部分原始绘图脚本依赖原工作目录路径，使用前需对照“数据与结果”调整输入路径。
官方运行入口依赖另行提供的模拟器及运行标识；解压不会自动启动测试。

PUBLIC-MANIFEST.json records SHA-256 values for every retained original file.
