param([switch]$OpenBrowser)
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
Start-Process node -ArgumentList "server.js" -WorkingDirectory (Join-Path $root "backend")
Start-Process node -ArgumentList "local_frontend_server.js" -WorkingDirectory (Join-Path $root "frontend")
if ($OpenBrowser) { Start-Process "http://127.0.0.1:8010/" }