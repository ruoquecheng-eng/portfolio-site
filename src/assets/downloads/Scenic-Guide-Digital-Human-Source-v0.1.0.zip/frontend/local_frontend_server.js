const http = require("http");
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

const HOST = "0.0.0.0";
const PORT = Number(process.env.FRONTEND_PORT || 8010);
const FRONTEND_DIR = __dirname;
const BACKEND_DIR = path.resolve(__dirname, "..", "backend");
const BACKEND_HOST = "127.0.0.1";
const BACKEND_PORT = 8000;
const BACKEND_HEALTH_URL = `http://${BACKEND_HOST}:${BACKEND_PORT}/api/health`;
let backendStartLock = null;

function now() {
  return new Date().toISOString();
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".html") return "text/html; charset=utf-8";
  if (ext === ".js") return "application/javascript; charset=utf-8";
  if (ext === ".css") return "text/css; charset=utf-8";
  if (ext === ".json") return "application/json; charset=utf-8";
  if (ext === ".svg") return "image/svg+xml";
  if (ext === ".png") return "image/png";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".gif") return "image/gif";
  if (ext === ".webp") return "image/webp";
  if (ext === ".ico") return "image/x-icon";
  if (ext === ".mp3") return "audio/mpeg";
  if (ext === ".wav") return "audio/wav";
  return "application/octet-stream";
}

function cacheControlFor(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const rel = path.relative(FRONTEND_DIR, filePath).replace(/\\/g, "/");
  if (rel === "index.html") return "no-store, no-cache, must-revalidate";
  if (rel.startsWith("assets/")) return "public, max-age=31536000, immutable";
  if ([".js", ".css", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".moc3"].includes(ext)) {
    return "public, max-age=86400";
  }
  return "no-store, no-cache, must-revalidate";
}

function sendJson(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
  });
  res.end(JSON.stringify(body));
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms || 0))));
}

function checkBackendHealth(timeoutMs = 1200) {
  return new Promise((resolve) => {
    const req = http.get(BACKEND_HEALTH_URL, { timeout: timeoutMs }, (resp) => {
      let raw = "";
      resp.on("data", (c) => (raw += String(c || "")));
      resp.on("end", () => {
        try {
          const data = JSON.parse(raw || "{}");
          resolve(Boolean(resp.statusCode === 200 && String(data?.status || "").toLowerCase() === "ok"));
        } catch {
          resolve(false);
        }
      });
    });
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
    req.on("error", () => resolve(false));
  });
}

async function startBackendIfNeeded() {
  const already = await checkBackendHealth(800);
  if (already) {
    return { ok: true, started: false, reason: "already_running" };
  }
  if (backendStartLock) {
    return await backendStartLock;
  }
  backendStartLock = (async () => {
    try {
      const already2 = await checkBackendHealth(800);
      if (already2) {
        return { ok: true, started: false, reason: "already_running" };
      }
      try {
        const outFd = fs.openSync(path.join(BACKEND_DIR, "_node.out.log"), "a");
        const errFd = fs.openSync(path.join(BACKEND_DIR, "_node.err.log"), "a");
        const child = spawn("node", ["server.js"], {
          cwd: BACKEND_DIR,
          detached: true,
          windowsHide: true,
          stdio: ["ignore", outFd, errFd]
        });
        child.unref();
      } catch (err) {
        return { ok: false, started: false, reason: "spawn_failed", detail: String(err?.message || err) };
      }

      for (let i = 0; i < 28; i += 1) {
        const healthy = await checkBackendHealth(900);
        if (healthy) return { ok: true, started: true, reason: "started" };
        await sleep(250);
      }
      return { ok: false, started: true, reason: "timeout_waiting_health" };
    } finally {
      backendStartLock = null;
    }
  })();
  return await backendStartLock;
}

async function proxyApiRequest(req, res) {
  const start = await startBackendIfNeeded();
  if (!start?.ok) {
    return sendJson(res, 503, {
      ok: false,
      detail: start?.detail || start?.reason || "backend_unavailable"
    });
  }
  const proxy = http.request(
    {
      host: BACKEND_HOST,
      port: BACKEND_PORT,
      path: req.url,
      method: req.method,
      headers: {
        ...req.headers,
        host: `${BACKEND_HOST}:${BACKEND_PORT}`
      }
    },
    (backendResp) => {
      const headers = { ...backendResp.headers, "cache-control": "no-store" };
      res.writeHead(Number(backendResp.statusCode || 502), headers);
      backendResp.pipe(res);
    }
  );
  proxy.on("error", (err) => {
    if (!res.headersSent) {
      sendJson(res, 502, { ok: false, detail: String(err?.message || err || "proxy_error") });
      return;
    }
    try { res.end(); } catch (e) { /* ignore */ }
  });
  req.pipe(proxy);
}

async function handleLocalApi(req, res) {
  const url = String(req.url || "");
  if (req.method === "GET" && url === "/local/status") {
    const healthy = await checkBackendHealth(900);
    return sendJson(res, 200, {
      ok: true,
      backend_healthy: healthy,
      now: now()
    });
  }
  if (req.method === "POST" && url === "/local/start-backend") {
    const result = await startBackendIfNeeded();
    return sendJson(res, result.ok ? 200 : 503, {
      ok: result.ok,
      started: result.started,
      reason: result.reason,
      detail: result.detail || "",
      now: now()
    });
  }
  return sendJson(res, 404, { ok: false, detail: "not found" });
}

function serveStatic(req, res) {
  const reqPathRaw = decodeURIComponent(String(req.url || "/").split("?")[0]);
  const normalizedReqPath = reqPathRaw.startsWith("/static/")
    ? reqPathRaw.replace(/^\/static/, "")
    : reqPathRaw;
  const reqPath = normalizedReqPath === "/" ? "/index.html" : normalizedReqPath;
  const safePath = path.normalize(reqPath).replace(/^(\.\.[/\\])+/, "");
  const fullPath = path.join(FRONTEND_DIR, safePath);
  if (!fullPath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }
  fs.stat(fullPath, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404);
      res.end("Not Found");
      return;
    }
    res.writeHead(200, {
      "Content-Type": contentType(fullPath),
      "Cache-Control": cacheControlFor(fullPath)
    });
    fs.createReadStream(fullPath).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  const url = String(req.url || "");
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Cache-Control": "no-store"
    });
    res.end();
    return;
  }
  if (url.startsWith("/local/")) {
    return handleLocalApi(req, res);
  }
  if (url.startsWith("/api/")) {
    return proxyApiRequest(req, res);
  }
  return serveStatic(req, res);
});

server.listen(PORT, HOST, () => {
  console.log(`[frontend-local] started at http://${HOST}:${PORT}`);
  startBackendIfNeeded()
    .then((result) => console.log(`[frontend-local] backend auto-start: ${JSON.stringify(result)}`))
    .catch((err) => console.warn(`[frontend-local] backend auto-start failed: ${err?.message || err}`));
});
