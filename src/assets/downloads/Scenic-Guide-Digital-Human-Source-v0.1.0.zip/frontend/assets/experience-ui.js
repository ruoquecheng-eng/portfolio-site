(function () {
  "use strict";

  const ROUTES = [
    { id: "gate", title: "入口", meta: "确认当前位置" },
    { id: "xiangfu", title: "祥符禅寺", meta: "先听背景" },
    { id: "buddha", title: "灵山大佛", meta: "核心礼佛点" },
    { id: "brahma", title: "梵宫", meta: "建筑与演艺" },
    { id: "wuyin", title: "五印坛城", meta: "收束体验" }
  ];

  const PREFERENCES = [
    { label: "轻松逛", prompt: "我想轻松逛灵山胜境，路线不要太累" },
    { label: "听故事", prompt: "我想听灵山大佛和梵宫背后的故事" },
    { label: "带孩子", prompt: "我是亲子家庭，请推荐轻松、有互动点的路线" },
    { label: "拍照点", prompt: "请推荐灵山胜境适合拍照的路线和下一站" },
    { label: "时间不多", prompt: "我时间不多，请给我一条最顺的精华路线" }
  ];

  const state = {
    routeIndex: 0,
    stage: "idle",
    speakingTimer: 0
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function guideLabel() {
    return /guide-kei/i.test(location.pathname) ? "灵山男导游" : "灵山女导游";
  }

  function setText(node, text) {
    if (node) node.textContent = text;
  }

  function escapeAttr(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function mountStage() {
    const avatar = $(".avatar");
    if (!avatar || $(".guide-stage-status", avatar)) return;

    avatar.insertAdjacentHTML("beforeend", `
      <div class="guide-stage-status" aria-live="polite">
        <span class="stage-dot"></span>
        <span class="stage-label">待命中</span>
      </div>
      <div class="guide-stage-caption">
        <strong>${guideLabel()}</strong>
        <span>可以直接问路线、景点故事或下一站。</span>
      </div>
    `);
  }

  function mountPreferenceChips() {
    const toolbar = $(".quick-toolbar");
    if (!toolbar || $(".experience-preferences")) return;
    const wrap = document.createElement("div");
    wrap.className = "experience-preferences";
    wrap.setAttribute("aria-label", "游览方式选择");
    wrap.innerHTML = `
      <div class="experience-section-head">
        <strong>今天想怎么逛？</strong>
        <span>选一个方向，我会先替你铺好路线。</span>
      </div>
      <div class="experience-chip-row">
        ${PREFERENCES.map((item, index) => `
          <button type="button" class="experience-chip${index === 0 ? " active" : ""}" data-prompt="${escapeAttr(item.prompt)}">${item.label}</button>
        `).join("")}
      </div>
    `;
    toolbar.parentNode.insertBefore(wrap, toolbar);
    $$(".experience-chip", wrap).forEach((button, index) => {
      button.addEventListener("click", () => {
        $$(".experience-chip", wrap).forEach((node) => node.classList.remove("active"));
        button.classList.add("active");
        const question = $("#question");
        if (question && !String(question.value || "").trim()) {
          question.value = button.dataset.prompt || "";
          question.dispatchEvent(new Event("input", { bubbles: true }));
        }
        setRoute(index % ROUTES.length, "selected");
        setStage("asking", `${button.textContent.trim()}路线已准备`);
      });
    });
  }

  function mountRouteRail() {
    const toolbar = $(".quick-toolbar");
    const answer = $("#answer");
    if (!toolbar || !answer || $(".experience-route")) return;
    const route = document.createElement("section");
    route.className = "experience-route";
    route.setAttribute("aria-label", "推荐游览路线");
    route.innerHTML = `
      <div class="experience-section-head">
        <strong>路线预览</strong>
        <span class="route-state">先选玩法或直接提问，我会自动更新路线。</span>
      </div>
      <div class="route-rail">
        ${ROUTES.map((item, index) => `
          <button type="button" class="route-node${index === 0 ? " active" : ""}" data-route-index="${index}">
            <span class="route-index">${index + 1}</span>
            <span class="route-title">${item.title}</span>
            <span class="route-meta">${item.meta}</span>
          </button>
        `).join("")}
      </div>
    `;
    const answerSurface = answer.closest(".answer-surface");
    const target = answerSurface || answer;
    target.parentNode.insertBefore(route, target);
    $$(".route-node", route).forEach((button) => {
      button.addEventListener("click", () => {
        const index = Number(button.dataset.routeIndex || "0");
        setRoute(index, "selected");
        const question = $("#question");
        if (question && !String(question.value || "").trim()) {
          question.value = `请详细讲解${ROUTES[index].title}这一站，以及下一站怎么走。`;
          question.dispatchEvent(new Event("input", { bubbles: true }));
        }
      });
    });
  }

  function setRoute(index, reason) {
    const next = Math.max(0, Math.min(ROUTES.length - 1, Number(index) || 0));
    state.routeIndex = next;
    $$(".route-node").forEach((node, i) => {
      node.classList.toggle("active", i === next);
      node.classList.toggle("visited", i < next);
      node.classList.toggle("pending", i > next);
    });
    const routeState = $(".route-state");
    const label = ROUTES[next]?.title || "当前路线";
    const copy = reason === "speaking"
      ? `正在讲解：${label}`
      : reason === "answered"
        ? `已生成建议：下一站重点看${label}`
        : `当前聚焦：${label}`;
    setText(routeState, copy);
  }

  function setStage(stage, label) {
    state.stage = stage;
    document.body.dataset.guideStage = stage;
    const avatar = $(".avatar");
    if (avatar) avatar.dataset.stage = stage;
    const text = label || ({
      idle: "待命中",
      asking: "准备路线",
      thinking: "整理路线中",
      answered: "导览建议已生成",
      speaking: "正在讲解",
      listening: "正在听你说"
    }[stage] || "待命中");
    setText($(".stage-label"), text);
  }

  function cycleSpeakingRoute() {
    window.clearInterval(state.speakingTimer);
    setRoute(state.routeIndex, "speaking");
    state.speakingTimer = window.setInterval(() => {
      setRoute((state.routeIndex + 1) % ROUTES.length, "speaking");
    }, 1800);
  }

  function patchFunction(name, before, after) {
    const original = window[name];
    if (typeof original !== "function" || original.__experiencePatched) return;
    const wrapped = function (...args) {
      before?.();
      let result;
      try {
        result = original.apply(this, args);
      } catch (error) {
        setStage("idle", "操作没有完成");
        throw error;
      }
      Promise.resolve(result).then(
        (value) => after?.(value),
        () => setStage("idle", "操作没有完成")
      );
      return result;
    };
    wrapped.__experiencePatched = true;
    window[name] = wrapped;
  }

  function patchInteractions() {
    patchFunction("sendQuestion", () => {
      setStage("thinking");
      setRoute(Math.max(1, state.routeIndex), "selected");
    }, () => {
      setStage("answered");
      setRoute(Math.max(2, state.routeIndex), "answered");
    });
    patchFunction("quickAsk", () => {
      setStage("thinking");
      setRoute(1, "selected");
    }, () => {
      setStage("answered");
      setRoute(2, "answered");
    });
    patchFunction("voiceInput", () => {
      setStage("listening");
      window.setTimeout(() => {
        if (state.stage === "listening") setStage("asking", "语音已准备");
      }, 2200);
    });
    patchFunction("speakLast", () => {
      setStage("speaking");
      cycleSpeakingRoute();
    });
    patchFunction("stopSpeak", () => {
      window.clearInterval(state.speakingTimer);
      setStage("answered");
      setRoute(state.routeIndex, "answered");
    });
  }

  function bindInputStates() {
    const question = $("#question");
    if (question) {
      question.addEventListener("focus", () => setStage("asking", "可以直接提问"));
      question.addEventListener("input", () => {
        document.body.classList.toggle("has-question-draft", String(question.value || "").trim().length > 0);
      });
    }
    $$(".quick-toolbar .q-btn").forEach((button, index) => {
      button.addEventListener("mouseenter", () => setRoute((index + 1) % ROUTES.length, "selected"));
      button.addEventListener("focus", () => setRoute((index + 1) % ROUTES.length, "selected"));
    });
  }

  function init() {
    if (document.body.dataset.experienceUiReady === "1") return;
    document.body.dataset.experienceUiReady = "1";
    document.body.classList.add("experience-ui");
    document.body.dataset.guidePersona = guideLabel();
    mountStage();
    mountPreferenceChips();
    mountRouteRail();
    bindInputStates();
    patchInteractions();
    setStage("idle");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
