# Scenic Guide Digital Human — sanitized public source package

This package is a reproducible, sanitized snapshot of the competition prototype. It contains the visitor-facing front end, the local Node.js back end, selected sample knowledge data, and a static SVG guide fallback.

## Excluded deliberately

- `.env`, `competition.env`, credentials, API keys, administrator tokens, and private configuration
- databases, `store.json`, caches, logs, reports, backups, uploads, and `node_modules`
- `frontend/assets/live2d`, `frontend/assets/vendor/live2d`, and all other Live2D/model files whose redistribution rights were not established

The public build disables Live2D loading. When original model assets are absent, the interface uses `frontend/assets/avatars/guide-fallback.svg`. This keeps the UI inspectable without claiming that third-party model assets are included.

## Run locally

1. Install Node.js 20 or newer.
2. In `backend`, run `npm ci` and then `node server.js`.
3. In another terminal, run `node frontend/local_frontend_server.js`.
4. Open `http://127.0.0.1:8010/`.

No model API key is required for the local fallback path. Copy the root `.env.example` only if optional local configuration is needed; do not commit real credentials.

## Scope

This is a competition prototype to which the portfolio owner contributed. It is not presented as a production deployment or as a redistribution of third-party Live2D models.