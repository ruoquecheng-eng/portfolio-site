# Third-party and excluded assets

The original working directory referenced Cubism/Live2D runtimes and model assets under `frontend/assets/live2d` and `frontend/assets/vendor/live2d`. Their redistribution license was not established for this public package, so neither the files nor their runtime bundles are included.

The replacement `frontend/assets/avatars/guide-fallback.svg` is an original static fallback created for this package. Node.js dependencies are declared in `backend/package.json` and must be installed by the recipient from their own package registry environment.