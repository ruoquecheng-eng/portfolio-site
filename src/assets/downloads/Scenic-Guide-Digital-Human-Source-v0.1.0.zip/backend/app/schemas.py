from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, description="游客问题")
    user_id: str = Field(default="guest")
    mode: str = Field(default="text", description="text|voice")
    interests: list[str] = Field(default_factory=list, description="兴趣标签")
    image_url: str | None = None


class SourceItem(BaseModel):
    title: str
    source: str
    snippet: str
    score: float


class RouteRecommendation(BaseModel):
    name: str
    description: str
    stops: list[str]
    match_tags: list[str]


class AvatarAction(BaseModel):
    expression: str
    mouth_animation: str


class ChatResponse(BaseModel):
    answer: str
    emotion: str
    latency_ms: int
    sources: list[SourceItem]
    route_recommendation: RouteRecommendation | None
    avatar_action: AvatarAction


class DocCreateRequest(BaseModel):
    title: str
    source: str = "manual"
    content: str


class DocItem(BaseModel):
    id: int
    title: str
    source: str
    content: str
    created_at: str
    updated_at: str


class AvatarConfigRequest(BaseModel):
    display_name: str
    voice_style: str
    outfit: str


class AvatarConfigResponse(BaseModel):
    display_name: str
    voice_style: str
    outfit: str
    updated_at: str
