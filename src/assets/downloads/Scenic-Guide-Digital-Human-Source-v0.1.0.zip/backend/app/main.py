from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.config import FRONTEND_DIR, PROJECT_DIR, settings
from app.db import init_db
from app.schemas import (
    AvatarConfigRequest,
    AvatarConfigResponse,
    ChatRequest,
    ChatResponse,
    DocCreateRequest,
    DocItem,
)
from app.services import (
    add_knowledge_doc,
    delete_knowledge_doc,
    get_avatar_config,
    get_dashboard_summary,
    get_report,
    import_demo_knowledge,
    list_knowledge_docs,
    process_chat,
    update_avatar_config,
)

app = FastAPI(title=settings.APP_NAME, version=settings.APP_VERSION)

try:
    import multipart as _multipart  # noqa: F401
    MULTIPART_AVAILABLE = True
except Exception:
    MULTIPART_AVAILABLE = False

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

INOCHI_ASSETS_DIR = (PROJECT_DIR / "inochi-assets").resolve()
if INOCHI_ASSETS_DIR.exists():
    app.mount("/inochi-assets", StaticFiles(directory=str(INOCHI_ASSETS_DIR)), name="inochi-assets")


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
    }


@app.post("/api/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    result = process_chat(
        question=payload.question,
        user_id=payload.user_id,
        mode=payload.mode,
        interests=payload.interests,
        image_url=payload.image_url,
    )
    return result


@app.get("/api/routes/dashboard")
def dashboard():
    return get_dashboard_summary()


@app.get("/api/routes/report")
def report():
    return get_report()


@app.post("/api/admin/knowledge/import_demo")
def import_demo():
    return import_demo_knowledge()


@app.post("/api/admin/knowledge", response_model=DocItem)
def add_doc(payload: DocCreateRequest):
    return add_knowledge_doc(payload.title, payload.source, payload.content)


if MULTIPART_AVAILABLE:
    @app.post("/api/admin/knowledge/upload", response_model=DocItem)
    async def upload_doc(file: UploadFile = File(...), title: str | None = None):
        content = (await file.read()).decode("utf-8", errors="ignore")
        clean_title = title or Path(file.filename or "upload.txt").stem
        return add_knowledge_doc(clean_title, "upload", content)
else:
    @app.post("/api/admin/knowledge/upload")
    async def upload_doc_unavailable():
        raise HTTPException(
            status_code=503,
            detail='missing dependency: python-multipart (pip install "python-multipart")',
        )


@app.get("/api/admin/knowledge", response_model=list[DocItem])
def list_docs():
    return list_knowledge_docs()


@app.delete("/api/admin/knowledge/{doc_id}")
def delete_doc(doc_id: int):
    ok = delete_knowledge_doc(doc_id)
    if not ok:
        raise HTTPException(status_code=404, detail="doc not found")
    return {"ok": True}


@app.get("/api/admin/avatar", response_model=AvatarConfigResponse)
def get_avatar():
    return get_avatar_config()


@app.put("/api/admin/avatar", response_model=AvatarConfigResponse)
def put_avatar(payload: AvatarConfigRequest):
    return update_avatar_config(payload.display_name, payload.voice_style, payload.outfit)


@app.get("/")
def root():
    index = FRONTEND_DIR / "index.html"
    if index.exists():
        return FileResponse(index)
    return {"message": "frontend not found"}
