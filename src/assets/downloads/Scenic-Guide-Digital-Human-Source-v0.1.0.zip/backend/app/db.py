import json
import sqlite3
from datetime import UTC, datetime

from app.config import DB_FILE


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_FILE, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _now() -> str:
    return datetime.now(UTC).isoformat()


def init_db() -> None:
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS knowledge_docs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                source TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS qa_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                question TEXT NOT NULL,
                answer TEXT NOT NULL,
                mode TEXT NOT NULL,
                emotion TEXT NOT NULL,
                latency_ms INTEGER NOT NULL,
                route_name TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS profiles (
                user_id TEXT PRIMARY KEY,
                interests_json TEXT NOT NULL,
                last_seen TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS routes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                tags_json TEXT NOT NULL,
                stops_json TEXT NOT NULL,
                description TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS avatar_config (
                id INTEGER PRIMARY KEY CHECK(id = 1),
                display_name TEXT NOT NULL,
                voice_style TEXT NOT NULL,
                outfit TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """
        )

        route_count = conn.execute("SELECT COUNT(1) AS c FROM routes").fetchone()["c"]
        if route_count == 0:
            seed_routes = [
                (
                    "历史文化深度线",
                    json.dumps(["history", "culture", "lingshan"], ensure_ascii=False),
                    json.dumps(["祥符禅寺", "灵山大佛", "灵山梵宫", "五印坛城"], ensure_ascii=False),
                    "灵山胜境佛教文化核心路线，适合深度讲解。",
                ),
                (
                    "自然风光轻徒步线",
                    json.dumps(["nature", "taihu", "zen"], ensure_ascii=False),
                    json.dumps(["菩提大道", "太湖观景平台", "曼飞龙塔园林", "拈花湾禅意花海"], ensure_ascii=False),
                    "灵山山水与禅意园林轻徒步路线，适合拍照休闲。",
                ),
                (
                    "亲子互动体验线",
                    json.dumps(["family", "interactive", "show"], ensure_ascii=False),
                    json.dumps(["九龙灌浴", "佛手广场", "百子戏弥勒", "梵宫吉祥颂演艺"], ensure_ascii=False),
                    "围绕灵山亲子互动与演艺场次的轻松路线。",
                ),
                (
                    "地道美食漫游线",
                    json.dumps(["food", "tea", "night"], ensure_ascii=False),
                    json.dumps(["梵宫素斋区", "灵山精舍茶点", "拈花湾香月花街"], ensure_ascii=False),
                    "覆盖素斋、茶点与夜间街区的慢节奏路线。",
                ),
            ]
            conn.executemany(
                "INSERT INTO routes(name, tags_json, stops_json, description) VALUES (?, ?, ?, ?)",
                seed_routes,
            )

        avatar = conn.execute("SELECT id FROM avatar_config WHERE id = 1").fetchone()
        if avatar is None:
            conn.execute(
                """
                INSERT INTO avatar_config(id, display_name, voice_style, outfit, updated_at)
                VALUES (1, ?, ?, ?, ?)
                """,
                ("灵山小导", "亲和女声", "灵山禅意导览制服", _now()),
            )

        conn.commit()
    finally:
        conn.close()
