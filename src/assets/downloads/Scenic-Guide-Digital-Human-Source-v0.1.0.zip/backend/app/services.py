import json
import re
import time
from collections import Counter, defaultdict
from datetime import datetime
from threading import BoundedSemaphore, Lock

import httpx

from app.config import BACKEND_DIR, settings
from app.db import get_conn


_MODEL_CALL_SEMAPHORE = BoundedSemaphore(max(1, int(getattr(settings, "MODEL_MAX_CONCURRENCY", 2) or 2)))
_MODEL_STATE_LOCK = Lock()
_MODEL_FAIL_STREAK = 0
_MODEL_CIRCUIT_OPEN_UNTIL = 0.0


def _now() -> str:
    return datetime.utcnow().isoformat()


def _tokenize(text: str) -> list[str]:
    tokens = re.findall(r"[a-zA-Z0-9]+|[\u4e00-\u9fff]{1,4}", (text or "").lower())
    return [t for t in tokens if t.strip()]


def _emotion_from_question(question: str) -> str:
    q = question.lower()
    if any(k in q for k in ["不满", "糟糕", "差", "投诉", "生气", "慢"]):
        return "negative"
    if any(k in q for k in ["喜欢", "满意", "好", "赞", "棒", "开心"]):
        return "positive"
    return "neutral"


def _avatar_action(emotion: str) -> dict:
    mapping = {
        "positive": {"expression": "smile", "mouth_animation": "energetic"},
        "negative": {"expression": "concerned", "mouth_animation": "gentle"},
        "neutral": {"expression": "natural", "mouth_animation": "standard"},
    }
    return mapping.get(emotion, mapping["neutral"])


def _extract_interests(question: str, declared: list[str]) -> list[str]:
    result = {x.strip() for x in (declared or []) if x and x.strip()}
    mapping = {
        "历史": ["历史", "古迹", "文化", "文物"],
        "自然": ["自然", "风景", "拍照", "山", "湖", "花"],
        "亲子": ["亲子", "孩子", "家庭", "小朋友"],
        "美食": ["美食", "吃", "餐厅", "小吃"],
    }
    q = question.lower()
    for tag, keywords in mapping.items():
        if any(k in q for k in keywords):
            result.add(tag)
    return sorted(result)


def _fetch_docs() -> list[dict]:
    conn = get_conn()
    try:
        rows = conn.execute("SELECT * FROM knowledge_docs ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def _search_docs(question: str, limit: int = 3) -> list[dict]:
    docs = _fetch_docs()
    q_tokens = _tokenize(question)
    q_count = Counter(q_tokens)
    scored = []
    for doc in docs:
        doc_tokens = _tokenize(doc["title"] + " " + doc["content"])
        d_count = Counter(doc_tokens)
        overlap = sum(min(q_count[t], d_count[t]) for t in q_count)
        if overlap <= 0:
            continue
        score = overlap / max(1, len(q_tokens))
        snippet = doc["content"][:120].replace("\n", " ")
        scored.append(
            {
                "title": doc["title"],
                "source": doc["source"],
                "snippet": snippet,
                "score": round(score, 4),
                "content": doc["content"],
            }
        )
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:limit]


def _upsert_profile(user_id: str, interests: list[str]) -> None:
    conn = get_conn()
    now = _now()
    try:
        interests_json = json.dumps(interests, ensure_ascii=False)
        conn.execute(
            """
            INSERT INTO profiles(user_id, interests_json, last_seen)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
              interests_json = excluded.interests_json,
              last_seen = excluded.last_seen
            """,
            (user_id, interests_json, now),
        )
        conn.commit()
    finally:
        conn.close()


def _recommend_route(interests: list[str]) -> dict | None:
    conn = get_conn()
    try:
        rows = conn.execute("SELECT * FROM routes").fetchall()
        best = None
        best_score = -1
        interest_set = set(interests)
        for r in rows:
            tags = set(json.loads(r["tags_json"]))
            match = sorted(list(tags.intersection(interest_set)))
            score = len(match)
            if score > best_score:
                best_score = score
                best = {
                    "name": r["name"],
                    "description": r["description"],
                    "stops": json.loads(r["stops_json"]),
                    "match_tags": match,
                }
        return best
    finally:
        conn.close()


def _build_prompt(question: str, sources: list[dict], route: dict | None, interests: list[str]) -> str:
    context_parts = []
    for idx, src in enumerate(sources, 1):
        context_parts.append(f"[资料{idx}] {src['title']}：{src['content'][:300]}")
    route_hint = ""
    if route:
        route_hint = f"\n推荐路线：{route['name']}，站点：{'、'.join(route['stops'])}"
    return (
        "你是景区导览AI数字人。请以亲切、简洁、准确的中文回答。\n"
        f"游客兴趣：{', '.join(interests) if interests else '未指定'}\n"
        f"问题：{question}\n"
        f"{chr(10).join(context_parts)}"
        f"{route_hint}\n"
        "要求：优先基于资料回答，若资料不足需明确说明并给出建议。"
    )


def _is_model_circuit_open() -> bool:
    with _MODEL_STATE_LOCK:
        return time.time() < _MODEL_CIRCUIT_OPEN_UNTIL


def _mark_model_call_result(ok: bool) -> None:
    global _MODEL_FAIL_STREAK, _MODEL_CIRCUIT_OPEN_UNTIL
    with _MODEL_STATE_LOCK:
        if ok:
            _MODEL_FAIL_STREAK = 0
            _MODEL_CIRCUIT_OPEN_UNTIL = 0.0
            return
        _MODEL_FAIL_STREAK += 1
        if _MODEL_FAIL_STREAK >= 3:
            cooldown = max(5, int(getattr(settings, "MODEL_CIRCUIT_BREAK_SECONDS", 20) or 20))
            _MODEL_CIRCUIT_OPEN_UNTIL = time.time() + cooldown


def _effective_model_timeout_seconds() -> int:
    configured = int(getattr(settings, "MODEL_TIMEOUT_SECONDS", 30) or 30)
    fast_cap = int(getattr(settings, "MODEL_TIMEOUT_FAST_SECONDS", 6) or 6)
    configured = max(1, configured)
    fast_cap = max(1, fast_cap)
    return max(1, min(configured, fast_cap))


def _call_online_model(question: str, sources: list[dict], route: dict | None, interests: list[str], image_url: str | None) -> str | None:
    if not settings.MULTIMODAL_ENABLED:
        return None
    if not (settings.MODEL_API_KEY or "").strip():
        return None
    if _is_model_circuit_open():
        return None

    acquired = _MODEL_CALL_SEMAPHORE.acquire(timeout=0.2)
    if not acquired:
        return None

    try:
        prompt = _build_prompt(question, sources, route, interests)
        user_content: list[dict] = [{"type": "text", "text": prompt}]
        if image_url:
            user_content.append({"type": "image_url", "image_url": {"url": image_url}})

        payload = {
            "model": settings.MODEL_NAME,
            "messages": [
                {"role": "system", "content": "????AI????????"},
                {"role": "user", "content": user_content},
            ],
            "temperature": 0.2,
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {settings.MODEL_API_KEY}",
        }

        timeout_s = _effective_model_timeout_seconds()
        timeout = httpx.Timeout(timeout=timeout_s, connect=min(2.0, float(timeout_s)), read=float(timeout_s))

        with httpx.Client(timeout=timeout) as client:
            resp = client.post(settings.MODEL_BASE_URL, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            choices = data.get("choices") or []
            if not choices:
                _mark_model_call_result(False)
                return None
            msg = choices[0].get("message", {})
            content = msg.get("content")
            if isinstance(content, str):
                text = content.strip()
                _mark_model_call_result(bool(text))
                return text or None
            if isinstance(content, list):
                text_parts = [x.get("text", "") for x in content if isinstance(x, dict)]
                text = "".join(text_parts).strip() or None
                _mark_model_call_result(bool(text))
                return text
    except Exception:
        _mark_model_call_result(False)
        return None
    finally:
        _MODEL_CALL_SEMAPHORE.release()

    return None


def _fallback_answer(question: str, sources: list[dict], route: dict | None) -> str:
    if sources:
        knowledge = "；".join(f"{s['title']}：{s['snippet']}" for s in sources[:2])
        route_line = ""
        if route:
            route_line = f"\n我建议你走“{route['name']}”，重点站点：{'、'.join(route['stops'][:3])}。"
        return f"根据景区资料，我先给你一个导览建议：{knowledge}{route_line}\n如果你愿意，我可以继续细化到每个站点的讲解词。"
    return "我当前资料命中较少，建议你告诉我更具体的景点名称或兴趣方向（如历史/自然/亲子），我会给出更精准导览。"


def process_chat(question: str, user_id: str, mode: str, interests: list[str], image_url: str | None) -> dict:
    started = time.time()
    normalized_interests = _extract_interests(question, interests)
    _upsert_profile(user_id, normalized_interests)
    sources = _search_docs(question, limit=3)
    route = _recommend_route(normalized_interests)
    emotion = _emotion_from_question(question)

    answer = _call_online_model(question, sources, route, normalized_interests, image_url)
    if not answer:
        answer = _fallback_answer(question, sources, route)

    latency_ms = int((time.time() - started) * 1000)

    conn = get_conn()
    try:
        conn.execute(
            """
            INSERT INTO qa_logs(user_id, question, answer, mode, emotion, latency_ms, route_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (user_id, question, answer, mode, emotion, latency_ms, route["name"] if route else None, _now()),
        )
        conn.commit()
    finally:
        conn.close()

    return {
        "answer": answer,
        "emotion": emotion,
        "latency_ms": latency_ms,
        "sources": [{k: s[k] for k in ["title", "source", "snippet", "score"]} for s in sources],
        "route_recommendation": route,
        "avatar_action": _avatar_action(emotion),
    }


def import_demo_knowledge() -> dict:
    data_path = BACKEND_DIR / "data" / "demo_scenic_knowledge.json"
    raw = json.loads(data_path.read_text(encoding="utf-8"))
    docs = raw.get("docs", [])
    now = _now()
    conn = get_conn()
    inserted = 0
    try:
        for d in docs:
            conn.execute(
                """
                INSERT INTO knowledge_docs(title, source, content, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (d["title"], d.get("source", "demo_pack"), d["content"], now, now),
            )
            inserted += 1
        conn.commit()
    finally:
        conn.close()
    return {"inserted": inserted}


def add_knowledge_doc(title: str, source: str, content: str) -> dict:
    now = _now()
    conn = get_conn()
    try:
        cursor = conn.execute(
            """
            INSERT INTO knowledge_docs(title, source, content, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (title, source, content, now, now),
        )
        conn.commit()
        new_id = cursor.lastrowid
        row = conn.execute("SELECT * FROM knowledge_docs WHERE id = ?", (new_id,)).fetchone()
        return dict(row)
    finally:
        conn.close()


def list_knowledge_docs() -> list[dict]:
    conn = get_conn()
    try:
        rows = conn.execute("SELECT * FROM knowledge_docs ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def delete_knowledge_doc(doc_id: int) -> bool:
    conn = get_conn()
    try:
        cursor = conn.execute("DELETE FROM knowledge_docs WHERE id = ?", (doc_id,))
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def get_avatar_config() -> dict:
    conn = get_conn()
    try:
        row = conn.execute("SELECT * FROM avatar_config WHERE id = 1").fetchone()
        return dict(row)
    finally:
        conn.close()


def update_avatar_config(display_name: str, voice_style: str, outfit: str) -> dict:
    conn = get_conn()
    now = _now()
    try:
        conn.execute(
            "UPDATE avatar_config SET display_name = ?, voice_style = ?, outfit = ?, updated_at = ? WHERE id = 1",
            (display_name, voice_style, outfit, now),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM avatar_config WHERE id = 1").fetchone()
        return dict(row)
    finally:
        conn.close()


def get_dashboard_summary() -> dict:
    conn = get_conn()
    try:
        today = datetime.utcnow().strftime("%Y-%m-%d")
        service_today = conn.execute(
            "SELECT COUNT(1) AS c FROM qa_logs WHERE substr(created_at,1,10)=?",
            (today,),
        ).fetchone()["c"]
        service_week = conn.execute(
            """
            SELECT COUNT(1) AS c FROM qa_logs
            WHERE datetime(created_at) >= datetime('now', '-7 day')
            """
        ).fetchone()["c"]
        avg_latency = conn.execute("SELECT AVG(latency_ms) AS a FROM qa_logs").fetchone()["a"] or 0
        top_routes_rows = conn.execute(
            """
            SELECT COALESCE(route_name,'未推荐') as route_name, COUNT(1) AS c
            FROM qa_logs GROUP BY route_name ORDER BY c DESC LIMIT 5
            """
        ).fetchall()
        top_routes = [{"route_name": r["route_name"], "count": r["c"]} for r in top_routes_rows]
        return {
            "service_today": int(service_today),
            "service_week": int(service_week),
            "avg_latency_ms": round(float(avg_latency), 2),
            "top_routes": top_routes,
        }
    finally:
        conn.close()


def get_report() -> dict:
    conn = get_conn()
    try:
        rows = conn.execute("SELECT question, emotion, created_at FROM qa_logs ORDER BY id DESC LIMIT 500").fetchall()
        hot_counter = Counter()
        trend = defaultdict(lambda: {"positive": 0, "neutral": 0, "negative": 0})
        for r in rows:
            tokens = _tokenize(r["question"])
            for t in tokens:
                if len(t) >= 2:
                    hot_counter[t] += 1
            day = r["created_at"][:10]
            emo = r["emotion"]
            if emo in trend[day]:
                trend[day][emo] += 1

        hot_topics = [{"topic": k, "count": v} for k, v in hot_counter.most_common(12)]
        trend_list = [{"date": d, **vals} for d, vals in sorted(trend.items())]
        return {"hot_topics": hot_topics, "emotion_trend": trend_list}
    finally:
        conn.close()
