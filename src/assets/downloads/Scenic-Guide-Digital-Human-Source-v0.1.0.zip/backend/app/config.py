from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    APP_NAME: str = "灵山胜境AI导览中枢"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = True
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    DB_PATH: str = "data/scenic_ai_guide.db"

    MULTIMODAL_ENABLED: bool = False
    MODEL_PROVIDER: str = "openai_compatible"
    MODEL_BASE_URL: str = "https://api.deepseek.com/chat/completions"
    MODEL_NAME: str = "deepseek-chat"
    MODEL_API_KEY: str = ""
    MODEL_TIMEOUT_SECONDS: int = 30
    MODEL_TIMEOUT_FAST_SECONDS: int = 3
    MODEL_MAX_CONCURRENCY: int = 2
    MODEL_CIRCUIT_BREAK_SECONDS: int = 20
    # competition.env keeps the submitted package runnable; .env can override it locally.
    model_config = SettingsConfigDict(env_file=("competition.env", ".env"), env_file_encoding="utf-8", extra="ignore")


settings = Settings()

BACKEND_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = BACKEND_DIR.parent
DB_FILE = Path(settings.DB_PATH)
if not DB_FILE.is_absolute():
    DB_FILE = (BACKEND_DIR / DB_FILE).resolve()

FRONTEND_DIR = (PROJECT_DIR / "frontend").resolve()
